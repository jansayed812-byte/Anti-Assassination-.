import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  CheckCircle as CheckIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Add as AddIcon,
} from '@mui/icons-material';
import { monitoringService, Alert as AlertType, AlertStatistics } from '../../services';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const Monitoring: React.FC = () => {
  const { t } = useTranslation();
  const [tabValue, setTabValue] = useState(0);
  const [activeAlerts, setActiveAlerts] = useState<AlertType[]>([]);
  const [statistics, setStatistics] = useState<AlertStatistics | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newAlert, setNewAlert] = useState({
    title: '',
    description: '',
    severity: 'info',
    source: 'manual',
  });

  useEffect(() => {
    loadMonitoringData();
    connectWebSocket();
    
    const interval = setInterval(loadMonitoringData, 30000);
    
    return () => {
      clearInterval(interval);
    };
  }, [tabValue]);

  const connectWebSocket = () => {
    try {
      const { websocketService } = require('../../services');
      websocketService.connect();
      websocketService.onAlertCreated(() => loadMonitoringData());
    } catch (err) {
      console.error('WebSocket connection error:', err);
    }
  };

  const loadMonitoringData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [alerts, stats] = await Promise.all([
        monitoringService.getActiveAlerts(),
        monitoringService.getStatistics(),
      ]);

      setActiveAlerts(alerts);
      setStatistics(stats);
    } catch (err) {
      setError('Failed to load monitoring data');
      console.error('Error loading monitoring data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAlert = async () => {
    try {
      setLoading(true);
      await monitoringService.createAlert(newAlert);
      setShowCreateDialog(false);
      setNewAlert({ title: '', description: '', severity: 'info', source: 'manual' });
      loadMonitoringData();
    } catch (err) {
      setError('Failed to create alert');
      console.error('Error creating alert:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAcknowledgeAlert = async (alertId: string) => {
    try {
      setLoading(true);
      await monitoringService.acknowledgeAlert(alertId);
      loadMonitoringData();
    } catch (err) {
      setError('Failed to acknowledge alert');
      console.error('Error acknowledging alert:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      setLoading(true);
      await monitoringService.resolveAlert(alertId);
      loadMonitoringData();
    } catch (err) {
      setError('Failed to resolve alert');
      console.error('Error resolving alert:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckRules = async () => {
    try {
      setLoading(true);
      const result = await monitoringService.checkAlertRules();
      alert(`${t('triggered_alerts')}: ${result.triggered}`);
      loadMonitoringData();
    } catch (err) {
      setError('Failed to check alert rules');
      console.error('Error checking rules:', err);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return '#d32f2f';
      case 'error':
        return '#f44336';
      case 'warning':
        return '#ff9800';
      case 'info':
        return '#2196f3';
      default:
        return '#9e9e9e';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <ErrorIcon />;
      case 'error':
        return <ErrorIcon />;
      case 'warning':
        return <WarningIcon />;
      case 'info':
        return <InfoIcon />;
      default:
        return <InfoIcon />;
    }
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('monitoring')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            onClick={loadMonitoringData}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
          <Button
            variant="contained"
            onClick={() => setShowCreateDialog(true)}
            startIcon={<AddIcon />}
          >
            {t('create_alert')}
          </Button>
          <Button
            variant="outlined"
            onClick={handleCheckRules}
            startIcon={<NotificationsIcon />}
          >
            {t('check_rules')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ mb: 3 }}>
          <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)}>
            <Tab label={t('active_alerts')} />
            <Tab label={t('statistics')} />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              {activeAlerts.map((alert) => (
                <Grid item xs={12} md={6} lg={4} key={alert.id}>
                  <Card>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {getSeverityIcon(alert.severity)}
                          <Typography variant="h6">{alert.title}</Typography>
                        </Box>
                        <Chip
                          label={alert.severity}
                          sx={{
                            backgroundColor: getSeverityColor(alert.severity),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {alert.description}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('source')}: {alert.source}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('created_at')}: {new Date(alert.created_at).toLocaleString()}
                      </Typography>
                      <Box sx={{ mt: 2, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        {alert.acknowledged && (
                          <Chip label={t('acknowledged')} color="success" size="small" />
                        )}
                        {alert.resolved && (
                          <Chip label={t('resolved')} color="success" size="small" />
                        )}
                      </Box>
                      <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                        {!alert.acknowledged && (
                          <Button
                            size="small"
                            variant="outlined"
                            onClick={() => handleAcknowledgeAlert(alert.id)}
                          >
                            {t('acknowledge')}
                          </Button>
                        )}
                        {!alert.resolved && (
                          <Button
                            size="small"
                            variant="contained"
                            onClick={() => handleResolveAlert(alert.id)}
                            startIcon={<CheckIcon />}
                          >
                            {t('resolve')}
                          </Button>
                        )}
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>

            {activeAlerts.length === 0 && !loading && (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  {t('no_active_alerts')}
                </Typography>
              </Box>
            )}
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            {statistics && (
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('total_alerts')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }}>
                        {statistics.total_alerts}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('active_alerts')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }} color="error">
                        {statistics.active_alerts}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('resolved_alerts')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }} color="success">
                        {statistics.resolved_alerts}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('acknowledged_alerts')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }} color="info">
                        {statistics.acknowledged_alerts}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('by_severity')}
                      </Typography>
                      {Object.entries(statistics.by_severity).map(([severity, count]) => (
                        <Box key={severity} sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                          <Typography variant="body2">{severity}</Typography>
                          <Typography variant="body2">{count}</Typography>
                        </Box>
                      ))}
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('by_source')}
                      </Typography>
                      {Object.entries(statistics.by_source).map(([source, count]) => (
                        <Box key={source} sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                          <Typography variant="body2">{source}</Typography>
                          <Typography variant="body2">{count}</Typography>
                        </Box>
                      ))}
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('average_resolution_time')}
                      </Typography>
                      <Typography variant="h4">
                        {Math.round(statistics.average_resolution_time / 60)} {t('resolution_minutes')}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            )}
          </TabPanel>
        </Paper>

        {/* Create Alert Dialog */}
        <Dialog open={showCreateDialog} onClose={() => setShowCreateDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('create_alert')}</DialogTitle>
          <DialogContent>
            <TextField
              fullWidth
              label={t('title')}
              value={newAlert.title}
              onChange={(e) => setNewAlert({ ...newAlert, title: e.target.value })}
              sx={{ mt: 2 }}
            />
            <TextField
              fullWidth
              label={t('description')}
              value={newAlert.description}
              onChange={(e) => setNewAlert({ ...newAlert, description: e.target.value })}
              sx={{ mt: 2 }}
              multiline
              rows={3}
            />
            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel>{t('severity')}</InputLabel>
              <Select
                value={newAlert.severity}
                label={t('severity')}
                onChange={(e) => setNewAlert({ ...newAlert, severity: e.target.value })}
              >
                <MenuItem value="info">Info</MenuItem>
                <MenuItem value="warning">Warning</MenuItem>
                <MenuItem value="error">Error</MenuItem>
                <MenuItem value="critical">Critical</MenuItem>
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label={t('source')}
              value={newAlert.source}
              onChange={(e) => setNewAlert({ ...newAlert, source: e.target.value })}
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowCreateDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleCreateAlert} variant="contained">
              {t('create')}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default Monitoring;
