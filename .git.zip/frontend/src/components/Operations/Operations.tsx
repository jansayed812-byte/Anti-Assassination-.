import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Calendar,
} from '@mui/material';
import {
  Build as BuildIcon,
  Speed as SpeedIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Refresh as RefreshIcon,
  Event as EventIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material';
import { operationsService, SLAMetric, SLAViolation, MaintenanceTask, MaintenanceCalendar } from '../../services';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const Operations: React.FC = () => {
  const { t } = useTranslation();
  const [tabValue, setTabValue] = useState(0);
  const [slaMetrics, setSlaMetrics] = useState<SLAMetric[]>([]);
  const [slaViolations, setSlaViolations] = useState<SLAViolation[]>([]);
  const [maintenanceTasks, setMaintenanceTasks] = useState<MaintenanceTask[]>([]);
  const [maintenanceCalendar, setMaintenanceCalendar] = useState<MaintenanceCalendar | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadOperationsData();
  }, [tabValue]);

  const loadOperationsData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [metrics, violations, tasks, calendar] = await Promise.all([
        operationsService.getSLAMetrics(),
        operationsService.getSLAViolations(),
        operationsService.getMaintenanceTasks(),
        operationsService.getMaintenanceCalendar(),
      ]);

      setSlaMetrics(metrics);
      setSlaViolations(violations);
      setMaintenanceTasks(tasks);
      setMaintenanceCalendar(calendar);
    } catch (err) {
      setError('Failed to load operations data');
      console.error('Error loading operations data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteTask = async (taskId: number) => {
    try {
      setLoading(true);
      await operationsService.completeMaintenanceTask(taskId);
      loadOperationsData();
    } catch (err) {
      setError('Failed to complete maintenance task');
      console.error('Error completing task:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'within_target':
        return '#4caf50';
      case 'warning':
        return '#ff9800';
      case 'breached':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return '#d32f2f';
      case 'major':
        return '#f44336';
      case 'minor':
        return '#ff9800';
      default:
        return '#9e9e9e';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return '#d32f2f';
      case 'high':
        return '#f44336';
      case 'medium':
        return '#ff9800';
      case 'low':
        return '#4caf50';
      default:
        return '#9e9e9e';
    }
  };

  const getTaskStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return '#4caf50';
      case 'in_progress':
        return '#2196f3';
      case 'pending':
        return '#ff9800';
      case 'cancelled':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('operations')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            onClick={loadOperationsData}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ mb: 3 }}>
          <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)}>
            <Tab label={t('sla_metrics')} />
            <Tab label={t('sla_violations')} />
            <Tab label={t('maintenance')} />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              {slaMetrics.map((metric) => (
                <Grid item xs={12} md={6} lg={4} key={metric.id}>
                  <Card>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h6">{metric.name}</Typography>
                        <Chip
                          label={metric.status}
                          sx={{
                            backgroundColor: getStatusColor(metric.status),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('target')}: {metric.target} {metric.unit}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('current')}: {metric.current} {metric.unit}
                      </Typography>
                      <Box sx={{ mt: 2 }}>
                        <LinearProgress
                          variant="determinate"
                          value={(metric.current / metric.target) * 100}
                          sx={{
                            '& .MuiLinearProgress-bar': {
                              backgroundColor: getStatusColor(metric.status),
                            },
                          }}
                        />
                        <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
                          {t('last_measured')}: {new Date(metric.last_measured).toLocaleString()}
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>{t('metric')}</TableCell>
                    <TableCell>{t('violation_time')}</TableCell>
                    <TableCell>{t('severity')}</TableCell>
                    <TableCell>{t('description')}</TableCell>
                    <TableCell>{t('status')}</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {slaViolations.map((violation) => (
                    <TableRow key={violation.id}>
                      <TableCell>{violation.metric_id}</TableCell>
                      <TableCell>{new Date(violation.violation_time).toLocaleString()}</TableCell>
                      <TableCell>
                        <Chip
                          label={violation.severity}
                          sx={{
                            backgroundColor: getSeverityColor(violation.severity),
                            color: 'white',
                          }}
                        />
                      </TableCell>
                      <TableCell>{violation.description}</TableCell>
                      <TableCell>
                        <Chip
                          label={violation.resolved ? t('resolved') : t('open')}
                          sx={{
                            backgroundColor: violation.resolved ? '#4caf50' : '#f44336',
                            color: 'white',
                          }}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </TabPanel>

          <TabPanel value={tabValue} index={2}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                {maintenanceCalendar && (
                  <Card sx={{ mb: 3 }}>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('maintenance_calendar')} - {maintenanceCalendar.month}/{maintenanceCalendar.year}
                      </Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={4}>
                          <Typography variant="body2" color="text.secondary">
                            {t('completed')}: {maintenanceCalendar.completed_count}
                          </Typography>
                        </Grid>
                        <Grid item xs={4}>
                          <Typography variant="body2" color="text.secondary">
                            {t('pending')}: {maintenanceCalendar.pending_count}
                          </Typography>
                        </Grid>
                        <Grid item xs={4}>
                          <Typography variant="body2" color="text.secondary">
                            {t('total')}: {maintenanceCalendar.tasks.length}
                          </Typography>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                )}
              </Grid>

              {maintenanceTasks.map((task) => (
                <Grid item xs={12} md={6} lg={4} key={task.id}>
                  <Card>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                        <Typography variant="h6">{task.title}</Typography>
                        <Chip
                          label={task.priority}
                          sx={{
                            backgroundColor: getPriorityColor(task.priority),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {task.description}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('scheduled')}: {new Date(task.scheduled_date).toLocaleString()}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('assigned_to')}: {task.assigned_to}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('duration')}: {task.estimated_duration} {t('hours')}
                      </Typography>
                      <Box sx={{ mt: 2, display: 'flex', gap: 1, alignItems: 'center' }}>
                        <Chip
                          label={task.status}
                          sx={{
                            backgroundColor: getTaskStatusColor(task.status),
                            color: 'white',
                          }}
                        />
                        {task.status === 'pending' && (
                          <Button
                            size="small"
                            variant="contained"
                            onClick={() => handleCompleteTask(task.id)}
                          >
                            {t('complete')}
                          </Button>
                        )}
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </TabPanel>
        </Paper>
      </Box>
    </Container>
  );
};

export default Operations;
