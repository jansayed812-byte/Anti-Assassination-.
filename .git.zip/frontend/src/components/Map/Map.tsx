import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Container, Typography, Box, Paper, Button, CircularProgress } from '@mui/material';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { geolocationService, Position, trackingService } from '../../services';

// Fix for default marker icons in Leaflet with webpack
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface MapProps {
  center?: [number, number];
  zoom?: number;
}

const MapView: React.FC<MapProps> = ({ center = [35.6892, 51.3890], zoom = 13 }) => {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);

  return null;
};

const Map: React.FC = () => {
  const { t } = useTranslation();
  const [currentPosition, setCurrentPosition] = useState<Position | null>(null);
  const [positionHistory, setPositionHistory] = useState<Position[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number]>([35.6892, 51.3890]);

  useEffect(() => {
    loadCurrentPosition();
    loadPositionHistory();
  }, []);

  const loadCurrentPosition = async () => {
    try {
      setLoading(true);
      setError(null);
      const position = await geolocationService.getCurrentPosition();
      setCurrentPosition(position);
      setMapCenter([position.latitude, position.longitude]);
    } catch (err) {
      setError('Failed to load current position');
      console.error('Error loading position:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadPositionHistory = async () => {
    try {
      const history = await geolocationService.getHistory(50);
      setPositionHistory(history.positions);
    } catch (err) {
      console.error('Error loading position history:', err);
    }
  };

  const handleStartGeolocation = async () => {
    try {
      await geolocationService.start();
      loadCurrentPosition();
    } catch (err) {
      setError('Failed to start geolocation service');
      console.error('Error starting geolocation:', err);
    }
  };

  const handleStopGeolocation = async () => {
    try {
      await geolocationService.stop();
    } catch (err) {
      setError('Failed to stop geolocation service');
      console.error('Error stopping geolocation:', err);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString();
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('map')}
        </Typography>

        <Box sx={{ mb: 2, display: 'flex', gap: 2 }}>
          <Button
            variant="contained"
            onClick={handleStartGeolocation}
            disabled={loading}
          >
            {t('start_geolocation')}
          </Button>
          <Button
            variant="outlined"
            onClick={handleStopGeolocation}
          >
            {t('stop_geolocation')}
          </Button>
          <Button
            variant="outlined"
            onClick={loadCurrentPosition}
            disabled={loading}
          >
            {t('refresh')}
          </Button>
        </Box>

        {error && (
          <Typography color="error" sx={{ mb: 2 }}>
            {error}
          </Typography>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ height: '600px', width: '100%' }}>
          <MapContainer
            center={mapCenter}
            zoom={13}
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapView center={mapCenter} />
            
            {currentPosition && (
              <Marker position={[currentPosition.latitude, currentPosition.longitude]}>
                <Popup>
                  <div>
                    <strong>Current Position</strong><br />
                    Lat: {currentPosition.latitude.toFixed(6)}<br />
                    Lon: {currentPosition.longitude.toFixed(6)}<br />
                    Accuracy: {currentPosition.accuracy}m<br />
                    Source: {currentPosition.source}<br />
                    Time: {formatDate(currentPosition.timestamp)}
                  </div>
                </Popup>
              </Marker>
            )}

            {positionHistory.length > 1 && (
              <Polyline
                positions={positionHistory.map(pos => [pos.latitude, pos.longitude])}
                color="#FF0000"
                weight={2}
              />
            )}

            {positionHistory.map((position, index) => (
              <Marker
                key={index}
                position={[position.latitude, position.longitude]}
                opacity={0.5}
              >
                <Popup>
                  <div>
                    <strong>Position {index + 1}</strong><br />
                    Lat: {position.latitude.toFixed(6)}<br />
                    Lon: {position.longitude.toFixed(6)}<br />
                    Time: {formatDate(position.timestamp)}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </Paper>

        {currentPosition && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="h6">{t('current_position')}</Typography>
            <Typography>
              Latitude: {currentPosition.latitude.toFixed(6)}, 
              Longitude: {currentPosition.longitude.toFixed(6)}, 
              Accuracy: {currentPosition.accuracy}m
            </Typography>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default Map;
