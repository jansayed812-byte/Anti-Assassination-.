import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  IconButton,
} from '@mui/material';
import {
  Lock as LockIcon,
  Refresh as RefreshIcon,
  Sync as SyncIcon,
  Security as SecurityIcon,
  ContentCopy as ContentCopyIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
} from '@mui/icons-material';
import { advancedSecurityService, EncryptionKey, SecurityScanResult, SecurityFinding } from '../../services';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const AdvancedSecurity: React.FC = () => {
  const { t } = useTranslation();
  const [tabValue, setTabValue] = useState(0);
  const [keys, setKeys] = useState<EncryptionKey[]>([]);
  const [scanResult, setScanResult] = useState<SecurityScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showEncryptDialog, setShowEncryptDialog] = useState(false);
  const [showDecryptDialog, setShowDecryptDialog] = useState(false);
  const [encryptData, setEncryptData] = useState({ data: '', keyId: '' });
  const [decryptData, setDecryptData] = useState({ encryptedData: '', keyId: '', iv: '' });
  const [encryptResult, setEncryptResult] = useState<any>(null);
  const [decryptResult, setDecryptResult] = useState('');
  const [showKeyDetails, setShowKeyDetails] = useState(false);

  useEffect(() => {
    loadSecurityData();
  }, [tabValue]);

  const loadSecurityData = async () => {
    try {
      setLoading(true);
      setError(null);
      const keyList = await advancedSecurityService.getKeys();
      setKeys(keyList);
    } catch (err) {
      setError('Failed to load security data');
      console.error('Error loading security data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEncrypt = async () => {
    try {
      setLoading(true);
      const result = await advancedSecurityService.encryptData(encryptData.data, encryptData.keyId || undefined);
      setEncryptResult(result);
      setShowEncryptDialog(false);
      setEncryptData({ data: '', keyId: '' });
    } catch (err) {
      setError('Failed to encrypt data');
      console.error('Error encrypting data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDecrypt = async () => {
    try {
      setLoading(true);
      const result = await advancedSecurityService.decryptData(
        decryptData.encryptedData,
        decryptData.keyId,
        decryptData.iv
      );
      setDecryptResult(result);
      setShowDecryptDialog(false);
      setDecryptData({ encryptedData: '', keyId: '', iv: '' });
    } catch (err) {
      setError('Failed to decrypt data');
      console.error('Error decrypting data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRotateKey = async (keyId: string) => {
    try {
      setLoading(true);
      await advancedSecurityService.rotateKey(keyId);
      loadSecurityData();
    } catch (err) {
      setError('Failed to rotate key');
      console.error('Error rotating key:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSecurityScan = async () => {
    try {
      setLoading(true);
      const result = await advancedSecurityService.performSecurityScan();
      setScanResult(result);
    } catch (err) {
      setError('Failed to perform security scan');
      console.error('Error performing security scan:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return '#4caf50';
      case 'expired':
        return '#f44336';
      case 'revoked':
        return '#9e9e9e';
      default:
        return '#ff9800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return '#d32f2f';
      case 'high':
        return '#f44336';
      case 'medium':
        return '#ff9800';
      case 'low':
        return '#4caf50';
      default:
        return '#9e9e9e';
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('advanced_security')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            onClick={loadSecurityData}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
          <Button
            variant="contained"
            onClick={() => setShowEncryptDialog(true)}
            startIcon={<LockIcon />}
          >
            {t('encrypt_data')}
          </Button>
          <Button
            variant="outlined"
            onClick={() => setShowDecryptDialog(true)}
            startIcon={<LockIcon />}
          >
            {t('decrypt_data')}
          </Button>
          <Button
            variant="outlined"
            onClick={handleSecurityScan}
            startIcon={<SecurityIcon />}
          >
            {t('security_scan')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ mb: 3 }}>
          <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)}>
            <Tab label={t('encryption_keys')} />
            <Tab label={t('security_scan_results')} />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              {keys.map((key) => (
                <Grid item xs={12} md={6} lg={4} key={key.id}>
                  <Card>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h6">{key.name}</Typography>
                        <Chip
                          label={key.status}
                          sx={{
                            backgroundColor: getStatusColor(key.status),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('algorithm')}: {key.algorithm}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('key_size')}: {key.key_size} bits
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('created')}: {new Date(key.created_at).toLocaleString()}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('expires')}: {new Date(key.expires_at).toLocaleString()}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('last_rotated')}: {new Date(key.last_rotated).toLocaleString()}
                      </Typography>
                      <Box sx={{ mt: 2 }}>
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={() => handleRotateKey(key.id)}
                          startIcon={<SyncIcon />}
                          disabled={key.status !== 'active'}
                        >
                          {t('rotate_key')}
                        </Button>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>

            {keys.length === 0 && !loading && (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  {t('no_keys')}
                </Typography>
              </Box>
            )}
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            {scanResult ? (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('scan_summary')}
                      </Typography>
                      <Typography variant="body1" gutterBottom>
                        {t('overall_score')}: {scanResult.overall_score}/100
                      </Typography>
                      <Grid container spacing={2} sx={{ mt: 2 }}>
                        <Grid item xs={3}>
                          <Typography variant="body2" color="error">
                            {t('critical')}: {scanResult.vulnerabilities.critical}
                          </Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography variant="body2" color="error">
                            {t('high')}: {scanResult.vulnerabilities.high}
                          </Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography variant="body2" color="warning">
                            {t('medium')}: {scanResult.vulnerabilities.medium}
                          </Typography>
                        </Grid>
                        <Grid item xs={3}>
                          <Typography variant="body2" color="success">
                            {t('low')}: {scanResult.vulnerabilities.low}
                          </Typography>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    {t('findings')}
                  </Typography>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>{t('severity')}</TableCell>
                          <TableCell>{t('category')}</TableCell>
                          <TableCell>{t('description')}</TableCell>
                          <TableCell>{t('recommendation')}</TableCell>
                          <TableCell>{t('affected_components')}</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {scanResult.findings.map((finding) => (
                          <TableRow key={finding.id}>
                            <TableCell>
                              <Chip
                                label={finding.severity}
                                sx={{
                                  backgroundColor: getSeverityColor(finding.severity),
                                  color: 'white',
                                }}
                              />
                            </TableCell>
                            <TableCell>{finding.category}</TableCell>
                            <TableCell>{finding.description}</TableCell>
                            <TableCell>{finding.recommendation}</TableCell>
                            <TableCell>
                              {finding.affected_components.map((comp, index) => (
                                <Chip key={index} label={comp} variant="outlined" size="small" sx={{ mr: 1 }} />
                              ))}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
              </Grid>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  {t('no_scan_results')}
                </Typography>
              </Box>
            )}
          </TabPanel>
        </Paper>

        {/* Encrypt Result */}
        {encryptResult && (
          <Alert severity="success" sx={{ mb: 2 }}>
            <Typography variant="body2">{t('encryption_successful')}</Typography>
            <Box sx={{ mt: 1 }}>
              <Typography variant="caption">
                {t('encrypted_data')}: {encryptResult.encrypted_data.substring(0, 50)}...
              </Typography>
              <IconButton size="small" onClick={() => copyToClipboard(encryptResult.encrypted_data)}>
                <ContentCopyIcon fontSize="small" />
              </IconButton>
            </Box>
          </Alert>
        )}

        {/* Decrypt Result */}
        {decryptResult && (
          <Alert severity="success" sx={{ mb: 2 }}>
            <Typography variant="body2">{t('decryption_successful')}</Typography>
            <Typography variant="caption">{t('decrypted_data')}: {decryptResult}</Typography>
          </Alert>
        )}

        {/* Encrypt Dialog */}
        <Dialog open={showEncryptDialog} onClose={() => setShowEncryptDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('encrypt_data')}</DialogTitle>
          <DialogContent>
            <TextField
              fullWidth
              label={t('data_to_encrypt')}
              value={encryptData.data}
              onChange={(e) => setEncryptData({ ...encryptData, data: e.target.value })}
              sx={{ mt: 2 }}
              multiline
              rows={4}
            />
            <TextField
              fullWidth
              label={t('key_id_optional')}
              value={encryptData.keyId}
              onChange={(e) => setEncryptData({ ...encryptData, keyId: e.target.value })}
              sx={{ mt: 2 }}
              placeholder={t('leave_empty_for_default')}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowEncryptDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleEncrypt} variant="contained">
              {t('encrypt')}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Decrypt Dialog */}
        <Dialog open={showDecryptDialog} onClose={() => setShowDecryptDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('decrypt_data')}</DialogTitle>
          <DialogContent>
            <TextField
              fullWidth
              label={t('encrypted_data')}
              value={decryptData.encryptedData}
              onChange={(e) => setDecryptData({ ...decryptData, encryptedData: e.target.value })}
              sx={{ mt: 2 }}
              multiline
              rows={4}
            />
            <TextField
              fullWidth
              label={t('key_id')}
              value={decryptData.keyId}
              onChange={(e) => setDecryptData({ ...decryptData, keyId: e.target.value })}
              sx={{ mt: 2 }}
            />
            <TextField
              fullWidth
              label={t('iv')}
              value={decryptData.iv}
              onChange={(e) => setDecryptData({ ...decryptData, iv: e.target.value })}
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowDecryptDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleDecrypt} variant="contained">
              {t('decrypt')}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default AdvancedSecurity;
