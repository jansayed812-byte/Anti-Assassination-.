import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  IconButton,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Add as AddIcon,
  Send as SendIcon,
  PowerSettingsNew as PowerIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material';
import { communicationService, Device, DeviceCommand, websocketService } from '../../services';

const Devices: React.FC = () => {
  const { t } = useTranslation();
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [serviceActive, setServiceActive] = useState(false);
  const [showConnectDialog, setShowConnectDialog] = useState(false);
  const [showCommandDialog, setShowCommandDialog] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [newDeviceType, setNewDeviceType] = useState('');
  const [newConnectionString, setNewConnectionString] = useState('');
  const [commandText, setCommandText] = useState('');
  const [commandParams, setCommandParams] = useState('');

  useEffect(() => {
    loadDevices();
    connectWebSocket();
    
    return () => {
      websocketService.disconnect();
    };
  }, []);

  const connectWebSocket = () => {
    try {
      websocketService.connect();
      websocketService.onDeviceStatusChange((data) => {
        loadDevices(); // Refresh when device status changes
      });
    } catch (err) {
      console.error('WebSocket connection error:', err);
    }
  };

  const loadDevices = async () => {
    try {
      setLoading(true);
      setError(null);
      const deviceList = await communicationService.getDevices();
      setDevices(deviceList);
    } catch (err) {
      setError('Failed to load devices');
      console.error('Error loading devices:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartService = async () => {
    try {
      await communicationService.startService();
      setServiceActive(true);
      loadDevices();
    } catch (err) {
      setError('Failed to start communication service');
      console.error('Error starting service:', err);
    }
  };

  const handleConnectDevice = async () => {
    try {
      setLoading(true);
      setError(null);
      await communicationService.connectDevice(newDeviceType, newConnectionString);
      setShowConnectDialog(false);
      setNewDeviceType('');
      setNewConnectionString('');
      loadDevices();
    } catch (err) {
      setError('Failed to connect device');
      console.error('Error connecting device:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendCommand = async () => {
    if (!selectedDevice) return;

    try {
      setLoading(true);
      setError(null);
      const params = commandParams ? JSON.parse(commandParams) : undefined;
      await communicationService.sendCommand({
        device_id: selectedDevice.id,
        command: commandText,
        parameters: params,
      });
      setShowCommandDialog(false);
      setCommandText('');
      setCommandParams('');
      loadDevices();
    } catch (err) {
      setError('Failed to send command');
      console.error('Error sending command:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return '#4caf50';
      case 'disconnected':
        return '#9e9e9e';
      case 'error':
        return '#f44336';
      default:
        return '#ff9800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('devices')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            onClick={handleStartService}
            disabled={serviceActive}
            startIcon={<PowerIcon />}
          >
            {serviceActive ? t('service_active') : t('start_service')}
          </Button>
          <Button
            variant="outlined"
            onClick={loadDevices}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
          <Button
            variant="contained"
            onClick={() => setShowConnectDialog(true)}
            startIcon={<AddIcon />}
            disabled={!serviceActive}
          >
            {t('connect_device')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        {/* Device List */}
        <Grid container spacing={2}>
          {devices.map((device) => (
            <Grid item xs={12} md={6} lg={4} key={device.id}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="h6">{device.name}</Typography>
                    <Chip
                      label={device.status}
                      sx={{
                        backgroundColor: getStatusColor(device.status),
                        color: 'white',
                      }}
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {t('type')}: {device.type}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {t('last_seen')}: {formatDate(device.last_seen)}
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2" gutterBottom>
                      {t('capabilities')}:
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                      {device.capabilities.map((capability, index) => (
                        <Chip key={index} label={capability} variant="outlined" size="small" />
                      ))}
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => {
                        setSelectedDevice(device);
                        setShowCommandDialog(true);
                      }}
                      disabled={device.status !== 'connected'}
                      startIcon={<SendIcon />}
                    >
                      {t('send_command')}
                    </Button>
                    <IconButton
                      size="small"
                      disabled={device.status !== 'connected'}
                    >
                      <SettingsIcon />
                    </IconButton>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {devices.length === 0 && !loading && (
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="body1" color="text.secondary">
              {t('no_devices')}
            </Typography>
          </Paper>
        )}

        {/* Connect Device Dialog */}
        <Dialog open={showConnectDialog} onClose={() => setShowConnectDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('connect_device')}</DialogTitle>
          <DialogContent>
            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel>{t('device_type')}</InputLabel>
              <Select
                value={newDeviceType}
                label={t('device_type')}
                onChange={(e) => setNewDeviceType(e.target.value)}
              >
                <MenuItem value="mavlink">MAVLink (Drone)</MenuItem>
                <MenuItem value="serial">Serial Device</MenuItem>
                <MenuItem value="network">Network Device</MenuItem>
                <MenuItem value="bluetooth">Bluetooth Device</MenuItem>
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label={t('connection_string')}
              value={newConnectionString}
              onChange={(e) => setNewConnectionString(e.target.value)}
              sx={{ mt: 2 }}
              placeholder="e.g., /dev/ttyUSB0:57600 or 192.168.1.100:14550"
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowConnectDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleConnectDevice} variant="contained" disabled={!newDeviceType || !newConnectionString}>
              {t('connect')}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Send Command Dialog */}
        <Dialog open={showCommandDialog} onClose={() => setShowCommandDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            {t('send_command_to')} {selectedDevice?.name}
          </DialogTitle>
          <DialogContent>
            <TextField
              fullWidth
              label={t('command')}
              value={commandText}
              onChange={(e) => setCommandText(e.target.value)}
              sx={{ mt: 2 }}
              placeholder="e.g., ARM, TAKEOFF, LAND"
            />
            <TextField
              fullWidth
              label={t('parameters')}
              value={commandParams}
              onChange={(e) => setCommandParams(e.target.value)}
              sx={{ mt: 2 }}
              placeholder='{"altitude": 10, "speed": 5}'
              multiline
              rows={3}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowCommandDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleSendCommand} variant="contained" disabled={!commandText}>
              {t('send')}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default Devices;
