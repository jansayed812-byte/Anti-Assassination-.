import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
} from '@mui/material';
import {
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  CloudUpload as CloudUploadIcon,
} from '@mui/icons-material';
import { threatService, ThreatDetection, ThreatMap, RiskScore, websocketService } from '../../services';

const Threats: React.FC = () => {
  const { t } = useTranslation();
  const [threatMap, setThreatMap] = useState<ThreatMap | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [detectionResults, setDetectionResults] = useState<ThreatDetection[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [riskScore, setRiskScore] = useState<RiskScore | null>(null);
  const [analysisActive, setAnalysisActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showResultsDialog, setShowResultsDialog] = useState(false);

  useEffect(() => {
    loadThreatMap();
    connectWebSocket();
    
    return () => {
      websocketService.disconnect();
    };
  }, []);

  const connectWebSocket = () => {
    try {
      websocketService.connect();
      websocketService.onThreatDetected((data) => {
        loadThreatMap(); // Refresh when new threat is detected
      });
    } catch (err) {
      console.error('WebSocket connection error:', err);
    }
  };

  const loadThreatMap = async () => {
    try {
      setLoading(true);
      setError(null);
      const map = await threatService.getThreatMap();
      setThreatMap(map);
    } catch (err) {
      setError('Failed to load threat map');
      console.error('Error loading threat map:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartAnalysis = async () => {
    try {
      await threatService.startAnalysis();
      setAnalysisActive(true);
    } catch (err) {
      setError('Failed to start threat analysis');
      console.error('Error starting analysis:', err);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const handleAnalyzeImage = async () => {
    if (!selectedFile) return;

    try {
      setAnalyzing(true);
      setError(null);
      const results = await threatService.detectThreatInImage(selectedFile);
      setDetectionResults(results);
      setShowResultsDialog(true);
    } catch (err) {
      setError('Failed to analyze image');
      console.error('Error analyzing image:', err);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCalculateRisk = async (latitude: number, longitude: number) => {
    try {
      const score = await threatService.calculateRiskScore(latitude, longitude);
      setRiskScore(score);
    } catch (err) {
      setError('Failed to calculate risk score');
      console.error('Error calculating risk:', err);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low':
        return '#4caf50';
      case 'medium':
        return '#ff9800';
      case 'high':
        return '#f44336';
      case 'critical':
        return '#d32f2f';
      default:
        return '#9e9e9e';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return '#4caf50';
    if (confidence >= 0.6) return '#ff9800';
    return '#f44336';
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString();
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('threats')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            onClick={handleStartAnalysis}
            disabled={analysisActive}
            startIcon={<WarningIcon />}
          >
            {analysisActive ? t('analysis_active') : t('start_analysis')}
          </Button>
          <Button
            variant="outlined"
            onClick={loadThreatMap}
            disabled={loading}
          >
            {t('refresh')}
          </Button>
          <Button
            variant="outlined"
            component="label"
            startIcon={<CloudUploadIcon />}
          >
            {t('analyze_image')}
            <input
              type="file"
              hidden
              accept="image/*"
              onChange={handleFileSelect}
              ref={fileInputRef}
            />
          </Button>
          {selectedFile && (
            <Button
              variant="contained"
              onClick={handleAnalyzeImage}
              disabled={analyzing}
            >
              {analyzing ? t('analyzing') : t('analyze')}
            </Button>
          )}
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        {/* Risk Level Overview */}
        {threatMap && (
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              {t('overall_risk_level')}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Chip
                label={threatMap.risk_level.toUpperCase()}
                sx={{
                  backgroundColor: getRiskColor(threatMap.risk_level),
                  color: 'white',
                  fontSize: '1.2rem',
                  padding: '8px 16px',
                }}
              />
              <Typography variant="body2" color="text.secondary">
                {t('last_updated')}: {formatDate(new Date().getTime() / 1000)}
              </Typography>
            </Box>
          </Paper>
        )}

        {/* Threat Detection Results */}
        {threatMap && threatMap.threats.length > 0 && (
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                {t('detected_threats')} ({threatMap.threats.length})
              </Typography>
            </Grid>
            {threatMap.threats.map((threat) => (
              <Grid item xs={12} md={6} lg={4} key={threat.id}>
                <Card>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                      <Typography variant="h6">{threat.threat_type}</Typography>
                      <Chip
                        label={`${(threat.confidence * 100).toFixed(0)}%`}
                        sx={{
                          backgroundColor: getConfidenceColor(threat.confidence),
                          color: 'white',
                        }}
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {t('location')}: {threat.location.latitude.toFixed(4)}, {threat.location.longitude.toFixed(4)}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {t('detected_at')}: {formatDate(threat.timestamp)}
                    </Typography>
                    {threat.image_url && (
                      <Box sx={{ mt: 2 }}>
                        <img
                          src={threat.image_url}
                          alt={threat.threat_type}
                          style={{ width: '100%', maxHeight: '150px', objectFit: 'cover' }}
                        />
                      </Box>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}

        {/* Risk Score Calculator */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            {t('calculate_risk_score')}
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <Button
              variant="outlined"
              onClick={() => handleCalculateRisk(35.6892, 51.3890)}
            >
              {t('sample_location')}
            </Button>
          </Box>
          {riskScore && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body1">
                {t('risk_score')}: {riskScore.risk_score.toFixed(2)}
              </Typography>
              <Chip
                label={riskScore.risk_level}
                sx={{
                  backgroundColor: getRiskColor(riskScore.risk_level),
                  color: 'white',
                  mt: 1,
                }}
              />
              <Typography variant="body2" sx={{ mt: 1 }}>
                {t('risk_factors')}:
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                {riskScore.factors.map((factor, index) => (
                  <Chip key={index} label={factor} variant="outlined" size="small" />
                ))}
              </Box>
            </Box>
          )}
        </Paper>

        {/* Image Analysis Results Dialog */}
        <Dialog
          open={showResultsDialog}
          onClose={() => setShowResultsDialog(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>{t('analysis_results')}</DialogTitle>
          <DialogContent>
            {detectionResults.length > 0 ? (
              <Box>
                <Typography variant="body1" gutterBottom>
                  {t('threats_detected')}: {detectionResults.length}
                </Typography>
                {detectionResults.map((result, index) => (
                  <Card key={index} sx={{ mb: 2 }}>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="h6">{result.threat_type}</Typography>
                        <Chip
                          label={`${(result.confidence * 100).toFixed(0)}%`}
                          sx={{
                            backgroundColor: getConfidenceColor(result.confidence),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="body2">
                        {t('bounding_box')}: {result.bounding_box.x}, {result.bounding_box.y}, {result.bounding_box.width}x{result.bounding_box.height}
                      </Typography>
                    </CardContent>
                  </Card>
                ))}
              </Box>
            ) : (
              <Typography variant="body1">{t('no_threats_detected')}</Typography>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowResultsDialog(false)}>{t('close')}</Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default Threats;
