import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  Person as PersonIcon,
  Devices as DevicesIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon,
  TrendingUp as TrendingUpIcon,
  Security as SecurityIcon,
  School as SchoolIcon,
  Build as BuildIcon,
} from '@mui/icons-material';
import {
  communicationService,
  threatService,
  monitoringService,
  trainingService,
  operationsService,
  websocketService,
} from '../../services';

interface DashboardStats {
  activeUsers: number;
  connectedDevices: number;
  detectedThreats: number;
  activeAlerts: number;
  systemStatus: 'online' | 'offline' | 'degraded';
  trainingProgress: number;
  slaCompliance: number;
  pendingMaintenance: number;
}

const Dashboard: React.FC = () => {
  const { t } = useTranslation();
  const [stats, setStats] = useState<DashboardStats>({
    activeUsers: 0,
    connectedDevices: 0,
    detectedThreats: 0,
    activeAlerts: 0,
    systemStatus: 'online',
    trainingProgress: 0,
    slaCompliance: 0,
    pendingMaintenance: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboardData();
    connectWebSocket();
    
    // Refresh data every 30 seconds
    const interval = setInterval(loadDashboardData, 30000);
    
    return () => {
      clearInterval(interval);
      websocketService.disconnect();
    };
  }, []);

  const connectWebSocket = () => {
    try {
      websocketService.connect();
      websocketService.onAlertCreated(() => loadDashboardData());
      websocketService.onThreatDetected(() => loadDashboardData());
      websocketService.onDeviceStatusChange(() => loadDashboardData());
    } catch (err) {
      console.error('WebSocket connection error:', err);
    }
  };

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load data in parallel
      const [devices, threatMap, alerts, trainingStats, slaMetrics, maintenanceTasks] = await Promise.all([
        communicationService.getDevices().catch(() => []),
        threatService.getThreatMap().catch(() => ({ threats: [] })),
        monitoringService.getActiveAlerts().catch(() => []),
        trainingService.getStatistics().catch(() => ({ total_users: 0, completion_rate: 0 })),
        operationsService.getSLAMetrics().catch(() => []),
        operationsService.getMaintenanceTasks().catch(() => []),
      ]);

      setStats({
        activeUsers: trainingStats.total_users || 0,
        connectedDevices: devices.filter(d => d.status === 'connected').length,
        detectedThreats: threatMap.threats?.length || 0,
        activeAlerts: alerts.length,
        systemStatus: 'online',
        trainingProgress: Math.round(trainingStats.completion_rate * 100) || 0,
        slaCompliance: calculateSLACompliance(slaMetrics),
        pendingMaintenance: maintenanceTasks.filter(t => t.status === 'pending').length,
      });
    } catch (err) {
      setError('Failed to load dashboard data');
      console.error('Error loading dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const calculateSLACompliance = (metrics: any[]): number => {
    if (!metrics || metrics.length === 0) return 0;
    const compliant = metrics.filter(m => m.status === 'within_target').length;
    return Math.round((compliant / metrics.length) * 100);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return '#4caf50';
      case 'offline':
        return '#f44336';
      case 'degraded':
        return '#ff9800';
      default:
        return '#9e9e9e';
    }
  };

  const StatCard: React.FC<{
    title: string;
    value: number | string;
    icon: React.ReactNode;
    color: string;
    subtitle?: string;
  }> = ({ title, value, icon, color, subtitle }) => (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" component="div" sx={{ color }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="caption" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box sx={{ fontSize: 40, color }}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <Container maxWidth="xl">
        <Box sx={{ mt: 4, mb: 4, display: 'flex', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('dashboard')}
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('active_users')}
              value={stats.activeUsers}
              icon={<PersonIcon />}
              color="#2196f3"
              subtitle={t('total_users')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('connected_devices')}
              value={stats.connectedDevices}
              icon={<DevicesIcon />}
              color="#4caf50"
              subtitle={t('devices')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('detected_threats')}
              value={stats.detectedThreats}
              icon={<WarningIcon />}
              color="#f44336"
              subtitle={t('threats')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('active_alerts')}
              value={stats.activeAlerts}
              icon={<WarningIcon />}
              color="#ff9800"
              subtitle={t('alerts')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('system_status')}
              value={stats.systemStatus.toUpperCase()}
              icon={<CheckCircleIcon />}
              color={getStatusColor(stats.systemStatus)}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('training_progress')}
              value={`${stats.trainingProgress}%`}
              icon={<SchoolIcon />}
              color="#9c27b0"
              subtitle={t('completion_rate')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('sla_compliance')}
              value={`${stats.slaCompliance}%`}
              icon={<TrendingUpIcon />}
              color="#00bcd4"
              subtitle={t('service_level')}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={3}>
            <StatCard
              title={t('pending_maintenance')}
              value={stats.pendingMaintenance}
              icon={<BuildIcon />}
              color="#795548"
              subtitle={t('tasks')}
            />
          </Grid>
        </Grid>

        <Box sx={{ mt: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {t('quick_actions')}
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    {t('view_map')}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    {t('manage_devices')}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    {t('view_threats')}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    {t('security_routes')}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Container>
  );
};

export default Dashboard;
