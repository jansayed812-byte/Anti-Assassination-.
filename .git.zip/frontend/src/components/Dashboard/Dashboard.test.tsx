import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import Dashboard from './Dashboard';

// Mock the services
vi.mock('../../services', () => ({
  communicationService: {
    getDevices: vi.fn().mockResolvedValue([]),
  },
  threatService: {
    getThreatMap: vi.fn().mockResolvedValue({ threats: [] }),
  },
  monitoringService: {
    getActiveAlerts: vi.fn().mockResolvedValue([]),
  },
  trainingService: {
    getStatistics: vi.fn().mockResolvedValue({ total_users: 0, completion_rate: 0 }),
  },
  operationsService: {
    getSLAMetrics: vi.fn().mockResolvedValue([]),
    getMaintenanceTasks: vi.fn().mockResolvedValue([]),
  },
  websocketService: {
    connect: vi.fn(),
    disconnect: vi.fn(),
    onAlertCreated: vi.fn(),
    onThreatDetected: vi.fn(),
    onDeviceStatusChange: vi.fn(),
  },
}));

describe('Dashboard Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders dashboard title', () => {
    render(<Dashboard />);
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
  });

  it('displays loading state initially', () => {
    render(<Dashboard />);
    // Loading state should be shown
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('displays dashboard statistics after loading', async () => {
    render(<Dashboard />);
    
    await waitFor(() => {
      expect(screen.queryByRole('progressbar')).not.toBeInTheDocument();
    });

    // Check if stats cards are rendered
    expect(screen.getByText('Active Users')).toBeInTheDocument();
    expect(screen.getByText('Connected Devices')).toBeInTheDocument();
    expect(screen.getByText('Detected Threats')).toBeInTheDocument();
    expect(screen.getByText('Active Alerts')).toBeInTheDocument();
  });

  it('has refresh button', () => {
    render(<Dashboard />);
    expect(screen.getByText('Refresh')).toBeInTheDocument();
  });
});
