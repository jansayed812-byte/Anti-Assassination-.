import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Avatar,
} from '@mui/material';
import {
  School as SchoolIcon,
  PlayArrow as PlayIcon,
  CheckCircle as CheckIcon,
  TrendingUp as TrendingUpIcon,
  Refresh as RefreshIcon,
  Person as PersonIcon,
} from '@mui/icons-material';
import { trainingService, TrainingModule, TrainingPlan, TrainingProgress, TrainingStatistics } from '../../services';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const Training: React.FC = () => {
  const { t } = useTranslation();
  const [tabValue, setTabValue] = useState(0);
  const [modules, setModules] = useState<TrainingModule[]>([]);
  const [trainingPlans, setTrainingPlans] = useState<Record<string, TrainingPlan>>({});
  const [statistics, setStatistics] = useState<TrainingStatistics | null>(null);
  const [userProgress, setUserProgress] = useState<TrainingProgress | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedModule, setSelectedModule] = useState<TrainingModule | null>(null);
  const [showStartDialog, setShowStartDialog] = useState(false);

  useEffect(() => {
    loadTrainingData();
  }, [tabValue]);

  const loadTrainingData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [mods, stats] = await Promise.all([
        trainingService.getModules(),
        trainingService.getStatistics(),
      ]);

      setModules(mods);
      setStatistics(stats);

      // Load training plans for different roles
      const roles = ['operator', 'analyst', 'supervisor', 'admin', 'security_officer'];
      const plans: Record<string, TrainingPlan> = {};
      for (const role of roles) {
        try {
          const plan = await trainingService.getTrainingPlan(role);
          plans[role] = plan;
        } catch (err) {
          console.error(`Error loading plan for ${role}:`, err);
        }
      }
      setTrainingPlans(plans);
    } catch (err) {
      setError('Failed to load training data');
      console.error('Error loading training data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTraining = async (module: TrainingModule) => {
    try {
      setSelectedModule(module);
      setShowStartDialog(true);
    } catch (err) {
      setError('Failed to start training');
      console.error('Error starting training:', err);
    }
  };

  const handleConfirmStart = async () => {
    if (!selectedModule) return;

    try {
      setLoading(true);
      // Use a default user ID - in real app this would come from auth
      await trainingService.startTraining(1, selectedModule.id);
      setShowStartDialog(false);
      setSelectedModule(null);
      loadTrainingData();
    } catch (err) {
      setError('Failed to start training module');
      console.error('Error starting training:', err);
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return '#4caf50';
      case 'intermediate':
        return '#ff9800';
      case 'advanced':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('training')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            onClick={loadTrainingData}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ mb: 3 }}>
          <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)}>
            <Tab label={t('modules')} />
            <Tab label={t('training_plans')} />
            <Tab label={t('statistics')} />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              {modules.map((module) => (
                <Grid item xs={12} md={6} lg={4} key={module.id}>
                  <Card>
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                        <Avatar sx={{ bgcolor: getDifficultyColor(module.difficulty) }}>
                          <SchoolIcon />
                        </Avatar>
                        <Chip
                          label={module.difficulty}
                          sx={{
                            backgroundColor: getDifficultyColor(module.difficulty),
                            color: 'white',
                          }}
                        />
                      </Box>
                      <Typography variant="h6" gutterBottom>
                        {module.title}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {module.description}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {t('duration')}: {module.duration_minutes} {t('minutes')}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {t('category')}: {module.category}
                      </Typography>
                      <Box sx={{ mt: 2 }}>
                        <Button
                          variant="contained"
                          startIcon={<PlayIcon />}
                          onClick={() => handleStartTraining(module)}
                          fullWidth
                        >
                          {t('start_training')}
                        </Button>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            <Grid container spacing={3}>
              {Object.entries(trainingPlans).map(([role, plan]) => (
                <Grid item xs={12} md={6} key={role}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('role')}: {role}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('total_duration')}: {plan.total_duration} {t('minutes')}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {t('modules_count')}: {plan.modules.length}
                      </Typography>
                      <Box sx={{ mt: 2 }}>
                        <Typography variant="body2" gutterBottom>
                          {t('modules')}:
                        </Typography>
                        {plan.modules.map((module) => (
                          <Chip
                            key={module.id}
                            label={module.title}
                            variant="outlined"
                            size="small"
                            sx={{ mr: 1, mb: 1 }}
                          />
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </TabPanel>

          <TabPanel value={tabValue} index={2}>
            {statistics && (
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('total_users')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }}>
                        {statistics.total_users}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('active_trainings')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }}>
                        {statistics.active_trainings}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('completed_trainings')}
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1 }}>
                        {statistics.completed_trainings}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('completion_rate')}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                        <LinearProgress
                          variant="determinate"
                          value={statistics.completion_rate * 100}
                          sx={{ flexGrow: 1, mr: 1 }}
                        />
                        <Typography variant="h6">
                          {(statistics.completion_rate * 100).toFixed(0)}%
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    {t('by_role')}
                  </Typography>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>{t('role')}</TableCell>
                          <TableCell>{t('total')}</TableCell>
                          <TableCell>{t('completed')}</TableCell>
                          <TableCell>{t('in_progress')}</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {Object.entries(statistics.by_role).map(([role, data]) => (
                          <TableRow key={role}>
                            <TableCell>{role}</TableCell>
                            <TableCell>{data.total}</TableCell>
                            <TableCell>{data.completed}</TableCell>
                            <TableCell>{data.in_progress}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
              </Grid>
            )}
          </TabPanel>
        </Paper>

        {/* Start Training Dialog */}
        <Dialog open={showStartDialog} onClose={() => setShowStartDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('start_training_module')}</DialogTitle>
          <DialogContent>
            <Typography variant="body1" gutterBottom>
              {selectedModule?.title}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {selectedModule?.description}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              {t('duration')}: {selectedModule?.duration_minutes} {t('minutes')}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowStartDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleConfirmStart} variant="contained">
              {t('start')}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default Training;
