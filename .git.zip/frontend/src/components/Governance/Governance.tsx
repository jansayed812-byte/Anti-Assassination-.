import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
} from '@mui/material';
import {
  Gavel as GavelIcon,
  Description as DescriptionIcon,
  Assessment as AssessmentIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { governanceService, DataItem, ComplianceStatus, ComplianceFinding, QuarterlyReview } from '../../services';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const Governance: React.FC = () => {
  const { t } = useTranslation();
  const [tabValue, setTabValue] = useState(0);
  const [complianceStatus, setComplianceStatus] = useState<ComplianceStatus | null>(null);
  const [quarterlyReview, setQuarterlyReview] = useState<QuarterlyReview | null>(null);
  const [dataItems, setDataItems] = useState<DataItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showRegisterDialog, setShowRegisterDialog] = useState(false);
  const [newDataItem, setNewDataItem] = useState({
    data_class: '',
    retention_period: 365,
    owner: '',
  });

  useEffect(() => {
    loadGovernanceData();
  }, [tabValue]);

  const loadGovernanceData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [status, review] = await Promise.all([
        governanceService.getComplianceStatus(),
        governanceService.getQuarterlyReview(),
      ]);

      setComplianceStatus(status);
      setQuarterlyReview(review);
    } catch (err) {
      setError('Failed to load governance data');
      console.error('Error loading governance data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterDataItem = async () => {
    try {
      setLoading(true);
      await governanceService.registerDataItem(newDataItem);
      setShowRegisterDialog(false);
      setNewDataItem({ data_class: '', retention_period: 365, owner: '' });
      loadGovernanceData();
    } catch (err) {
      setError('Failed to register data item');
      console.error('Error registering data item:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCleanupExpiredData = async () => {
    try {
      setLoading(true);
      const result = await governanceService.cleanupExpiredData();
      alert(`Deleted ${result.deleted_count} expired data items`);
      loadGovernanceData();
    } catch (err) {
      setError('Failed to cleanup expired data');
      console.error('Error cleaning up data:', err);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return '#f44336';
      case 'medium':
        return '#ff9800';
      case 'low':
        return '#4caf50';
      default:
        return '#9e9e9e';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return '#f44336';
      case 'resolved':
        return '#4caf50';
      case 'mitigated':
        return '#ff9800';
      default:
        return '#9e9e9e';
    }
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {t('governance')}
        </Typography>

        <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            onClick={loadGovernanceData}
            disabled={loading}
            startIcon={<RefreshIcon />}
          >
            {t('refresh')}
          </Button>
          <Button
            variant="contained"
            onClick={() => setShowRegisterDialog(true)}
            startIcon={<DescriptionIcon />}
          >
            {t('register_data')}
          </Button>
          <Button
            variant="outlined"
            onClick={handleCleanupExpiredData}
            startIcon={<DeleteIcon />}
            color="error"
          >
            {t('cleanup_expired')}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
            <CircularProgress />
          </Box>
        )}

        <Paper sx={{ mb: 3 }}>
          <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)}>
            <Tab label={t('compliance_status')} />
            <Tab label={t('quarterly_review')} />
            <Tab label={t('data_lifecycle')} />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            {complianceStatus && (
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        {t('overall_compliance')}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                        <LinearProgress
                          variant="determinate"
                          value={complianceStatus.overall_compliance}
                          sx={{ flexGrow: 1, mr: 1 }}
                        />
                        <Typography variant="h6">
                          {complianceStatus.overall_compliance}%
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        ISO 27001
                      </Typography>
                      <Typography variant="h6" sx={{ mt: 1 }}>
                        {complianceStatus.iso_27001_compliance}%
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        NIST SP 800-53
                      </Typography>
                      <Typography variant="h6" sx={{ mt: 1 }}>
                        {complianceStatus.nist_compliance}%
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6} lg={3}>
                  <Card>
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        GDPR
                      </Typography>
                      <Typography variant="h6" sx={{ mt: 1 }}>
                        {complianceStatus.gdpr_compliance}%
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    {t('compliance_findings')}
                  </Typography>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>{t('control_id')}</TableCell>
                          <TableCell>{t('description')}</TableCell>
                          <TableCell>{t('severity')}</TableCell>
                          <TableCell>{t('status')}</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {complianceStatus.findings.map((finding) => (
                          <TableRow key={finding.id}>
                            <TableCell>{finding.control_id}</TableCell>
                            <TableCell>{finding.description}</TableCell>
                            <TableCell>
                              <Chip
                                label={finding.severity}
                                sx={{
                                  backgroundColor: getSeverityColor(finding.severity),
                                  color: 'white',
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={finding.status}
                                sx={{
                                  backgroundColor: getStatusColor(finding.status),
                                  color: 'white',
                                }}
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
              </Grid>
            )}
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            {quarterlyReview && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        {t('quarter')} {quarterlyReview.quarter} {quarterlyReview.year}
                      </Typography>
                      <Typography variant="body1" gutterBottom>
                        {t('compliance_score')}: {quarterlyReview.compliance_score}%
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {t('reviewed_by')}: {quarterlyReview.reviewed_by}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {t('review_date')}: {new Date(quarterlyReview.review_date).toLocaleString()}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    {t('recommendations')}
                  </Typography>
                  {quarterlyReview.recommendations.map((rec, index) => (
                    <Alert key={index} severity="info" sx={{ mb: 1 }}>
                      {rec}
                    </Alert>
                  ))}
                </Grid>
              </Grid>
            )}
          </TabPanel>

          <TabPanel value={tabValue} index={2}>
            <Typography variant="body1" color="text.secondary">
              {t('data_lifecycle_description')}
            </Typography>
          </TabPanel>
        </Paper>

        {/* Register Data Dialog */}
        <Dialog open={showRegisterDialog} onClose={() => setShowRegisterDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{t('register_data_item')}</DialogTitle>
          <DialogContent>
            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel>{t('data_class')}</InputLabel>
              <Select
                value={newDataItem.data_class}
                label={t('data_class')}
                onChange={(e) => setNewDataItem({ ...newDataItem, data_class: e.target.value })}
              >
                <MenuItem value="public">Public</MenuItem>
                <MenuItem value="internal">Internal</MenuItem>
                <MenuItem value="confidential">Confidential</MenuItem>
                <MenuItem value="restricted">Restricted</MenuItem>
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label={t('retention_period_days')}
              type="number"
              value={newDataItem.retention_period}
              onChange={(e) => setNewDataItem({ ...newDataItem, retention_period: parseInt(e.target.value) })}
              sx={{ mt: 2 }}
            />
            <TextField
              fullWidth
              label={t('owner')}
              value={newDataItem.owner}
              onChange={(e) => setNewDataItem({ ...newDataItem, owner: e.target.value })}
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowRegisterDialog(false)}>{t('cancel')}</Button>
            <Button onClick={handleRegisterDataItem} variant="contained">
              {t('register')}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default Governance;
