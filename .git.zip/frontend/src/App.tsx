import React from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Box,
  Container,
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Map as MapIcon,
  Warning as WarningIcon,
  Devices as DevicesIcon,
  Gavel as GavelIcon,
  School as SchoolIcon,
  Build as BuildIcon,
  Notifications as NotificationsIcon,
  Security as SecurityIcon,
  Menu as MenuIcon,
} from '@mui/icons-material';
import { useTranslation } from 'react-i18next';
import Dashboard from './components/Dashboard/Dashboard';
import Map from './components/Map/Map';
import Threats from './components/Threats/Threats';
import Devices from './components/Devices/Devices';
import Governance from './components/Governance/Governance';
import Training from './components/Training/Training';
import Operations from './components/Operations/Operations';
import Monitoring from './components/Monitoring/Monitoring';
import AdvancedSecurity from './components/AdvancedSecurity/AdvancedSecurity';

const theme = createTheme({
  direction: 'rtl',
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

const drawerWidth = 240;

const navigationItems = [
  { path: '/', label: 'dashboard', icon: <DashboardIcon /> },
  { path: '/map', label: 'map', icon: <MapIcon /> },
  { path: '/threats', label: 'threats', icon: <WarningIcon /> },
  { path: '/devices', label: 'devices', icon: <DevicesIcon /> },
  { path: '/governance', label: 'governance', icon: <GavelIcon /> },
  { path: '/training', label: 'training', icon: <SchoolIcon /> },
  { path: '/operations', label: 'operations', icon: <BuildIcon /> },
  { path: '/monitoring', label: 'monitoring', icon: <NotificationsIcon /> },
  { path: '/advanced-security', label: 'advanced_security', icon: <SecurityIcon /> },
];

function AppContent() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <div>
      <Toolbar />
      <List>
        {navigationItems.map((item) => (
          <ListItem
            button
            key={item.path}
            onClick={() => {
              navigate(item.path);
              setMobileOpen(false);
            }}
            selected={location.pathname === item.path}
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={t(item.label)} />
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
      >
        <Toolbar>
          <Button
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </Button>
          <Typography variant="h6" noWrap component="div">
            {t('app_title')}
          </Typography>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
        }}
      >
        <Toolbar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/map" element={<Map />} />
          <Route path="/threats" element={<Threats />} />
          <Route path="/devices" element={<Devices />} />
          <Route path="/governance" element={<Governance />} />
          <Route path="/training" element={<Training />} />
          <Route path="/operations" element={<Operations />} />
          <Route path="/monitoring" element={<Monitoring />} />
          <Route path="/advanced-security" element={<AdvancedSecurity />} />
        </Routes>
      </Box>
    </Box>
  );
}

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppContent />
      </Router>
    </ThemeProvider>
  );
}

export default App;
