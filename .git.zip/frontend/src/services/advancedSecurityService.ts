import api from './api';

export interface EncryptionKey {
  id: string;
  name: string;
  algorithm: string;
  key_size: number;
  created_at: string;
  expires_at: string;
  status: 'active' | 'expired' | 'revoked';
  last_rotated: string;
}

export interface EncryptedData {
  encrypted_data: string;
  key_id: string;
  algorithm: string;
  iv: string;
}

export interface SecurityScanResult {
  scan_id: string;
  timestamp: string;
  vulnerabilities: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  findings: SecurityFinding[];
  overall_score: number;
}

export interface SecurityFinding {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  category: string;
  description: string;
  recommendation: string;
  affected_components: string[];
}

export const advancedSecurityService = {
  async encryptData(data: string, keyId?: string): Promise<EncryptedData> {
    const response = await api.post<EncryptedData>('/api/advanced-security/encrypt', {
      data,
      key_id: keyId,
    });
    return response.data;
  },

  async decryptData(encryptedData: string, keyId: string, iv: string): Promise<string> {
    const response = await api.post<{ decrypted_data: string }>('/api/advanced-security/decrypt', {
      encrypted_data: encryptedData,
      key_id: keyId,
      iv,
    });
    return response.data.decrypted_data;
  },

  async rotateKey(keyId: string): Promise<EncryptionKey> {
    const response = await api.post<EncryptionKey>('/api/advanced-security/keys/rotate', {
      key_id: keyId,
    });
    return response.data;
  },

  async getKeys(): Promise<EncryptionKey[]> {
    const response = await api.get<EncryptionKey[]>('/api/advanced-security/keys');
    return response.data;
  },

  async performSecurityScan(): Promise<SecurityScanResult> {
    const response = await api.get<SecurityScanResult>('/api/advanced-security/security-scan');
    return response.data;
  },
};
