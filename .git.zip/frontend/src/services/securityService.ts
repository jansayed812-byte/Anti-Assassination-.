import api from './api';

export interface RoutePoint {
  latitude: number;
  longitude: number;
  altitude?: number;
}

export interface SecurityRoute {
  route: RoutePoint[];
  total_distance: number;
  estimated_time: number;
  risk_level: string;
  waypoints: RoutePoint[];
}

export interface EscortPlan {
  id: number;
  name: string;
  route: RoutePoint[];
  start_time: string;
  end_time: string;
  security_level: string;
  team_size: number;
  status: 'planned' | 'active' | 'completed' | 'cancelled';
}

export interface RouteRequest {
  start: RoutePoint;
  end: RoutePoint;
  risk_tolerance?: 'low' | 'medium' | 'high';
}

export const securityService = {
  async calculateRoute(request: RouteRequest): Promise<SecurityRoute> {
    const response = await api.post<SecurityRoute>('/api/security/route', request);
    return response.data;
  },

  async createEscortPlan(planData: Partial<EscortPlan>): Promise<EscortPlan> {
    const response = await api.post<EscortPlan>('/api/security/escort-plan', planData);
    return response.data;
  },

  async getEscortPlan(planId: number): Promise<EscortPlan> {
    const response = await api.get<EscortPlan>(`/api/security/escort-plan/${planId}`);
    return response.data;
  },
};
