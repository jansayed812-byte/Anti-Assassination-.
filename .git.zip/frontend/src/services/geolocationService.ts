import api from './api';

export interface Position {
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy: number;
  timestamp: number;
  source: string;
}

export interface PositionHistory {
  positions: Position[];
  total: number;
}

export interface SourceStatus {
  source: string;
  status: 'active' | 'inactive' | 'error';
  last_update: string;
  accuracy: number;
}

export const geolocationService = {
  async start(): Promise<void> {
    await api.post('/api/geolocation/start');
  },

  async stop(): Promise<void> {
    await api.post('/api/geolocation/stop');
  },

  async getCurrentPosition(): Promise<Position> {
    const response = await api.get<Position>('/api/geolocation/current');
    return response.data;
  },

  async getHistory(limit: number = 100): Promise<PositionHistory> {
    const response = await api.get<PositionHistory>('/api/geolocation/history', {
      params: { limit },
    });
    return response.data;
  },

  async getSourceStatus(): Promise<SourceStatus[]> {
    const response = await api.get<SourceStatus[]>('/api/geolocation/sources');
    return response.data;
  },
};
