import api from './api';

export interface ThreatDetection {
  id: number;
  threat_type: string;
  confidence: number;
  bounding_box: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  location: {
    latitude: number;
    longitude: number;
  };
  timestamp: number;
  image_url?: string;
}

export interface ThreatMap {
  threats: ThreatDetection[];
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  updated_at: string;
}

export interface RiskScore {
  location: {
    latitude: number;
    longitude: number;
  };
  risk_score: number;
  risk_level: string;
  factors: string[];
}

export const threatService = {
  async startAnalysis(): Promise<void> {
    await api.post('/api/threat/start');
  },

  async detectThreatInImage(imageFile: File): Promise<ThreatDetection[]> {
    const formData = new FormData();
    formData.append('file', imageFile);
    
    const response = await api.post<ThreatDetection[]>('/api/threat/detect/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  async getThreatMap(): Promise<ThreatMap> {
    const response = await api.get<ThreatMap>('/api/threat/map');
    return response.data;
  },

  async calculateRiskScore(latitude: number, longitude: number): Promise<RiskScore> {
    const response = await api.post<RiskScore>('/api/threat/risk-score', {
      location: { latitude, longitude },
    });
    return response.data;
  },
};
