import api from './api';

export interface SLAMetric {
  id: string;
  name: string;
  target: number;
  current: number;
  unit: string;
  status: 'within_target' | 'warning' | 'breached';
  last_measured: string;
}

export interface SLAViolation {
  id: string;
  metric_id: string;
  violation_time: string;
  severity: 'minor' | 'major' | 'critical';
  description: string;
  resolved: boolean;
  resolution_time?: string;
}

export interface MaintenanceTask {
  id: number;
  title: string;
  description: string;
  scheduled_date: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  assigned_to: string;
  estimated_duration: number;
}

export interface MaintenanceCalendar {
  month: number;
  year: number;
  tasks: MaintenanceTask[];
  completed_count: number;
  pending_count: number;
}

export const operationsService = {
  async getSLAMetrics(): Promise<SLAMetric[]> {
    const response = await api.get<SLAMetric[]>('/api/operations/sla/metrics');
    return response.data;
  },

  async recordSLAMeasurement(metricId: string, value: number): Promise<void> {
    await api.post('/api/operations/sla/measure', {
      metric_id: metricId,
      value,
    });
  },

  async getSLAViolations(): Promise<SLAViolation[]> {
    const response = await api.get<SLAViolation[]>('/api/operations/sla/violations');
    return response.data;
  },

  async getMaintenanceTasks(): Promise<MaintenanceTask[]> {
    const response = await api.get<MaintenanceTask[]>('/api/operations/maintenance/tasks');
    return response.data;
  },

  async completeMaintenanceTask(taskId: number): Promise<void> {
    await api.post(`/api/operations/maintenance/complete/${taskId}`);
  },

  async getMaintenanceCalendar(month?: number, year?: number): Promise<MaintenanceCalendar> {
    const params: any = {};
    if (month) params.month = month;
    if (year) params.year = year;
    
    const response = await api.get<MaintenanceCalendar>('/api/operations/maintenance/calendar', { params });
    return response.data;
  },
};
