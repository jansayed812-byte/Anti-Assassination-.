import { describe, it, expect } from 'vitest';
import { authService } from './authService';

describe('Auth Service', () => {
  it('has login method', () => {
    expect(typeof authService.login).toBe('function');
  });

  it('has register method', () => {
    expect(typeof authService.register).toBe('function');
  });

  it('has getCurrentUser method', () => {
    expect(typeof authService.getCurrentUser).toBe('function');
  });

  it('has logout method', () => {
    expect(typeof authService.logout).toBe('function');
  });

  it('has isAuthenticated method', () => {
    expect(typeof authService.isAuthenticated).toBe('function');
  });
});
