import api from './api';

export interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  source: string;
  created_at: string;
  acknowledged: boolean;
  acknowledged_by?: string;
  acknowledged_at?: string;
  resolved: boolean;
  resolved_at?: string;
  resolved_by?: string;
  metadata?: Record<string, any>;
}

export interface AlertStatistics {
  total_alerts: number;
  active_alerts: number;
  resolved_alerts: number;
  acknowledged_alerts: number;
  by_severity: Record<string, number>;
  by_source: Record<string, number>;
  average_resolution_time: number;
}

export const monitoringService = {
  async createAlert(alert: Partial<Alert>): Promise<Alert> {
    const response = await api.post<Alert>('/api/monitoring/alerts', alert);
    return response.data;
  },

  async getActiveAlerts(): Promise<Alert[]> {
    const response = await api.get<Alert[]>('/api/monitoring/alerts/active');
    return response.data;
  },

  async acknowledgeAlert(alertId: string): Promise<void> {
    await api.post(`/api/monitoring/alerts/${alertId}/acknowledge`);
  },

  async resolveAlert(alertId: string): Promise<void> {
    await api.post(`/api/monitoring/alerts/${alertId}/resolve`);
  },

  async getStatistics(): Promise<AlertStatistics> {
    const response = await api.get<AlertStatistics>('/api/monitoring/alerts/statistics');
    return response.data;
  },

  async checkAlertRules(): Promise<{ triggered: number }> {
    const response = await api.post<{ triggered: number }>('/api/monitoring/alerts/check-rules');
    return response.data;
  },
};
