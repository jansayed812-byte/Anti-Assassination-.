import api from './api';

export interface TrackingStatus {
  user_id: number;
  is_tracking: boolean;
  last_position?: {
    latitude: number;
    longitude: number;
    timestamp: number;
  };
  start_time?: string;
}

export interface PositionUpdate {
  user_id: number;
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy: number;
  timestamp: number;
}

export const trackingService = {
  async startTracking(userId: number): Promise<void> {
    await api.post(`/api/tracking/start/${userId}`);
  },

  async stopTracking(userId: number): Promise<void> {
    await api.post(`/api/tracking/stop/${userId}`);
  },

  async updatePosition(data: PositionUpdate): Promise<void> {
    await api.post('/api/tracking/update', data);
  },

  async getTrackingStatus(userId: number): Promise<TrackingStatus> {
    const response = await api.get<TrackingStatus>(`/api/tracking/status/${userId}`);
    return response.data;
  },

  // WebSocket connection for real-time updates
  connectWebSocket(userId: number): WebSocket {
    const token = localStorage.getItem('access_token');
    const wsUrl = `ws://localhost:8000/api/tracking/ws/${userId}?token=${token}`;
    return new WebSocket(wsUrl);
  },
};
