import api from './api';

export interface Device {
  id: number;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error';
  last_seen: string;
  capabilities: string[];
}

export interface DeviceCommand {
  device_id: number;
  command: string;
  parameters?: Record<string, any>;
}

export const communicationService = {
  async startService(): Promise<void> {
    await api.post('/api/communication/start');
  },

  async connectDevice(deviceType: string, connectionString: string): Promise<Device> {
    const response = await api.post<Device>('/api/communication/connect', {
      device_type: deviceType,
      connection_string: connectionString,
    });
    return response.data;
  },

  async getDevices(): Promise<Device[]> {
    const response = await api.get<Device[]>('/api/communication/devices');
    return response.data;
  },

  async sendCommand(command: DeviceCommand): Promise<any> {
    const response = await api.post(`/api/communication/command/${command.device_id}`, command);
    return response.data;
  },
};
