import { io, Socket } from 'socket.io-client';

const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:8000';

class WebSocketService {
  private socket: Socket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;

  connect(userId?: number): Socket {
    if (this.socket?.connected) {
      return this.socket;
    }

    const token = localStorage.getItem('access_token');
    
    this.socket = io(WS_URL, {
      auth: {
        token,
        user_id: userId,
      },
      reconnection: true,
      reconnectionDelay: this.reconnectDelay,
      reconnectionAttempts: this.maxReconnectAttempts,
    });

    this.socket.on('connect', () => {
      console.log('WebSocket connected');
      this.reconnectAttempts = 0;
    });

    this.socket.on('disconnect', (reason) => {
      console.log('WebSocket disconnected:', reason);
    });

    this.socket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
      this.reconnectAttempts++;
      
      if (this.reconnectAttempts >= this.maxReconnectAttempts) {
        console.error('Max reconnection attempts reached');
      }
    });

    return this.socket;
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  on(event: string, callback: (...args: any[]) => void): void {
    this.socket?.on(event, callback);
  }

  off(event: string, callback?: (...args: any[]) => void): void {
    this.socket?.off(event, callback);
  }

  emit(event: string, data?: any): void {
    this.socket?.emit(event, data);
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }

  // Specific event listeners for the application
  onPositionUpdate(callback: (data: any) => void): void {
    this.on('position_update', callback);
  }

  onThreatDetected(callback: (data: any) => void): void {
    this.on('threat_detected', callback);
  }

  onDeviceStatusChange(callback: (data: any) => void): void {
    this.on('device_status_change', callback);
  }

  onAlertCreated(callback: (data: any) => void): void {
    this.on('alert_created', callback);
  }

  onSLAViolation(callback: (data: any) => void): void {
    this.on('sla_violation', callback);
  }
}

export const websocketService = new WebSocketService();
