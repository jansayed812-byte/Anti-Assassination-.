import { describe, it, expect } from 'vitest';
import api from './api';

describe('API Service', () => {
  it('creates axios instance with correct base URL', () => {
    expect(api.defaults.baseURL).toBeDefined();
    expect(api.defaults.headers['Content-Type']).toBe('application/json');
  });

  it('has request interceptor configured', () => {
    expect(api.interceptors.request.handlers).toBeDefined();
    expect(api.interceptors.request.handlers.length).toBeGreaterThan(0);
  });

  it('has response interceptor configured', () => {
    expect(api.interceptors.response.handlers).toBeDefined();
    expect(api.interceptors.response.handlers.length).toBeGreaterThan(0);
  });
});
