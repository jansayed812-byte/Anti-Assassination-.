export { authService } from './authService';
export { geolocationService } from './geolocationService';
export { trackingService } from './trackingService';
export { threatService } from './threatService';
export { communicationService } from './communicationService';
export { securityService } from './securityService';
export { governanceService } from './governanceService';
export { trainingService } from './trainingService';
export { operationsService } from './operationsService';
export { monitoringService } from './monitoringService';
export { advancedSecurityService } from './advancedSecurityService';
export { websocketService } from './websocketService';

export type {
  LoginCredentials,
  RegisterData,
  User,
  AuthResponse,
} from './authService';

export type {
  Position,
  PositionHistory,
  SourceStatus,
} from './geolocationService';

export type {
  TrackingStatus,
  PositionUpdate,
} from './trackingService';

export type {
  ThreatDetection,
  ThreatMap,
  RiskScore,
} from './threatService';

export type {
  Device,
  DeviceCommand,
} from './communicationService';

export type {
  RoutePoint,
  SecurityRoute,
  EscortPlan,
  RouteRequest,
} from './securityService';

export type {
  DataItem,
  ComplianceStatus,
  ComplianceFinding,
  QuarterlyReview,
} from './governanceService';

export type {
  TrainingModule,
  TrainingPlan,
  TrainingProgress,
  TrainingStatistics,
} from './trainingService';

export type {
  SLAMetric,
  SLAViolation,
  MaintenanceTask,
  MaintenanceCalendar,
} from './operationsService';

export type {
  Alert,
  AlertStatistics,
} from './monitoringService';

export type {
  EncryptionKey,
  EncryptedData,
  SecurityScanResult,
  SecurityFinding,
} from './advancedSecurityService';
