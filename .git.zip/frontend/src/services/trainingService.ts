import api from './api';

export interface TrainingModule {
  id: number;
  title: string;
  description: string;
  category: string;
  duration_minutes: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  prerequisites: string[];
}

export interface TrainingPlan {
  role: string;
  modules: TrainingModule[];
  total_duration: number;
  required_for_role: boolean;
}

export interface TrainingProgress {
  user_id: number;
  completed_modules: number;
  total_modules: number;
  current_module?: TrainingModule;
  progress_percentage: number;
  last_activity: string;
  certifications: string[];
}

export interface TrainingStatistics {
  total_users: number;
  active_trainings: number;
  completed_trainings: number;
  average_completion_time: number;
  completion_rate: number;
  by_role: Record<string, {
    total: number;
    completed: number;
    in_progress: number;
  }>;
}

export const trainingService = {
  async getModules(): Promise<TrainingModule[]> {
    const response = await api.get<TrainingModule[]>('/api/training/modules');
    return response.data;
  },

  async getTrainingPlan(role: string): Promise<TrainingPlan> {
    const response = await api.get<TrainingPlan>(`/api/training/plans/role/${role}`);
    return response.data;
  },

  async startTraining(userId: number, moduleId: number): Promise<void> {
    await api.post('/api/training/start', {
      user_id: userId,
      module_id: moduleId,
    });
  },

  async completeTraining(userId: number, moduleId: number, score: number): Promise<void> {
    await api.post('/api/training/complete', {
      user_id: userId,
      module_id: moduleId,
      score,
    });
  },

  async getProgress(userId: number): Promise<TrainingProgress> {
    const response = await api.get<TrainingProgress>(`/api/training/progress/${userId}`);
    return response.data;
  },

  async getStatistics(): Promise<TrainingStatistics> {
    const response = await api.get<TrainingStatistics>('/api/training/statistics');
    return response.data;
  },
};
