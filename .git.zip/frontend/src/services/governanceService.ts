import api from './api';

export interface DataItem {
  id: string;
  data_class: string;
  retention_period: number;
  created_at: string;
  expires_at: string;
  owner: string;
  status: 'active' | 'expired' | 'archived';
}

export interface ComplianceStatus {
  overall_compliance: number;
  iso_27001_compliance: number;
  nist_compliance: number;
  gdpr_compliance: number;
  last_audit: string;
  next_audit: string;
  findings: ComplianceFinding[];
}

export interface ComplianceFinding {
  id: string;
  severity: 'high' | 'medium' | 'low';
  description: string;
  control_id: string;
  status: 'open' | 'resolved' | 'mitigated';
}

export interface QuarterlyReview {
  quarter: string;
  year: number;
  compliance_score: number;
  findings: ComplianceFinding[];
  recommendations: string[];
  reviewed_by: string;
  review_date: string;
}

export const governanceService = {
  async registerDataItem(data: Partial<DataItem>): Promise<DataItem> {
    const response = await api.post<DataItem>('/api/governance/data/register', data);
    return response.data;
  },

  async getDataItem(dataId: string): Promise<DataItem> {
    const response = await api.get<DataItem>(`/api/governance/data/${dataId}`);
    return response.data;
  },

  async cleanupExpiredData(): Promise<{ deleted_count: number }> {
    const response = await api.post<{ deleted_count: number }>('/api/governance/data/cleanup');
    return response.data;
  },

  async getComplianceStatus(): Promise<ComplianceStatus> {
    const response = await api.get<ComplianceStatus>('/api/governance/data/compliance');
    return response.data;
  },

  async getQuarterlyReview(): Promise<QuarterlyReview> {
    const response = await api.get<QuarterlyReview>('/api/governance/compliance/quarterly-review');
    return response.data;
  },

  async getComplianceReport(): Promise<any> {
    const response = await api.get('/api/governance/compliance/report');
    return response.data;
  },
};
