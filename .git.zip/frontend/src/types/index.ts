export interface Position {
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy?: number;
  speed?: number;
  heading?: number;
  timestamp: string;
}

export interface Device {
  id: string;
  device_type: string;
  name: string;
  status: 'online' | 'offline' | 'error';
  battery_level?: number;
  last_seen?: string;
}

export interface Threat {
  id: string;
  location: Position;
  threat_type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  timestamp: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
  is_admin: boolean;
}
