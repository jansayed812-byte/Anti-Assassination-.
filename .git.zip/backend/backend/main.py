from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import engine, Base
from app.api import auth, geolocation, tracking, threat, communication, security, governance, training, operations, monitoring, advanced_security, v1
from app.websocket import v1_websocket
from app.services.geolocation.geolocation_service import geolocation_service
from app.services.tracking.tracking_service import tracking_service
from app.services.threat.threat_service import threat_analysis_service
from app.services.communication.device_manager import device_manager
from app.services.security.routing_service import routing_service
from app.websocket.v1_streams import telemetry_stream, risk_stream, alert_stream

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    debug=settings.DEBUG
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(geolocation.router, prefix="/api/geolocation", tags=["Geolocation"])
app.include_router(tracking.router, prefix="/api/tracking", tags=["Tracking"])
app.include_router(threat.router, prefix="/api/threat", tags=["Threat Analysis"])
app.include_router(communication.router, prefix="/api/communication", tags=["Communication"])
app.include_router(security.router, prefix="/api/security", tags=["Security Protocols"])
app.include_router(governance.router, prefix="/api/governance", tags=["Data Governance"])
app.include_router(training.router, prefix="/api/training", tags=["Training"])
app.include_router(operations.router, prefix="/api/operations", tags=["Operations"])
app.include_router(monitoring.router, prefix="/api/monitoring", tags=["Monitoring"])
app.include_router(advanced_security.router, prefix="/api/advanced-security", tags=["Advanced Security"])
app.include_router(v1.router, prefix="/api", tags=["v1"])
app.include_router(v1_websocket.router, prefix="/api/v1", tags=["WebSocket"])


@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    # Start geolocation service
    geolocation_service.start()
    
    # Start tracking service
    tracking_service.start_service()
    
    # Start threat analysis service (optional, may require model download)
    try:
        threat_analysis_service.start()
    except Exception as e:
        print(f"Warning: Could not start threat analysis service: {e}")
    
    # Start device manager
    try:
        device_manager.start()
    except Exception as e:
        print(f"Warning: Could not start device manager: {e}")
    
    # Initialize routing service with sample network
    try:
        routing_service.generate_sample_network()
        print("Routing service initialized with sample network")
    except Exception as e:
        print(f"Warning: Could not initialize routing service: {e}")
    
    print("Services started successfully")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup services on shutdown."""
    # Stop geolocation service
    geolocation_service.stop()
    
    # Stop tracking service
    tracking_service.stop_service()
    
    # Stop threat analysis service
    threat_analysis_service.stop()
    
    # Stop device manager
    device_manager.stop()
    
    print("Services stopped successfully")


@app.get("/")
async def root():
    return {
        "message": "Security Assessment System API",
        "version": settings.APP_VERSION,
        "status": "running"
    }


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
