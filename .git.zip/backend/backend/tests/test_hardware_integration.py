import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


@pytest.mark.hardware
def test_mavlink_connection():
    """Test MAVLink connection for drone communication."""
    response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "mavlink",
            "connection_string": "udp:127.0.0.1:14550"
        }
    )
    # Hardware may not be available
    assert response.status_code in [200, 400, 500]


@pytest.mark.hardware
def test_serial_device_connection():
    """Test serial device connection."""
    response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "serial",
            "connection_string": "/dev/ttyUSB0:9600"
        }
    )
    # Hardware may not be available
    assert response.status_code in [200, 400, 500]


@pytest.mark.hardware
def test_gps_sensor_reading():
    """Test GPS sensor reading."""
    response = client.get("/api/geolocation/current")
    # GPS may not be available
    assert response.status_code in [200, 404, 401]


@pytest.mark.hardware
def test_network_device_connection():
    """Test network device connection."""
    response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "network",
            "connection_string": "192.168.1.100:8080"
        }
    )
    # Network device may not be available
    assert response.status_code in [200, 400, 500]


@pytest.mark.hardware
def test_bluetooth_device_connection():
    """Test Bluetooth device connection."""
    response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "bluetooth",
            "connection_string": "00:11:22:33:44:55"
        }
    )
    # Bluetooth device may not be available
    assert response.status_code in [200, 400, 500]


@pytest.mark.hardware
def test_sensor_fusion():
    """Test sensor fusion from multiple sources."""
    # Start geolocation to enable sensor fusion
    client.post("/api/geolocation/start")
    
    response = client.get("/api/geolocation/sources")
    # Should return status of various sensors
    assert response.status_code in [200, 401]


@pytest.mark.hardware
def test_drone_command_execution():
    """Test sending commands to drone."""
    # First connect to a drone (may fail if no hardware)
    connect_response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "mavlink",
            "connection_string": "udp:127.0.0.1:14550"
        }
    )
    
    if connect_response.status_code == 200:
        # Try to send a command
        command_response = client.post(
            "/api/communication/command/1",
            json={
                "command": "ARM",
                "parameters": {}
            }
        )
        # Command may fail if drone not ready
        assert command_response.status_code in [200, 400, 404, 500]
    else:
        # Hardware not available, which is acceptable for integration tests
        assert True


@pytest.mark.hardware
def test_camera_integration():
    """Test camera integration for threat detection."""
    # Start threat analysis
    client.post("/api/threat/start")
    
    # Try to detect threat (will fail if no camera)
    response = client.post(
        "/api/threat/detect/image",
        files={"file": ("test.jpg", b"fake image data", "image/jpeg")}
    )
    # Camera/ML may not be available
    assert response.status_code in [200, 400, 401, 500]
