import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_start_communication_service():
    """Test starting communication service."""
    response = client.post("/api/communication/start")
    # Service may already be running or not configured
    assert response.status_code in [200, 400, 500]


def test_get_devices():
    """Test getting device list."""
    response = client.get("/api/communication/devices")
    # Should return empty list or devices if configured
    assert response.status_code in [200, 401]


def test_connect_device():
    """Test connecting a device."""
    response = client.post(
        "/api/communication/connect",
        json={
            "device_type": "mavlink",
            "connection_string": "/dev/ttyUSB0:57600"
        }
    )
    # Will fail if hardware not available, but tests endpoint structure
    assert response.status_code in [200, 400, 401, 500]


def test_send_command():
    """Test sending command to device."""
    response = client.post(
        "/api/communication/command/1",
        json={
            "command": "ARM",
            "parameters": {}
        }
    )
    # Will fail if device doesn't exist, but tests endpoint structure
    assert response.status_code in [200, 404, 401, 500]
