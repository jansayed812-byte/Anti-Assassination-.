import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_start_geolocation():
    """Test starting geolocation service."""
    response = client.post("/api/geolocation/start")
    # Service may already be running
    assert response.status_code in [200, 400, 500]


def test_stop_geolocation():
    """Test stopping geolocation service."""
    response = client.post("/api/geolocation/stop")
    assert response.status_code in [200, 400, 500]


def test_get_current_position():
    """Test getting current position."""
    response = client.get("/api/geolocation/current")
    # May return 404 if no position available
    assert response.status_code in [200, 404, 401]


def test_get_position_history():
    """Test getting position history."""
    response = client.get("/api/geolocation/history")
    assert response.status_code in [200, 401]


def test_get_source_status():
    """Test getting source status."""
    response = client.get("/api/geolocation/sources")
    assert response.status_code in [200, 401]
