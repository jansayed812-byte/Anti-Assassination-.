import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


@pytest.mark.integration
def test_complete_user_flow():
    """Test complete user flow from registration to dashboard access."""
    
    # 1. Register a new user
    register_response = client.post(
        "/api/auth/register",
        json={
            "username": "e2e_test_user",
            "email": "e2e_test@example.com",
            "password": "testpass123"
        }
    )
    # User may already exist
    assert register_response.status_code in [200, 400]
    
    # 2. Login
    login_response = client.post(
        "/api/auth/login",
        data={
            "username": "e2e_test_user",
            "password": "testpass123"
        }
    )
    if login_response.status_code == 200:
        token = login_response.json().get("access_token")
        assert token is not None
        
        # 3. Access protected endpoint with token
        headers = {"Authorization": f"Bearer {token}"}
        me_response = client.get("/api/auth/me", headers=headers)
        assert me_response.status_code in [200, 401]
    else:
        # Login may fail if user doesn't exist, but flow is tested
        assert login_response.status_code in [401, 422]


@pytest.mark.integration
def test_geolocation_flow():
    """Test complete geolocation service flow."""
    
    # 1. Start geolocation service
    start_response = client.post("/api/geolocation/start")
    assert start_response.status_code in [200, 400, 500]
    
    # 2. Check source status
    sources_response = client.get("/api/geolocation/sources")
    assert sources_response.status_code in [200, 401]
    
    # 3. Try to get current position
    position_response = client.get("/api/geolocation/current")
    assert position_response.status_code in [200, 404, 401]
    
    # 4. Get position history
    history_response = client.get("/api/geolocation/history")
    assert history_response.status_code in [200, 401]
    
    # 5. Stop geolocation service
    stop_response = client.post("/api/geolocation/stop")
    assert stop_response.status_code in [200, 400, 500]


@pytest.mark.integration
def test_tracking_flow():
    """Test complete tracking service flow."""
    
    # 1. Start tracking for a user
    start_response = client.post("/api/tracking/start/1")
    assert start_response.status_code in [200, 400, 404, 500]
    
    # 2. Check tracking status
    status_response = client.get("/api/tracking/status/1")
    assert status_response.status_code in [200, 404, 401]
    
    # 3. Update position
    update_response = client.post(
        "/api/tracking/update",
        json={
            "user_id": 1,
            "latitude": 35.6892,
            "longitude": 51.3890,
            "accuracy": 10.0,
            "timestamp": 1234567890
        }
    )
    assert update_response.status_code in [200, 400, 401]
    
    # 4. Stop tracking
    stop_response = client.post("/api/tracking/stop/1")
    assert stop_response.status_code in [200, 400, 404, 500]


@pytest.mark.integration
def test_threat_analysis_flow():
    """Test complete threat analysis flow."""
    
    # 1. Start threat analysis
    start_response = client.post("/api/threat/start")
    assert start_response.status_code in [200, 400, 500]
    
    # 2. Get threat map
    map_response = client.get("/api/threat/map")
    assert map_response.status_code in [200, 401]
    
    # 3. Calculate risk score
    risk_response = client.post(
        "/api/threat/risk-score",
        json={
            "location": {
                "latitude": 35.6892,
                "longitude": 51.3890
            }
        }
    )
    assert risk_response.status_code in [200, 400, 401, 500]


@pytest.mark.integration
def test_governance_flow():
    """Test complete governance flow."""
    
    # 1. Register data item
    register_response = client.post(
        "/api/governance/data/register",
        json={
            "data_class": "confidential",
            "retention_period": 365,
            "owner": "test_user"
        }
    )
    assert register_response.status_code in [200, 400, 401]
    
    # 2. Get compliance status
    compliance_response = client.get("/api/governance/data/compliance")
    assert compliance_response.status_code in [200, 401]
    
    # 3. Get quarterly review
    review_response = client.get("/api/governance/compliance/quarterly-review")
    assert review_response.status_code in [200, 401]
    
    # 4. Get compliance report
    report_response = client.get("/api/governance/compliance/report")
    assert report_response.status_code in [200, 401]


@pytest.mark.integration
def test_training_flow():
    """Test complete training flow."""
    
    # 1. Get training modules
    modules_response = client.get("/api/training/modules")
    assert modules_response.status_code in [200, 401]
    
    # 2. Get training plan for a role
    plan_response = client.get("/api/training/plans/role/operator")
    assert plan_response.status_code in [200, 401]
    
    # 3. Get training statistics
    stats_response = client.get("/api/training/statistics")
    assert stats_response.status_code in [200, 401]
    
    # 4. Get user progress
    progress_response = client.get("/api/training/progress/1")
    assert progress_response.status_code in [200, 404, 401]


@pytest.mark.integration
def test_operations_flow():
    """Test complete operations flow."""
    
    # 1. Get SLA metrics
    sla_response = client.get("/api/operations/sla/metrics")
    assert sla_response.status_code in [200, 401]
    
    # 2. Get SLA violations
    violations_response = client.get("/api/operations/sla/violations")
    assert violations_response.status_code in [200, 401]
    
    # 3. Get maintenance tasks
    tasks_response = client.get("/api/operations/maintenance/tasks")
    assert tasks_response.status_code in [200, 401]
    
    # 4. Get maintenance calendar
    calendar_response = client.get("/api/operations/maintenance/calendar")
    assert calendar_response.status_code in [200, 401]


@pytest.mark.integration
def test_monitoring_flow():
    """Test complete monitoring flow."""
    
    # 1. Create alert
    create_response = client.post(
        "/api/monitoring/alerts",
        json={
            "title": "Test Alert",
            "description": "Test alert for E2E testing",
            "severity": "info",
            "source": "e2e_test"
        }
    )
    assert create_response.status_code in [200, 400, 401]
    
    # 2. Get active alerts
    alerts_response = client.get("/api/monitoring/alerts/active")
    assert alerts_response.status_code in [200, 401]
    
    # 3. Get alert statistics
    stats_response = client.get("/api/monitoring/alerts/statistics")
    assert stats_response.status_code in [200, 401]
    
    # 4. Check alert rules
    rules_response = client.post("/api/monitoring/alerts/check-rules")
    assert rules_response.status_code in [200, 401]


@pytest.mark.integration
def test_advanced_security_flow():
    """Test complete advanced security flow."""
    
    # 1. Get encryption keys
    keys_response = client.get("/api/advanced-security/keys")
    assert keys_response.status_code in [200, 401]
    
    # 2. Encrypt data
    encrypt_response = client.post(
        "/api/advanced-security/encrypt",
        json={
            "data": "test sensitive data"
        }
    )
    assert encrypt_response.status_code in [200, 400, 401]
    
    if encrypt_response.status_code == 200:
        encrypted_data = encrypt_response.json()
        
        # 3. Decrypt data
        decrypt_response = client.post(
            "/api/advanced-security/decrypt",
            json={
                "encrypted_data": encrypted_data["encrypted_data"],
                "key_id": encrypted_data["key_id"],
                "iv": encrypted_data["iv"]
            }
        )
        assert decrypt_response.status_code in [200, 400, 401]
    
    # 4. Perform security scan
    scan_response = client.get("/api/advanced-security/security-scan")
    assert scan_response.status_code in [200, 401, 500]


@pytest.mark.integration
def test_security_protocols_flow():
    """Test complete security protocols flow."""
    
    # 1. Calculate security route
    route_response = client.post(
        "/api/security/route",
        json={
            "start": {
                "latitude": 35.6892,
                "longitude": 51.3890
            },
            "end": {
                "latitude": 35.7000,
                "longitude": 51.4000
            },
            "risk_tolerance": "medium"
        }
    )
    assert route_response.status_code in [200, 400, 401]
    
    # 2. Create escort plan
    plan_response = client.post(
        "/api/security/escort-plan",
        json={
            "name": "Test Escort Plan",
            "route": [
                {"latitude": 35.6892, "longitude": 51.3890},
                {"latitude": 35.7000, "longitude": 51.4000}
            ],
            "security_level": "high",
            "team_size": 4
        }
    )
    assert plan_response.status_code in [200, 400, 401]
    
    if plan_response.status_code == 200:
        plan_id = plan_response.json().get("id")
        
        # 3. Get escort plan details
        details_response = client.get(f"/api/security/escort-plan/{plan_id}")
        assert details_response.status_code in [200, 404, 401]


@pytest.mark.integration
def test_system_health():
    """Test overall system health endpoints."""
    
    # 1. Root endpoint
    root_response = client.get("/")
    assert root_response.status_code == 200
    
    # 2. Health check
    health_response = client.get("/health")
    assert health_response.status_code == 200
    assert health_response.json()["status"] == "healthy"
    
    # 3. API documentation
    docs_response = client.get("/docs")
    assert docs_response.status_code == 200
