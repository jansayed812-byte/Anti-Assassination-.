from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import asyncio
import uuid
import json


class VideoResolution(Enum):
    RES_720P = "720p"
    RES_1080P = "1080p"
    RES_4K = "4k"


class VideoCodec(Enum):
    H264 = "h264"
    H265 = "h265"
    VP9 = "vp9"
    AV1 = "av1"


@dataclass
class VideoStreamInfo:
    """Information about a video stream."""
    stream_id: str
    source_id: str
    resolution: VideoResolution
    codec: VideoCodec
    framerate: float
    bitrate: int  # bits per second
    width: int
    height: int
    is_authorized: bool
    timestamp: datetime


@dataclass
class Detection:
    """Object detection result."""
    detection_id: str
    class_name: str
    confidence: float
    bounding_box: Dict[str, int]  # {x, y, width, height}
    temporal_trajectory: List[Dict[str, Any]]
    alert_reason: Optional[str]
    timestamp: datetime
    model_version: str
    frame_number: int


@dataclass
class VideoMetrics:
    """Video processing metrics."""
    stream_id: str
    encode_latency_ms: float
    decode_latency_ms: float
    inference_latency_ms: float
    total_latency_ms: float
    dropped_frames: int
    total_frames: int
    frame_drop_rate: float
    current_bitrate: int
    memory_usage_mb: float
    timestamp: datetime


class VideoGateway:
    """
    Video gateway as per architecture spec.
    
    Gateway should only decode authorized streams and send to inference service.
    Inference service stores timestamp and model version alongside each detection.
    Output should include bounding box, class, confidence, temporal trajectory, and alert reason.
    
    Claim of 4K/30 must be proven with encode/decode measurement, bitrate, frame drop, and latency.
    In this sample, it's just display.
    """
    
    def __init__(self):
        self.active_streams: Dict[str, VideoStreamInfo] = {}
        self.stream_metrics: Dict[str, VideoMetrics] = {}
        self.detections: List[Detection] = []
        self.authorized_sources: set = set()
        self.model_version = "1.0"
        self.inference_service = InferenceService()
    
    def authorize_source(self, source_id: str):
        """Authorize a video source."""
        self.authorized_sources.add(source_id)
    
    def revoke_source(self, source_id: str):
        """Revoke authorization for a video source."""
        self.authorized_sources.discard(source_id)
    
    def register_stream(
        self,
        source_id: str,
        resolution: VideoResolution,
        codec: VideoCodec,
        framerate: float,
        bitrate: int
    ) -> VideoStreamInfo:
        """Register a new video stream."""
        # Check authorization
        is_authorized = source_id in self.authorized_sources
        
        # Set dimensions based on resolution
        if resolution == VideoResolution.RES_720P:
            width, height = 1280, 720
        elif resolution == VideoResolution.RES_1080P:
            width, height = 1920, 1080
        elif resolution == VideoResolution.RES_4K:
            width, height = 3840, 2160
        else:
            width, height = 1920, 1080  # default
        
        stream_info = VideoStreamInfo(
            stream_id=str(uuid.uuid4()),
            source_id=source_id,
            resolution=resolution,
            codec=codec,
            framerate=framerate,
            bitrate=bitrate,
            width=width,
            height=height,
            is_authorized=is_authorized,
            timestamp=datetime.utcnow()
        )
        
        self.active_streams[stream_info.stream_id] = stream_info
        
        # Initialize metrics
        self.stream_metrics[stream_info.stream_id] = VideoMetrics(
            stream_id=stream_info.stream_id,
            encode_latency_ms=0.0,
            decode_latency_ms=0.0,
            inference_latency_ms=0.0,
            total_latency_ms=0.0,
            dropped_frames=0,
            total_frames=0,
            frame_drop_rate=0.0,
            current_bitrate=bitrate,
            memory_usage_mb=0.0,
            timestamp=datetime.utcnow()
        )
        
        return stream_info
    
    def process_frame(
        self,
        stream_id: str,
        frame_data: bytes,
        frame_number: int
    ) -> Optional[List[Detection]]:
        """
        Process a video frame.
        
        Only decode authorized streams and send to inference service.
        """
        stream_info = self.active_streams.get(stream_id)
        if not stream_info:
            return None
        
        # Check authorization
        if not stream_info.is_authorized:
            # Log unauthorized access attempt
            return None
        
        # Simulate decode latency
        decode_latency = self._simulate_decode_latency(stream_info)
        
        # Send to inference service
        detections = self.inference_service.process_frame(
            frame_data=frame_data,
            frame_number=frame_number,
            stream_info=stream_info,
            model_version=self.model_version
        )
        
        # Update metrics
        metrics = self.stream_metrics[stream_id]
        metrics.decode_latency_ms = decode_latency
        metrics.total_frames += 1
        metrics.inference_latency_ms = self.inference_service.get_last_latency_ms()
        metrics.total_latency_ms = decode_latency + metrics.inference_latency_ms
        metrics.timestamp = datetime.utcnow()
        
        # Store detections
        self.detections.extend(detections)
        
        return detections
    
    def _simulate_decode_latency(self, stream_info: VideoStreamInfo) -> float:
        """Simulate decode latency based on resolution and codec."""
        base_latency = {
            VideoResolution.RES_720P: 5.0,
            VideoResolution.RES_1080P: 10.0,
            VideoResolution.RES_4K: 25.0
        }
        
        codec_multiplier = {
            VideoCodec.H264: 1.0,
            VideoCodec.H265: 1.2,
            VideoCodec.VP9: 1.3,
            VideoCodec.AV1: 1.5
        }
        
        latency = base_latency[stream_info.resolution] * codec_multiplier[stream_info.codec]
        
        # Add some random variance
        import random
        latency += random.uniform(-1.0, 1.0)
        
        return max(0.0, latency)
    
    def get_stream_metrics(self, stream_id: str) -> Optional[VideoMetrics]:
        """Get metrics for a specific stream."""
        return self.stream_metrics.get(stream_id)
    
    def get_all_metrics(self) -> Dict[str, VideoMetrics]:
        """Get metrics for all active streams."""
        return self.stream_metrics.copy()
    
    def get_detections(
        self,
        stream_id: Optional[str] = None,
        limit: int = 100
    ) -> List[Detection]:
        """Get detections, optionally filtered by stream."""
        if stream_id:
            # Need to map detections to streams (simplified)
            return [d for d in self.detections if d.detection_id.startswith(stream_id)][:limit]
        return self.detections[-limit:]
    
    def calculate_4k_30_performance(self) -> Dict[str, Any]:
        """
        Calculate 4K/30 performance metrics.
        
        Claim of 4K/30 must be proven with:
        - encode/decode measurement
        - bitrate
        - frame drop
        - latency measurement
        """
        # Simulate 4K/30 stream
        stream_info = self.register_stream(
            source_id="test_4k",
            resolution=VideoResolution.RES_4K,
            codec=VideoCodec.H265,
            framerate=30.0,
            bitrate=20000000  # 20 Mbps
        )
        
        # Simulate processing 100 frames
        total_latency = 0.0
        dropped_frames = 0
        
        for i in range(100):
            frame_data = b"mock_frame_data" * 1000  # Simulated frame
            
            try:
                self.process_frame(stream_info.stream_id, frame_data, i)
                metrics = self.get_stream_metrics(stream_info.stream_id)
                total_latency += metrics.total_latency_ms
            except Exception:
                dropped_frames += 1
        
        avg_latency = total_latency / (100 - dropped_frames) if (100 - dropped_frames) > 0 else 0
        frame_drop_rate = dropped_frames / 100.0
        
        return {
            "resolution": "4K",
            "framerate": 30.0,
            "codec": "H265",
            "bitrate_bps": 20000000,
            "avg_decode_latency_ms": self._simulate_decode_latency(stream_info),
            "avg_inference_latency_ms": self.inference_service.get_last_latency_ms(),
            "avg_total_latency_ms": avg_latency,
            "total_frames": 100,
            "dropped_frames": dropped_frames,
            "frame_drop_rate": frame_drop_rate,
            "memory_usage_mb": self._estimate_memory_usage(stream_info),
            "performance_claim": "4K/30 achievable" if avg_latency < 33.0 else "4K/30 not achievable",
            "note": "This is a simulation. Real measurement requires actual video processing."
        }
    
    def _estimate_memory_usage(self, stream_info: VideoStreamInfo) -> float:
        """Estimate memory usage for stream processing."""
        pixel_count = stream_info.width * stream_info.height
        # 3 bytes per pixel (RGB) + overhead
        frame_size_mb = (pixel_count * 3) / (1024 * 1024)
        
        # Double buffering + inference overhead
        return frame_size_mb * 3
    
    def remove_stream(self, stream_id: str):
        """Remove a video stream."""
        if stream_id in self.active_streams:
            del self.active_streams[stream_id]
        if stream_id in self.stream_metrics:
            del self.stream_metrics[stream_id]


class InferenceService:
    """
    Inference service for video analysis.
    
    Stores timestamp and model version alongside each detection.
    Output includes bounding box, class, confidence, temporal trajectory, and alert reason.
    """
    
    def __init__(self):
        self.last_latency_ms = 0.0
        self.detection_history: Dict[str, List[Detection]] = {}
        self.max_history = 1000
    
    def process_frame(
        self,
        frame_data: bytes,
        frame_number: int,
        stream_info: VideoStreamInfo,
        model_version: str
    ) -> List[Detection]:
        """Process a frame and return detections."""
        # Simulate inference latency
        self.last_latency_ms = self._simulate_inference_latency(stream_info)
        
        # Simulate detections (in production, this would use actual ML model)
        detections = self._simulate_detections(frame_number, stream_info, model_version)
        
        # Store in history
        for detection in detections:
            if detection.class_name not in self.detection_history:
                self.detection_history[detection.class_name] = []
            
            self.detection_history[detection.class_name].append(detection)
            
            # Maintain max history
            if len(self.detection_history[detection.class_name]) > self.max_history:
                self.detection_history[detection.class_name].pop(0)
        
        return detections
    
    def _simulate_inference_latency(self, stream_info: VideoStreamInfo) -> float:
        """Simulate inference latency based on resolution."""
        base_latency = {
            VideoResolution.RES_720P: 15.0,
            VideoResolution.RES_1080P: 30.0,
            VideoResolution.RES_4K: 80.0
        }
        
        latency = base_latency[stream_info.resolution]
        
        # Add random variance
        import random
        latency += random.uniform(-5.0, 5.0)
        
        return max(0.0, latency)
    
    def _simulate_detections(
        self,
        frame_number: int,
        stream_info: VideoStreamInfo,
        model_version: str
    ) -> List[Detection]:
        """Simulate object detections."""
        import random
        
        # Random number of detections (0-5)
        num_detections = random.randint(0, 5)
        
        detections = []
        classes = ["person", "vehicle", "weapon", "anomaly"]
        
        for i in range(num_detections):
            class_name = random.choice(classes)
            confidence = random.uniform(0.5, 0.99)
            
            # Generate bounding box
            x = random.randint(0, stream_info.width - 100)
            y = random.randint(0, stream_info.height - 100)
            width = random.randint(50, 200)
            height = random.randint(50, 200)
            
            # Generate temporal trajectory (last 5 frames)
            trajectory = []
            for j in range(5):
                trajectory.append({
                    "frame_number": frame_number - j,
                    "x": x + random.randint(-10, 10),
                    "y": y + random.randint(-10, 10),
                    "confidence": confidence - (j * 0.05)
                })
            
            # Determine alert reason
            alert_reason = None
            if class_name in ["weapon", "anomaly"] and confidence > 0.8:
                alert_reason = f"High confidence {class_name} detected"
            
            detection = Detection(
                detection_id=str(uuid.uuid4()),
                class_name=class_name,
                confidence=confidence,
                bounding_box={"x": x, "y": y, "width": width, "height": height},
                temporal_trajectory=trajectory,
                alert_reason=alert_reason,
                timestamp=datetime.utcnow(),
                model_version=model_version,
                frame_number=frame_number
            )
            
            detections.append(detection)
        
        return detections
    
    def get_last_latency_ms(self) -> float:
        """Get the last inference latency."""
        return self.last_latency_ms
    
    def get_detection_history(self, class_name: Optional[str] = None) -> List[Detection]:
        """Get detection history, optionally filtered by class."""
        if class_name:
            return self.detection_history.get(class_name, []).copy()
        
        # Return all detections
        all_detections = []
        for class_detections in self.detection_history.values():
            all_detections.extend(class_detections)
        
        return all_detections
    
    def get_temporal_trajectory(self, detection_id: str) -> List[Dict[str, Any]]:
        """Get temporal trajectory for a specific detection."""
        # This would require tracking specific detections across frames
        # For now, return empty
        return []


# Global video gateway instance
video_gateway = VideoGateway()