import numpy as np
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import asyncio
import threading
import time


@dataclass
class MovementData:
    user_id: int
    latitude: float
    longitude: float
    altitude: float
    speed: float
    heading: float
    acceleration: float
    timestamp: datetime


@dataclass
class TrackingSession:
    user_id: int
    start_time: datetime
    last_update: datetime
    total_distance: float
    max_speed: float
    avg_speed: float
    positions: List[Dict[str, Any]]
    is_active: bool


class TrackingService:
    """Service for real-time movement tracking with kinematic calculations."""
    
    def __init__(self):
        self.tracking_sessions: Dict[int, TrackingSession] = {}
        self.position_buffer: Dict[int, List[Dict[str, Any]]] = {}
        self.is_running = False
        self._thread: Optional[threading.Thread] = None
        self.update_interval = 0.2  # 5Hz update rate
        self.callbacks = []
    
    def start_tracking(self, user_id: int) -> bool:
        """Start tracking a user."""
        if user_id in self.tracking_sessions:
            return False
        
        self.tracking_sessions[user_id] = TrackingSession(
            user_id=user_id,
            start_time=datetime.now(),
            last_update=datetime.now(),
            total_distance=0.0,
            max_speed=0.0,
            avg_speed=0.0,
            positions=[],
            is_active=True
        )
        
        self.position_buffer[user_id] = []
        print(f"Started tracking user {user_id}")
        return True
    
    def stop_tracking(self, user_id: int) -> bool:
        """Stop tracking a user."""
        if user_id not in self.tracking_sessions:
            return False
        
        self.tracking_sessions[user_id].is_active = False
        print(f"Stopped tracking user {user_id}")
        return True
    
    def update_position(self, user_id: int, position: Dict[str, Any]) -> Dict[str, Any]:
        """Update position and calculate kinematic parameters."""
        if user_id not in self.tracking_sessions:
            self.start_tracking(user_id)
        
        session = self.tracking_sessions[user_id]
        
        # Add to position buffer
        self.position_buffer[user_id].append({
            **position,
            "timestamp": datetime.now()
        })
        
        # Keep buffer size manageable (last 10 seconds)
        buffer_size = int(10 / self.update_interval)
        if len(self.position_buffer[user_id]) > buffer_size:
            self.position_buffer[user_id] = self.position_buffer[user_id][-buffer_size:]
        
        # Calculate kinematic parameters
        kinematics = self._calculate_kinematics(user_id)
        
        # Update session statistics
        if len(self.position_buffer[user_id]) >= 2:
            # Calculate distance
            prev_pos = self.position_buffer[user_id][-2]
            curr_pos = self.position_buffer[user_id][-1]
            distance = self._haversine_distance(
                prev_pos["latitude"], prev_pos["longitude"],
                curr_pos["latitude"], curr_pos["longitude"]
            )
            session.total_distance += distance
        
        # Update speed statistics
        if kinematics["speed"] > session.max_speed:
            session.max_speed = kinematics["speed"]
        
        # Calculate average speed
        if session.positions:
            total_speed = sum(p.get("speed", 0) for p in session.positions)
            session.avg_speed = total_speed / len(session.positions)
        
        # Store position with kinematics
        position_with_kinematics = {
            **position,
            **kinematics,
            "timestamp": datetime.now()
        }
        session.positions.append(position_with_kinematics)
        session.last_update = datetime.now()
        
        # Notify callbacks
        for callback in self.callbacks:
            try:
                callback(user_id, position_with_kinematics)
            except Exception as e:
                print(f"Error in tracking callback: {e}")
        
        return position_with_kinematics
    
    def _calculate_kinematics(self, user_id: int) -> Dict[str, float]:
        """Calculate speed, heading, and acceleration from position buffer."""
        buffer = self.position_buffer.get(user_id, [])
        
        if len(buffer) < 2:
            return {
                "speed": 0.0,
                "heading": 0.0,
                "acceleration": 0.0
            }
        
        current = buffer[-1]
        previous = buffer[-2]
        
        # Calculate time difference
        dt = (current["timestamp"] - previous["timestamp"]).total_seconds()
        if dt <= 0:
            dt = self.update_interval
        
        # Calculate distance
        distance = self._haversine_distance(
            previous["latitude"], previous["longitude"],
            current["latitude"], current["longitude"]
        )
        
        # Calculate speed (m/s)
        speed = distance / dt
        
        # Calculate heading (degrees)
        heading = self._calculate_heading(
            previous["latitude"], previous["longitude"],
            current["latitude"], current["longitude"]
        )
        
        # Calculate acceleration (m/s²)
        acceleration = 0.0
        if len(buffer) >= 3:
            prev_previous = buffer[-3]
            prev_dt = (previous["timestamp"] - prev_previous["timestamp"]).total_seconds()
            if prev_dt > 0:
                prev_distance = self._haversine_distance(
                    prev_previous["latitude"], prev_previous["longitude"],
                    previous["latitude"], previous["longitude"]
                )
                prev_speed = prev_distance / prev_dt
                acceleration = (speed - prev_speed) / dt
        
        return {
            "speed": speed,
            "heading": heading,
            "acceleration": acceleration
        }
    
    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two points using Haversine formula."""
        R = 6371000  # Earth's radius in meters
        
        lat1_rad = np.radians(lat1)
        lat2_rad = np.radians(lat2)
        delta_lat = np.radians(lat2 - lat1)
        delta_lon = np.radians(lon2 - lon1)
        
        a = (np.sin(delta_lat / 2) ** 2 +
             np.cos(lat1_rad) * np.cos(lat2_rad) * np.sin(delta_lon / 2) ** 2)
        c = 2 * np.arcsin(np.sqrt(a))
        
        return R * c
    
    def _calculate_heading(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate heading from point 1 to point 2."""
        lat1_rad = np.radians(lat1)
        lat2_rad = np.radians(lat2)
        delta_lon = np.radians(lon2 - lon1)
        
        x = np.sin(delta_lon) * np.cos(lat2_rad)
        y = (np.cos(lat1_rad) * np.sin(lat2_rad) -
             np.sin(lat1_rad) * np.cos(lat2_rad) * np.cos(delta_lon))
        
        heading = np.degrees(np.arctan2(x, y))
        if heading < 0:
            heading += 360
        
        return heading
    
    def get_tracking_status(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get current tracking status for a user."""
        if user_id not in self.tracking_sessions:
            return None
        
        session = self.tracking_sessions[user_id]
        return {
            "user_id": user_id,
            "is_active": session.is_active,
            "start_time": session.start_time.isoformat(),
            "last_update": session.last_update.isoformat(),
            "total_distance": session.total_distance,
            "max_speed": session.max_speed,
            "avg_speed": session.avg_speed,
            "position_count": len(session.positions)
        }
    
    def get_all_tracking_status(self) -> List[Dict[str, Any]]:
        """Get tracking status for all users."""
        return [
            self.get_tracking_status(user_id)
            for user_id in self.tracking_sessions.keys()
        ]
    
    def get_position_history(self, user_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        """Get position history for a user."""
        if user_id not in self.tracking_sessions:
            return []
        
        session = self.tracking_sessions[user_id]
        return session.positions[-limit:]
    
    def add_callback(self, callback):
        """Add a callback for position updates."""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback):
        """Remove a callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def start_service(self):
        """Start the tracking service background thread."""
        if self.is_running:
            return
        
        self.is_running = True
        self._thread = threading.Thread(target=self._service_loop, daemon=True)
        self._thread.start()
    
    def stop_service(self):
        """Stop the tracking service."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
    
    def _service_loop(self):
        """Background service loop for cleanup and maintenance."""
        while self.is_running:
            try:
                # Clean up inactive sessions
                current_time = datetime.now()
                inactive_threshold = timedelta(minutes=5)
                
                inactive_users = [
                    user_id for user_id, session in self.tracking_sessions.items()
                    if (current_time - session.last_update) > inactive_threshold
                ]
                
                for user_id in inactive_users:
                    self.stop_tracking(user_id)
                
                time.sleep(10)  # Check every 10 seconds
            except Exception as e:
                print(f"Error in tracking service loop: {e}")
                time.sleep(1)


# Global tracking service instance
tracking_service = TrackingService()
