from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import json


class DataClass(Enum):
    SENSOR_RAW = "sensor_raw"
    FUSED_TRACKS = "fused_tracks"
    INTEL_REPORTS = "intel_reports"
    AAR_RECORDS = "aar_records"
    AUDIT_LOGS = "audit_logs"
    USER_PROFILES = "user_profiles"
    DEVICE_DATA = "device_data"
    COMMUNICATION_LOGS = "communication_logs"
    SECURITY_EVENTS = "security_events"
    TRAINING_RECORDS = "training_records"
    OPERATIONAL_METRICS = "operational_metrics"


@dataclass
class DataClassConfig:
    data_class: DataClass
    retention: str  # e.g., "30d", "180d", "5y"
    encrypt: str  # e.g., "AES-256-GCM"
    pii: bool = False
    immutable: bool = False
    tamper_evident: bool = False
    review: Optional[str] = None
    note: Optional[str] = None


class DataLifecycleService:
    """Service for managing data lifecycle, retention, and compliance."""
    
    def __init__(self):
        self.data_classes_config: Dict[DataClass, DataClassConfig] = {
            DataClass.SENSOR_RAW: DataClassConfig(
                data_class=DataClass.SENSOR_RAW,
                retention="30d",
                encrypt="AES-256-GCM",
                pii=False,
                note="Raw sensor data from GPS, WiFi, Bluetooth, Cellular, INS"
            ),
            DataClass.FUSED_TRACKS: DataClassConfig(
                data_class=DataClass.FUSED_TRACKS,
                retention="180d",
                encrypt="AES-256-GCM",
                pii=True,
                note="موقعیت تیم = داده حساس — RLS اجباری"
            ),
            DataClass.INTEL_REPORTS: DataClassConfig(
                data_class=DataClass.INTEL_REPORTS,
                retention="5y",
                encrypt="AES-256-GCM",
                review="yearly_declassification",
                note="Intelligence and threat analysis reports"
            ),
            DataClass.AAR_RECORDS: DataClassConfig(
                data_class=DataClass.AAR_RECORDS,
                retention="5y",
                encrypt="AES-256-GCM",
                immutable=True,
                note="After-Action Review records - cannot be modified"
            ),
            DataClass.AUDIT_LOGS: DataClassConfig(
                data_class=DataClass.AUDIT_LOGS,
                retention="7y",
                encrypt="AES-256-GCM",
                tamper_evident=True,
                note="System audit logs - tamper-evident"
            ),
            DataClass.USER_PROFILES: DataClassConfig(
                data_class=DataClass.USER_PROFILES,
                retention="2y",
                encrypt="AES-256-GCM",
                pii=True,
                note="User profile information - GDPR compliant"
            ),
            DataClass.DEVICE_DATA: DataClassConfig(
                data_class=DataClass.DEVICE_DATA,
                retention="1y",
                encrypt="AES-256-GCM",
                pii=False,
                note="Device telemetry and status data"
            ),
            DataClass.COMMUNICATION_LOGS: DataClassConfig(
                data_class=DataClass.COMMUNICATION_LOGS,
                retention="3y",
                encrypt="AES-256-GCM",
                pii=True,
                note="Communication logs between devices and teams"
            ),
            DataClass.SECURITY_EVENTS: DataClassConfig(
                data_class=DataClass.SECURITY_EVENTS,
                retention="5y",
                encrypt="AES-256-GCM",
                tamper_evident=True,
                note="Security events and incidents"
            ),
            DataClass.TRAINING_RECORDS: DataClassConfig(
                data_class=DataClass.TRAINING_RECORDS,
                retention="5y",
                encrypt="AES-256-GCM",
                pii=True,
                note="User training and certification records"
            ),
            DataClass.OPERATIONAL_METRICS: DataClassConfig(
                data_class=DataClass.OPERATIONAL_METRICS,
                retention="1y",
                encrypt="AES-256-GCM",
                pii=False,
                note="System performance and operational metrics"
            )
        }
        self.data_registry: Dict[str, Dict[str, Any]] = {}
    
    def register_data(self, data_id: str, data_class: DataClass, 
                    metadata: Dict[str, Any]) -> bool:
        """Register a data item with its class and metadata."""
        config = self.data_classes_config.get(data_class)
        if not config:
            return False
        
        retention_period = self._parse_retention(config.retention)
        expiry_date = datetime.now() + retention_period
        
        self.data_registry[data_id] = {
            "data_class": data_class.value,
            "registered_at": datetime.now().isoformat(),
            "expires_at": expiry_date.isoformat(),
            "encryption": config.encrypt,
            "pii": config.pii,
            "immutable": config.immutable,
            "tamper_evident": config.tamper_evident,
            "metadata": metadata
        }
        
        return True
    
    def _parse_retention(self, retention: str) -> timedelta:
        """Parse retention string to timedelta."""
        value = int(retention[:-1])
        unit = retention[-1]
        
        if unit == 'd':
            return timedelta(days=value)
        elif unit == 'm':
            return timedelta(days=value * 30)
        elif unit == 'y':
            return timedelta(days=value * 365)
        else:
            return timedelta(days=30)  # default
    
    def check_expiry(self) -> List[str]:
        """Check for expired data items that should be deleted."""
        expired_items = []
        current_time = datetime.now()
        
        for data_id, data_info in self.data_registry.items():
            expiry_date = datetime.fromisoformat(data_info["expires_at"])
            if current_time > expiry_date:
                expired_items.append(data_id)
        
        return expired_items
    
    def delete_expired_data(self) -> Dict[str, Any]:
        """Delete expired data items."""
        expired_items = self.check_expiry()
        deleted_count = 0
        
        for data_id in expired_items:
            data_info = self.data_registry[data_id]
            
            # Check if data is immutable
            if data_info.get("immutable", False):
                continue
            
            # Delete from registry
            del self.data_registry[data_id]
            deleted_count += 1
        
        return {
            "checked": len(self.data_registry) + deleted_count,
            "expired": len(expired_items),
            "deleted": deleted_count,
            "immutable_skipped": len(expired_items) - deleted_count
        }
    
    def get_data_info(self, data_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a data item."""
        return self.data_registry.get(data_id)
    
    def get_data_by_class(self, data_class: DataClass) -> List[Dict[str, Any]]:
        """Get all data items of a specific class."""
        return [
            {"data_id": data_id, **data_info}
            for data_id, data_info in self.data_registry.items()
            if data_info["data_class"] == data_class.value
        ]
    
    def apply_gdpr_protection(self, data_id: str) -> bool:
        """Apply GDPR-like protection (auto-blur for non-military personnel)."""
        data_info = self.data_registry.get(data_id)
        if not data_info:
            return False
        
        # For video data with PII, apply auto-blur
        if data_info.get("pii", False) and data_info["data_class"] == DataClass.SENSOR_RAW.value:
            # This would trigger video processing to blur faces
            data_info["gdpr_protected"] = True
            data_info["protection_applied_at"] = datetime.now().isoformat()
            return True
        
        return False
    
    def get_compliance_status(self) -> Dict[str, Any]:
        """Get overall compliance status for data governance."""
        total_items = len(self.data_registry)
        expired_items = len(self.check_expiry())
        pii_items = sum(1 for item in self.data_registry.values() if item.get("pii", False))
        immutable_items = sum(1 for item in self.data_registry.values() if item.get("immutable", False))
        
        return {
            "total_data_items": total_items,
            "expired_items": expired_items,
            "compliance_rate": (total_items - expired_items) / total_items if total_items > 0 else 1.0,
            "pii_items": pii_items,
            "immutable_items": immutable_items,
            "data_classes": {
                data_class.value: len(self.get_data_by_class(data_class))
                for data_class in DataClass
            }
        }
    
    def export_registry(self) -> str:
        """Export data registry for audit purposes."""
        return json.dumps(self.data_registry, indent=2, default=str)
    
    def generate_retention_report(self) -> Dict[str, Any]:
        """Generate retention report for compliance."""
        report = {
            "generated_at": datetime.now().isoformat(),
            "data_classes": []
        }
        
        for data_class, config in self.data_classes_config.items():
            items = self.get_data_by_class(data_class)
            expiry_dates = [
                datetime.fromisoformat(item["expires_at"])
                for item in items
            ]
            
            if expiry_dates:
                avg_retention_days = sum(
                    (date - datetime.now()).days
                    for date in expiry_dates
                ) / len(expiry_dates)
            else:
                avg_retention_days = 0
            
            report["data_classes"].append({
                "class": data_class.value,
                "configured_retention": config.retention,
                "item_count": len(items),
                "avg_days_until_expiry": avg_retention_days,
                "encryption": config.encrypt,
                "pii": config.pii,
                "immutable": config.immutable,
                "tamper_evident": config.tamper_evident,
                "review": config.review,
                "note": config.note
            })
        
        return report
    
    def validate_data_classification(self, data_id: str, proposed_class: DataClass) -> Dict[str, Any]:
        """Validate if data can be classified as proposed class."""
        config = self.data_classes_config.get(proposed_class)
        if not config:
            return {"valid": False, "reason": "Invalid data class"}
        
        # Check if data is already classified
        existing_data = self.data_registry.get(data_id)
        if existing_data:
            current_class = existing_data["data_class"]
            if existing_data.get("immutable", False):
                return {
                    "valid": False,
                    "reason": f"Cannot reclassify immutable data (current: {current_class})"
                }
        
        return {
            "valid": True,
            "class": proposed_class.value,
            "retention": config.retention,
            "encryption": config.encrypt,
            "requirements": {
                "pii": config.pii,
                "immutable": config.immutable,
                "tamper_evident": config.tamper_evident
            }
        }
    
    def update_retention_policy(self, data_class: DataClass, new_retention: str) -> bool:
        """Update retention policy for a data class (admin only)."""
        config = self.data_classes_config.get(data_class)
        if not config:
            return False
        
        # Validate retention format
        try:
            self._parse_retention(new_retention)
        except (ValueError, IndexError):
            return False
        
        config.retention = new_retention
        return True
    
    def get_data_subject_rights(self, user_id: str) -> Dict[str, Any]:
        """Get GDPR-like data subject rights for a user."""
        user_data = [
            {"data_id": data_id, **data_info}
            for data_id, data_info in self.data_registry.items()
            if data_info.get("metadata", {}).get("user_id") == user_id
        ]
        
        return {
            "user_id": user_id,
            "data_count": len(user_data),
            "data_items": user_data,
            "rights": {
                "access": True,
                "rectification": True,
                "erasure": "conditional",
                "portability": True,
                "objection": "conditional"
            },
            "can_delete": all(
                not item.get("immutable", False) and 
                not item.get("tamper_evident", False)
                for item in user_data
            )
        }
    
    def initiate_data_deletion_request(self, user_id: str, reason: str) -> Dict[str, Any]:
        """Initiate GDPR deletion request for user data."""
        user_data = [
            data_id
            for data_id, data_info in self.data_registry.items()
            if data_info.get("metadata", {}).get("user_id") == user_id
        ]
        
        deletable = []
        protected = []
        
        for data_id in user_data:
            data_info = self.data_registry[data_id]
            if data_info.get("immutable", False) or data_info.get("tamper_evident", False):
                protected.append(data_id)
            else:
                deletable.append(data_id)
        
        return {
            "request_id": f"DEL-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "user_id": user_id,
            "reason": reason,
            "deletable_count": len(deletable),
            "protected_count": len(protected),
            "status": "pending_approval",
            "estimated_completion": (datetime.now() + timedelta(days=30)).isoformat()
        }
    
    def get_storage_metrics(self) -> Dict[str, Any]:
        """Get storage metrics for data classes."""
        metrics = {}
        
        for data_class in DataClass:
            items = self.get_data_by_class(data_class)
            config = self.data_classes_config[data_class]
            
            # Calculate estimated storage (simplified)
            avg_item_size = self._estimate_item_size(data_class)
            total_storage = len(items) * avg_item_size
            
            metrics[data_class.value] = {
                "item_count": len(items),
                "estimated_storage_bytes": total_storage,
                "estimated_storage_mb": total_storage / (1024 * 1024),
                "retention": config.retention,
                "encrypted": config.encrypt is not None
            }
        
        return metrics
    
    def _estimate_item_size(self, data_class: DataClass) -> int:
        """Estimate average item size in bytes."""
        size_estimates = {
            DataClass.SENSOR_RAW: 1024 * 1024,  # 1MB per item
            DataClass.FUSED_TRACKS: 512 * 1024,  # 512KB per item
            DataClass.INTEL_REPORTS: 10 * 1024,  # 10KB per item
            DataClass.AAR_RECORDS: 50 * 1024,  # 50KB per item
            DataClass.AUDIT_LOGS: 1 * 1024,  # 1KB per item
            DataClass.USER_PROFILES: 5 * 1024,  # 5KB per item
            DataClass.DEVICE_DATA: 100 * 1024,  # 100KB per item
            DataClass.COMMUNICATION_LOGS: 2 * 1024,  # 2KB per item
            DataClass.SECURITY_EVENTS: 5 * 1024,  # 5KB per item
            DataClass.TRAINING_RECORDS: 20 * 1024,  # 20KB per item
            DataClass.OPERATIONAL_METRICS: 1 * 1024,  # 1KB per item
        }
        return size_estimates.get(data_class, 10 * 1024)


# Global data lifecycle service instance
data_lifecycle_service = DataLifecycleService()
