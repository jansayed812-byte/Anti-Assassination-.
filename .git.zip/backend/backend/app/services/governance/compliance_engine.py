from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import json


class ComplianceFramework(Enum):
    ISO_27001 = "ISO_27001"
    NIST_800_53 = "NIST_800_53"
    GDPR = "GDPR"


class ControlStatus(Enum):
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    PARTIALLY_COMPLIANT = "partially_compliant"
    NOT_APPLICABLE = "not_applicable"


@dataclass
class Control:
    id: str
    framework: ComplianceFramework
    title: str
    description: str
    category: str
    mandatory: bool = True


@dataclass
class ComplianceGap:
    control: Control
    status: ControlStatus
    evidence: str
    remediation: str
    severity: str  # low, medium, high, critical
    discovered_at: datetime


class ComplianceEngine:
    """Engine for automated compliance checking and reporting."""
    
    def __init__(self):
        self.controls: List[Control] = []
        self.gaps: List[ComplianceGap] = []
        self.control_mappings: Dict[str, str] = {}  # module -> control_ids
        self._initialize_controls()
    
    def _initialize_controls(self):
        """Initialize compliance controls for ISO 27001 and NIST 800-53."""
        # ISO 27001 Annex A controls (sample)
        iso_controls = [
            Control("A.5.1", ComplianceFramework.ISO_27001, 
                   "Information Security Policies", 
                   "Management direction and support for information security",
                   "policies"),
            Control("A.8.1", ComplianceFramework.ISO_27001,
                   "Asset Inventory", 
                   "Assets associated with information and information processing facilities identified",
                   "asset_management"),
            Control("A.9.1", ComplianceFramework.ISO_27001,
                   "Access Control Policy", 
                   "Access control policy established and documented",
                   "access_control"),
            Control("A.10.1", ComplianceFramework.ISO_27001,
                   "Cryptography", 
                   "Use of cryptography to protect confidentiality, integrity and authenticity",
                   "cryptography"),
            Control("A.12.1", ComplianceFramework.ISO_27001,
                   "Operations Security", 
                   "Correct and secure operations of information processing facilities",
                   "operations"),
            Control("A.13.1", ComplianceFramework.ISO_27001,
                   "Network Security", 
                   "Security of networks and information transferred within them",
                   "network_security"),
            Control("A.14.1", ComplianceFramework.ISO_27001,
                   "System Acquisition", 
                   "Security requirements for information systems",
                   "system_acquisition"),
            Control("A.16.1", ComplianceFramework.ISO_27001,
                   "Incident Management", 
                   "Management of information security incidents",
                   "incident_management")
        ]
        
        # NIST SP 800-53 controls (sample - Baseline Moderate)
        nist_controls = [
            Control("AC-1", ComplianceFramework.NIST_800_53,
                   "Access Control Policy and Procedures",
                   "Organization develops, documents, and disseminates access control policy",
                   "access_control"),
            Control("AU-1", ComplianceFramework.NIST_800_53,
                   "Audit and Accountability Policy and Procedures",
                   "Organization develops, documents, and disseminates audit policy",
                   "audit"),
            Control("SC-1", ComplianceFramework.NIST_800_53,
                   "System and Communications Protection Policy and Procedures",
                   "Organization develops, documents, and disseminates system protection policy",
                   "system_protection"),
            Control("CP-1", ComplianceFramework.NIST_800_53,
                   "Contingency Planning Policy and Procedures",
                   "Organization develops, documents, and disseminates contingency planning policy",
                   "contingency_planning"),
            Control("IA-1", ComplianceFramework.NIST_800_53,
                   "Identification and Authentication Policy and Procedures",
                   "Organization develops, documents, and disseminates identification policy",
                   "identification")
        ]
        
        self.controls = iso_controls + nist_controls
        
        # Map controls to system modules
        self.control_mappings = {
            "authentication": ["A.9.1", "AC-1", "IA-1"],
            "encryption": ["A.10.1"],
            "network": ["A.13.1", "SC-1"],
            "operations": ["A.12.1"],
            "auditing": ["A.16.1", "AU-1"],
            "contingency": ["CP-1"],
            "policies": ["A.5.1"]
        }
    
    def verify_control(self, control_id: str) -> Dict[str, Any]:
        """Verify a specific control with live testing."""
        control = next((c for c in self.controls if c.id == control_id), None)
        if not control:
            return {"error": f"Control {control_id} not found"}
        
        # Simulate live verification (in production, this would run actual tests)
        verification_result = self._run_verification_test(control)
        
        return {
            "control_id": control.id,
            "framework": control.framework.value,
            "title": control.title,
            "status": verification_result["status"],
            "evidence": verification_result["evidence"],
            "last_verified": datetime.now().isoformat()
        }
    
    def _run_verification_test(self, control: Control) -> Dict[str, Any]:
        """Run live verification test for a control."""
        # This is a simplified version - in production, this would run actual tests
        # For now, we'll simulate verification based on control category
        
        test_results = {
            "policies": {"status": ControlStatus.COMPLIANT, "evidence": "Security policies documented and approved"},
            "access_control": {"status": ControlStatus.COMPLIANT, "evidence": "JWT authentication implemented with role-based access"},
            "cryptography": {"status": ControlStatus.COMPLIANT, "evidence": "AES-256-GCM encryption for data at rest and TLS 1.3 for transit"},
            "network_security": {"status": ControlStatus.PARTIALLY_COMPLIANT, "evidence": "Network segmentation implemented, IDS monitoring scheduled"},
            "operations": {"status": ControlStatus.COMPLIANT, "evidence": "Operational procedures documented and followed"},
            "auditing": {"status": ControlStatus.PARTIALLY_COMPLIANT, "evidence": "Audit logging implemented, log rotation configured"},
            "contingency_planning": {"status": ControlStatus.PARTIALLY_COMPLIANT, "evidence": "Backup procedures documented, DR testing pending"},
            "identification": {"status": ControlStatus.COMPLIANT, "evidence": "Multi-factor authentication available"}
        }
        
        return test_results.get(control.category, {
            "status": ControlStatus.NOT_APPLICABLE,
            "evidence": "Control not applicable to current system configuration"
        })
    
    def quarterly_compliance_review(self) -> Dict[str, Any]:
        """Perform quarterly compliance review as specified in DEFENDERS.md §22.2."""
        drift = []
        
        for control in self.controls:
            status = self.verify_control(control.id)
            
            if status["status"] in [ControlStatus.NON_COMPLIANT, ControlStatus.PARTIALLY_COMPLIANT]:
                gap = ComplianceGap(
                    control=control,
                    status=status["status"],
                    evidence=status["evidence"],
                    remediation=self._generate_remediation(control, status["status"]),
                    severity=self._assess_severity(control, status["status"]),
                    discovered_at=datetime.now()
                )
                drift.append(gap)
        
        # Categorize gaps by severity
        critical_gaps = [g for g in drift if g.severity == "critical"]
        high_gaps = [g for g in drift if g.severity == "high"]
        medium_gaps = [g for g in drift if g.severity == "medium"]
        low_gaps = [g for g in drift if g.severity == "low"]
        
        return {
            "review_date": datetime.now().isoformat(),
            "review_period": self._get_quarter_period(),
            "total_controls": len(self.controls),
            "compliant_controls": len(self.controls) - len(drift),
            "gaps_found": len(drift),
            "gaps_by_severity": {
                "critical": len(critical_gaps),
                "high": len(high_gaps),
                "medium": len(medium_gaps),
                "low": len(low_gaps)
            },
            "gaps": [
                {
                    "control_id": gap.control.id,
                    "control_title": gap.control.title,
                    "framework": gap.control.framework.value,
                    "category": gap.control.category,
                    "status": gap.status.value,
                    "evidence": gap.evidence,
                    "remediation": gap.remediation,
                    "severity": gap.severity,
                    "discovered_at": gap.discovered_at.isoformat(),
                    "priority": self._assign_priority(gap.severity)
                }
                for gap in drift
            ],
            "action_required": len(drift) > 0,
            "deadline_days": 30,
            "immediate_actions": len(critical_gaps) > 0,
            "recommendations": self._generate_review_recommendations(drift),
            "sign_off": {
                "required": True,
                "role": "commander",
                "deadline": (datetime.now() + timedelta(days=30)).isoformat()
            }
        }
    
    def _get_quarter_period(self) -> str:
        """Get current quarter period string."""
        now = datetime.now()
        quarter = (now.month - 1) // 3 + 1
        year = now.year
        return f"Q{quarter}-{year}"
    
    def _assign_priority(self, severity: str) -> int:
        """Assign priority level (1=highest, 4=lowest)."""
        priority_map = {
            "critical": 1,
            "high": 2,
            "medium": 3,
            "low": 4
        }
        return priority_map.get(severity, 4)
    
    def _generate_review_recommendations(self, gaps: List[ComplianceGap]) -> List[str]:
        """Generate specific recommendations based on gaps found."""
        if not gaps:
            return ["All controls compliant - maintain current security posture"]
        
        categories = set(gap.control.category for gap in gaps)
        recommendations = []
        
        if "access_control" in categories:
            recommendations.append("Review and strengthen access control mechanisms")
        if "cryptography" in categories:
            recommendations.append("Update cryptographic standards and implement key rotation")
        if "network_security" in categories:
            recommendations.append("Enhance network monitoring and segmentation")
        if "auditing" in categories:
            recommendations.append("Improve audit logging and analysis capabilities")
        if "contingency_planning" in categories:
            recommendations.append("Complete disaster recovery testing and documentation")
        
        # Add general recommendations
        critical_count = sum(1 for g in gaps if g.severity == "critical")
        if critical_count > 0:
            recommendations.append(f"URGENT: Address {critical_count} critical compliance gaps immediately")
        
        return recommendations
    
    def _generate_remediation(self, control: Control, status: ControlStatus) -> str:
        """Generate remediation steps for a non-compliant control."""
        remediation_map = {
            "access_control": "Implement stronger access controls, review user permissions, enable MFA",
            "cryptography": "Update encryption standards, implement key rotation, review TLS configuration",
            "network_security": "Deploy network monitoring, implement segmentation, configure firewall rules",
            "auditing": "Enhance audit logging, implement log analysis, ensure log retention compliance",
            "contingency_planning": "Complete DR testing, document recovery procedures, implement backup verification"
        }
        
        return remediation_map.get(control.category, "Review control requirements and implement necessary changes")
    
    def _assess_severity(self, control: Control, status: ControlStatus) -> str:
        """Assess severity of compliance gap."""
        if status == ControlStatus.NON_COMPLIANT:
            return "critical" if control.mandatory else "high"
        elif status == ControlStatus.PARTIALLY_COMPLIANT:
            return "medium" if control.mandatory else "low"
        else:
            return "low"
    
    def get_controls_by_framework(self, framework: ComplianceFramework) -> List[Control]:
        """Get all controls for a specific framework."""
        return [c for c in self.controls if c.framework == framework]
    
    def get_controls_by_module(self, module: str) -> List[Control]:
        """Get controls relevant to a specific system module."""
        control_ids = self.control_mappings.get(module, [])
        return [c for c in self.controls if c.id in control_ids]
    
    def generate_compliance_report(self) -> Dict[str, Any]:
        """Generate comprehensive compliance report."""
        iso_controls = self.get_controls_by_framework(ComplianceFramework.ISO_27001)
        nist_controls = self.get_controls_by_framework(ComplianceFramework.NIST_800_53)
        
        iso_status = self._assess_framework_status(iso_controls)
        nist_status = self._assess_framework_status(nist_controls)
        
        return {
            "report_date": datetime.now().isoformat(),
            "iso_27001": {
                "total_controls": len(iso_controls),
                "compliant": iso_status["compliant"],
                "partially_compliant": iso_status["partially_compliant"],
                "non_compliant": iso_status["non_compliant"],
                "compliance_rate": iso_status["rate"]
            },
            "nist_800_53": {
                "total_controls": len(nist_controls),
                "compliant": nist_status["compliant"],
                "partially_compliant": nist_status["partially_compliant"],
                "non_compliant": nist_status["non_compliant"],
                "compliance_rate": nist_status["rate"]
            },
            "overall_compliance": (iso_status["rate"] + nist_status["rate"]) / 2,
            "recommendations": self._generate_recommendations()
        }
    
    def _assess_framework_status(self, controls: List[Control]) -> Dict[str, Any]:
        """Assess compliance status for a framework."""
        statuses = [self.verify_control(c.id)["status"] for c in controls]
        
        return {
            "compliant": statuses.count(ControlStatus.COMPLIANT),
            "partially_compliant": statuses.count(ControlStatus.PARTIALLY_COMPLIANT),
            "non_compliant": statuses.count(ControlStatus.NON_COMPLIANT),
            "rate": statuses.count(ControlStatus.COMPLIANT) / len(controls) if controls else 0
        }
    
    def _generate_recommendations(self) -> List[str]:
        """Generate improvement recommendations."""
        return [
            "Implement automated compliance monitoring for real-time gap detection",
            "Schedule quarterly penetration testing to validate security controls",
            "Enhance audit logging with centralized log management",
            "Implement role-based access control with regular permission reviews",
            "Develop comprehensive incident response procedures",
            "Conduct regular security awareness training for all personnel"
        ]
    
    def sign_and_send_review(self, review_id: str, approver: str, approver_role: str) -> Dict[str, Any]:
        """Sign and send quarterly review to commander (as per DEFENDERS.md §22.2)."""
        # In production, this would use digital signatures and secure messaging
        return {
            "review_id": review_id,
            "signed_by": approver,
            "role": approver_role,
            "signed_at": datetime.now().isoformat(),
            "sent_to": "commander",
            "delivery_method": "secure_message",
            "deadline": (datetime.now() + timedelta(days=30)).isoformat(),
            "status": "awaiting_commander_approval"
        }
    
    def track_remediation_progress(self, gap_id: str) -> Dict[str, Any]:
        """Track progress on remediation of specific compliance gap."""
        # In production, this would query remediation ticket system
        return {
            "gap_id": gap_id,
            "status": "in_progress",
            "progress_percentage": 65,
            "assigned_to": "security_team",
            "started_at": (datetime.now() - timedelta(days=15)).isoformat(),
            "estimated_completion": (datetime.now() + timedelta(days=15)).isoformat(),
            "milestones": [
                {"milestone": "Analysis", "status": "completed", "completed_at": (datetime.now() - timedelta(days=14)).isoformat()},
                {"milestone": "Planning", "status": "completed", "completed_at": (datetime.now() - timedelta(days=10)).isoformat()},
                {"milestone": "Implementation", "status": "in_progress", "started_at": (datetime.now() - timedelta(days=5)).isoformat()},
                {"milestone": "Testing", "status": "pending"},
                {"milestone": "Verification", "status": "pending"}
            ]
        }
    
    def generate_compliance_summary(self) -> Dict[str, Any]:
        """Generate high-level compliance summary for management."""
        iso_controls = self.get_controls_by_framework(ComplianceFramework.ISO_27001)
        nist_controls = self.get_controls_by_framework(ComplianceFramework.NIST_800_53)
        
        iso_status = self._assess_framework_status(iso_controls)
        nist_status = self._assess_framework_status(nist_controls)
        
        # Calculate trend (would need historical data in production)
        overall_compliance = (iso_status["rate"] + nist_status["rate"]) / 2
        
        return {
            "summary_date": datetime.now().isoformat(),
            "overall_compliance_percentage": round(overall_compliance * 100, 2),
            "trend": "improving",  # Would be calculated from historical data
            "risk_level": self._assess_overall_risk(overall_compliance),
            "frameworks": {
                "ISO_27001": {
                    "compliance_percentage": round(iso_status["rate"] * 100, 2),
                    "total_controls": len(iso_controls),
                    "compliant": iso_status["compliant"],
                    "issues": iso_status["non_compliant"] + iso_status["partially_compliant"]
                },
                "NIST_800_53": {
                    "compliance_percentage": round(nist_status["rate"] * 100, 2),
                    "total_controls": len(nist_controls),
                    "compliant": nist_status["compliant"],
                    "issues": nist_status["non_compliant"] + nist_status["partially_compliant"]
                }
            },
            "key_issues": self._get_key_issues(),
            "next_review_date": self._get_next_review_date()
        }
    
    def _assess_overall_risk(self, compliance_rate: float) -> str:
        """Assess overall risk level based on compliance rate."""
        if compliance_rate >= 0.95:
            return "low"
        elif compliance_rate >= 0.85:
            return "medium"
        elif compliance_rate >= 0.70:
            return "high"
        else:
            return "critical"
    
    def _get_key_issues(self) -> List[str]:
        """Get key compliance issues requiring attention."""
        # This would analyze recent gaps and identify patterns
        return [
            "Network security controls require enhancement",
            "Audit logging needs centralized management",
            "Disaster recovery testing schedule overdue"
        ]
    
    def _get_next_review_date(self) -> str:
        """Calculate next quarterly review date."""
        now = datetime.now()
        current_quarter = (now.month - 1) // 3 + 1
        next_quarter = current_quarter % 4 + 1
        next_year = now.year if next_quarter > current_quarter else now.year + 1
        
        # First day of next quarter
        next_month = (next_quarter - 1) * 3 + 1
        next_date = datetime(next_year, next_month, 1)
        
        return next_date.isoformat()


# Global compliance engine instance
compliance_engine = ComplianceEngine()
