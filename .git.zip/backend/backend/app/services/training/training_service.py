from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import json


class UserRole(Enum):
    DASHBOARD_OPERATOR = "dashboard_operator"
    SECURITY_ANALYST = "security_analyst"
    ESCORT_PLANNER = "escort_planner"
    COMMANDER = "commander"
    TECHNICAL_TEAM = "technical_team"


class TrainingStatus(Enum):
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class TrainingModule:
    id: str
    title: str
    description: str
    duration_hours: int
    target_roles: List[UserRole]
    content: List[str]
    assessment_method: str
    pass_score: float


@dataclass
class UserTrainingRecord:
    user_id: str
    role: UserRole
    module_id: str
    status: TrainingStatus
    progress: float
    score: Optional[float]
    started_at: datetime
    completed_at: Optional[datetime]
    attempts: int


class TrainingService:
    """Service for managing user training and knowledge transfer."""
    
    def __init__(self):
        self.modules: Dict[str, TrainingModule] = {}
        self.user_records: Dict[str, List[UserTrainingRecord]] = {}
        self._initialize_modules()
    
    def _initialize_modules(self):
        """Initialize training modules as specified in DEFENDERS.md."""
        # Dashboard Operator Training (2 days)
        self.modules["dashboard_basics"] = TrainingModule(
            id="dashboard_basics",
            title="Dashboard Operations",
            description="3D map navigation, alerts handling, ACK procedures, level 4 alerts",
            duration_hours=16,
            target_roles=[UserRole.DASHBOARD_OPERATOR],
            content=[
                "System login and role-based access",
                "3D map navigation and layer management",
                "Alert protocol (4 levels + ACK/ESCALATE)",
                "Real-time monitoring dashboard",
                "Emergency response procedures",
                "PANIC scenario handling"
            ],
            assessment_method="practical_exercise + panic_scenario",
            pass_score=80.0
        )
        
        # Security Analyst Training (3 days)
        self.modules["intel_analysis"] = TrainingModule(
            id="intel_analysis",
            title="Intelligence Analysis",
            description="Intel module usage, SHAP interpretation, confidence validation",
            duration_hours=24,
            target_roles=[UserRole.SECURITY_ANALYST],
            content=[
                "Intel module overview and data sources",
                "Risk map interpretation",
                "SHAP values and model explainability",
                "Confidence scoring and validation",
                "Threat pattern recognition",
                "Area analysis (5 real areas)",
                "Report generation"
            ],
            assessment_method="area_analysis_exercise",
            pass_score=75.0
        )
        
        # Escort Planner Training (2 days)
        self.modules["escort_planning"] = TrainingModule(
            id="escort_planning",
            title="Escort Planning",
            description="Risk area editing, PACE methodology, scenario planning",
            duration_hours=16,
            target_roles=[UserRole.ESCORT_PLANNER],
            content=[
                "Risk area management and editing",
                "PACE methodology (Primary/Alternate/Contingency/Emergency)",
                "Route planning algorithms",
                "Team distribution optimization",
                "Checkpoint management",
                "Scenario creation and testing",
                "Backup plan development"
            ],
            assessment_method="plan_creation_exercise",
            pass_score=70.0
        )
        
        # Commander Training (1 day)
        self.modules["command_interface"] = TrainingModule(
            id="command_interface",
            title="Command Interface",
            description="Command view, PANIC procedures, AAR, report management",
            duration_hours=8,
            target_roles=[UserRole.COMMANDER],
            content=[
                "Command dashboard overview",
                "Situational awareness tools",
                "PANIC activation procedures",
                "After-Action Review (AAR) process",
                "Strategic decision making",
                "Report review and approval",
                "Crisis management"
            ],
            assessment_method="scenario_response_exercise",
            pass_score=85.0
        )
        
        # Technical Team Training (10 days)
        self.modules["technical_operations"] = TrainingModule(
            id="technical_operations",
            title="Technical Operations",
            description="Architecture, deployment, runbook, DR exercises",
            duration_hours=80,
            target_roles=[UserRole.TECHNICAL_TEAM],
            content=[
                "System architecture overview",
                "Deployment procedures",
                "Configuration management",
                "Monitoring and alerting",
                "Troubleshooting runbooks RB-01 to RB-05",
                "Disaster Recovery (DR) procedures",
                "Security protocols and encryption",
                "Performance optimization",
                "Backup and recovery",
                "Incident response",
                "DR drill execution"
            ],
            assessment_method="practical_exam + rb_exercises",
            pass_score=90.0
        )
    
    def get_module(self, module_id: str) -> Optional[TrainingModule]:
        """Get a training module by ID."""
        return self.modules.get(module_id)
    
    def get_modules_for_role(self, role: UserRole) -> List[TrainingModule]:
        """Get all training modules for a specific role."""
        return [
            module for module in self.modules.values()
            if role in module.target_roles
        ]
    
    def start_training(self, user_id: str, role: UserRole, module_id: str) -> bool:
        """Start a training module for a user."""
        module = self.get_module(module_id)
        if not module:
            return False
        
        if role not in module.target_roles:
            return False
        
        if user_id not in self.user_records:
            self.user_records[user_id] = []
        
        # Check if already in progress
        for record in self.user_records[user_id]:
            if record.module_id == module_id and record.status == TrainingStatus.IN_PROGRESS:
                return False
        
        # Create new training record
        record = UserTrainingRecord(
            user_id=user_id,
            role=role,
            module_id=module_id,
            status=TrainingStatus.IN_PROGRESS,
            progress=0.0,
            score=None,
            started_at=datetime.now(),
            completed_at=None,
            attempts=1
        )
        
        self.user_records[user_id].append(record)
        return True
    
    def update_progress(self, user_id: str, module_id: str, progress: float) -> bool:
        """Update training progress for a user."""
        if user_id not in self.user_records:
            return False
        
        for record in self.user_records[user_id]:
            if record.module_id == module_id and record.status == TrainingStatus.IN_PROGRESS:
                record.progress = min(progress, 100.0)
                return True
        
        return False
    
    def complete_training(self, user_id: str, module_id: str, score: float) -> bool:
        """Complete a training module with assessment score."""
        if user_id not in self.user_records:
            return False
        
        module = self.get_module(module_id)
        if not module:
            return False
        
        for record in self.user_records[user_id]:
            if record.module_id == module_id and record.status == TrainingStatus.IN_PROGRESS:
                record.status = TrainingStatus.COMPLETED if score >= module.pass_score else TrainingStatus.FAILED
                record.score = score
                record.completed_at = datetime.now()
                return True
        
        return False
    
    def get_user_progress(self, user_id: str) -> Dict[str, Any]:
        """Get training progress for a user."""
        if user_id not in self.user_records:
            return {"user_id": user_id, "records": [], "summary": self._empty_summary()}
        
        records = self.user_records[user_id]
        completed = sum(1 for r in records if r.status == TrainingStatus.COMPLETED)
        in_progress = sum(1 for r in records if r.status == TrainingStatus.IN_PROGRESS)
        failed = sum(1 for r in records if r.status == TrainingStatus.FAILED)
        
        avg_score = 0.0
        completed_records = [r for r in records if r.status == TrainingStatus.COMPLETED]
        if completed_records:
            avg_score = sum(r.score for r in completed_records) / len(completed_records)
        
        return {
            "user_id": user_id,
            "records": [
                {
                    "module_id": r.module_id,
                    "module_title": self.modules.get(r.module_id).title if r.module_id in self.modules else "Unknown",
                    "status": r.status.value,
                    "progress": r.progress,
                    "score": r.score,
                    "started_at": r.started_at.isoformat(),
                    "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                    "attempts": r.attempts
                }
                for r in records
            ],
            "summary": {
                "total_modules": len(records),
                "completed": completed,
                "in_progress": in_progress,
                "failed": failed,
                "completion_rate": completed / len(records) if records else 0,
                "average_score": avg_score
            }
        }
    
    def _empty_summary(self) -> Dict[str, Any]:
        """Return empty summary for users with no records."""
        return {
            "total_modules": 0,
            "completed": 0,
            "in_progress": 0,
            "failed": 0,
            "completion_rate": 0,
            "average_score": 0
        }
    
    def get_role_training_plan(self, role: UserRole) -> Dict[str, Any]:
        """Get training plan for a specific role."""
        modules = self.get_modules_for_role(role)
        total_hours = sum(module.duration_hours for module in modules)
        
        return {
            "role": role.value,
            "modules": [
                {
                    "id": module.id,
                    "title": module.title,
                    "description": module.description,
                    "duration_hours": module.duration_hours,
                    "content": module.content,
                    "assessment_method": module.assessment_method,
                    "pass_score": module.pass_score
                }
                for module in modules
            ],
            "total_duration_hours": total_hours,
            "total_duration_days": total_hours / 8
        }
    
    def get_all_training_plans(self) -> Dict[str, Any]:
        """Get training plans for all roles."""
        return {
            role.value: self.get_role_training_plan(role)
            for role in UserRole
        }
    
    def get_training_statistics(self) -> Dict[str, Any]:
        """Get overall training statistics."""
        total_users = len(self.user_records)
        total_records = sum(len(records) for records in self.user_records.values())
        
        completed_count = 0
        in_progress_count = 0
        failed_count = 0
        
        for records in self.user_records.values():
            for record in records:
                if record.status == TrainingStatus.COMPLETED:
                    completed_count += 1
                elif record.status == TrainingStatus.IN_PROGRESS:
                    in_progress_count += 1
                elif record.status == TrainingStatus.FAILED:
                    failed_count += 1
        
        return {
            "total_users": total_users,
            "total_training_records": total_records,
            "completed_trainings": completed_count,
            "in_progress_trainings": in_progress_count,
            "failed_trainings": failed_count,
            "overall_completion_rate": completed_count / total_records if total_records > 0 else 0,
            "modules_available": len(self.modules)
        }
    
    def reset_user_training(self, user_id: str, module_id: str) -> bool:
        """Reset a user's training progress for a module (for retake)."""
        if user_id not in self.user_records:
            return False
        
        for record in self.user_records[user_id]:
            if record.module_id == module_id:
                record.status = TrainingStatus.NOT_STARTED
                record.progress = 0.0
                record.score = None
                record.completed_at = None
                record.attempts += 1
                return True
        
        return False


# Global training service instance
training_service = TrainingService()
