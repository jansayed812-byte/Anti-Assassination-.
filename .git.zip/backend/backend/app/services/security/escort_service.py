from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from .routing_service import routing_service, Route


@dataclass
class TeamMember:
    id: str
    name: str
    role: str  # commander, driver, security, medic
    position: Dict[str, float]  # lat, lon
    status: str  # available, assigned, unavailable


@dataclass
class Checkpoint:
    id: str
    name: str
    location: Dict[str, float]
    priority: int
    estimated_arrival: str


@dataclass
class EscortPlan:
    plan_id: str
    team_id: str
    route: Route
    checkpoints: List[Checkpoint]
    team_distribution: Dict[str, List[str]]  # role -> member_ids
    backup_plans: List[Dict[str, Any]]
    created_at: datetime
    status: str  # planning, active, completed, cancelled


class EscortPlanningService:
    """Service for security escort planning and force distribution."""
    
    def __init__(self):
        self.teams: Dict[str, List[TeamMember]] = {}
        self.active_plans: Dict[str, EscortPlan] = {}
        self.plan_counter = 0
    
    def register_team(self, team_id: str, members: List[TeamMember]):
        """Register a security team."""
        self.teams[team_id] = members
        print(f"Registered team {team_id} with {len(members)} members")
    
    def create_escort_plan(self, team_id: str, start_location: Dict[str, float],
                          end_location: Dict[str, float],
                          constraints: List[str] = None) -> Optional[EscortPlan]:
        """Create a security escort plan."""
        if team_id not in self.teams:
            return None
        
        constraints = constraints or []
        
        # Generate sample network if not exists
        if not routing_service.nodes:
            routing_service.generate_sample_network(
                start_location["latitude"],
                start_location["longitude"]
            )
        
        # Calculate optimal route
        route_result = routing_service.calculate_route(
            start_location["latitude"],
            start_location["longitude"],
            end_location["latitude"],
            end_location["longitude"],
            constraints
        )
        
        if not route_result.get("route"):
            return None
        
        # Generate checkpoints
        checkpoints = self._generate_checkpoints(route_result["route"]["waypoints"])
        
        # Distribute team members
        team_distribution = self._distribute_team(self.teams[team_id])
        
        # Create backup plans
        backup_plans = self._generate_backup_plans(
            start_location,
            end_location,
            constraints
        )
        
        # Create plan
        self.plan_counter += 1
        plan = EscortPlan(
            plan_id=f"plan_{self.plan_counter}",
            team_id=team_id,
            route=Route(
                nodes=[],  # Not storing full nodes for efficiency
                total_distance=route_result["route"]["total_distance"],
                total_risk=route_result["route"]["total_risk"],
                estimated_time=route_result["route"]["estimated_time"]
            ),
            checkpoints=checkpoints,
            team_distribution=team_distribution,
            backup_plans=backup_plans,
            created_at=datetime.now(),
            status="planning"
        )
        
        self.active_plans[plan.plan_id] = plan
        return plan
    
    def _generate_checkpoints(self, waypoints: List[Dict[str, float]]) -> List[Checkpoint]:
        """Generate security checkpoints along the route."""
        checkpoints = []
        
        # Add checkpoint at start
        if waypoints:
            checkpoints.append(Checkpoint(
                id="checkpoint_start",
                name="Start Point",
                location=waypoints[0],
                priority=1,
                estimated_arrival=datetime.now().isoformat()
            ))
        
        # Add checkpoints at regular intervals
        for i, waypoint in enumerate(waypoints):
            if i > 0 and i % 5 == 0:  # Every 5th waypoint
                checkpoints.append(Checkpoint(
                    id=f"checkpoint_{i}",
                    name=f"Checkpoint {i}",
                    location=waypoint,
                    priority=2,
                    estimated_arrival=datetime.now().isoformat()
                ))
        
        # Add checkpoint at end
        if waypoints:
            checkpoints.append(Checkpoint(
                id="checkpoint_end",
                name="Destination",
                location=waypoints[-1],
                priority=1,
                estimated_arrival=datetime.now().isoformat()
            ))
        
        return checkpoints
    
    def _distribute_team(self, members: List[TeamMember]) -> Dict[str, List[str]]:
        """Distribute team members by role."""
        distribution = {}
        
        for member in members:
            if member.role not in distribution:
                distribution[member.role] = []
            distribution[member.role].append(member.id)
        
        return distribution
    
    def _generate_backup_plans(self, start_location: Dict[str, float],
                             end_location: Dict[str, float],
                             constraints: List[str]) -> List[Dict[str, Any]]:
        """Generate backup plans for emergency situations."""
        backup_plans = []
        
        # Alternative route avoiding high-risk areas
        if "avoid_high_risk" not in constraints:
            backup_plans.append({
                "type": "alternative_route",
                "description": "Alternative route avoiding high-risk areas",
                "trigger": "high_risk_detected"
            })
        
        # Emergency rendezvous point
        backup_plans.append({
            "type": "rendezvous",
            "description": "Emergency rendezvous at safe location",
            "location": {
                "latitude": start_location["latitude"] + 0.01,
                "longitude": start_location["longitude"] + 0.01
            },
            "trigger": "team_separated"
        })
        
        # Medical emergency plan
        backup_plans.append({
            "type": "medical",
            "description": "Medical emergency response plan",
            "nearest_hospital": "Find nearest medical facility",
            "trigger": "medical_emergency"
        })
        
        return backup_plans
    
    def activate_plan(self, plan_id: str) -> bool:
        """Activate an escort plan."""
        if plan_id not in self.active_plans:
            return False
        
        self.active_plans[plan_id].status = "active"
        return True
    
    def complete_plan(self, plan_id: str) -> bool:
        """Mark an escort plan as completed."""
        if plan_id not in self.active_plans:
            return False
        
        self.active_plans[plan_id].status = "completed"
        return True
    
    def cancel_plan(self, plan_id: str) -> bool:
        """Cancel an escort plan."""
        if plan_id not in self.active_plans:
            return False
        
        self.active_plans[plan_id].status = "cancelled"
        return True
    
    def get_plan(self, plan_id: str) -> Optional[Dict[str, Any]]:
        """Get escort plan details."""
        if plan_id not in self.active_plans:
            return None
        
        plan = self.active_plans[plan_id]
        return {
            "plan_id": plan.plan_id,
            "team_id": plan.team_id,
            "route": {
                "total_distance": plan.route.total_distance,
                "total_risk": plan.route.total_risk,
                "estimated_time": plan.route.estimated_time
            },
            "checkpoints": [
                {
                    "id": cp.id,
                    "name": cp.name,
                    "location": cp.location,
                    "priority": cp.priority,
                    "estimated_arrival": cp.estimated_arrival
                }
                for cp in plan.checkpoints
            ],
            "team_distribution": plan.team_distribution,
            "backup_plans": plan.backup_plans,
            "created_at": plan.created_at.isoformat(),
            "status": plan.status
        }
    
    def get_all_plans(self) -> List[Dict[str, Any]]:
        """Get all escort plans."""
        return [
            self.get_plan(plan_id)
            for plan_id in self.active_plans.keys()
        ]
    
    def get_team_status(self, team_id: str) -> Optional[Dict[str, Any]]:
        """Get team status."""
        if team_id not in self.teams:
            return None
        
        members = self.teams[team_id]
        return {
            "team_id": team_id,
            "member_count": len(members),
            "members": [
                {
                    "id": m.id,
                    "name": m.name,
                    "role": m.role,
                    "position": m.position,
                    "status": m.status
                }
                for m in members
            ]
        }


# Global escort planning service instance
escort_planning_service = EscortPlanningService()
