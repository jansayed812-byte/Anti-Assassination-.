from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import hashlib
import secrets
from cryptography.fernet import Fernet
import base64


class EncryptionMethod(Enum):
    AES_256_GCM = "AES-256-GCM"
    AES_256_CBC = "AES-256-CBC"
    CHACHA20_POLY1305 = "ChaCha20-Poly1305"


class SecurityLevel(Enum):
    STANDARD = "standard"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class EncryptionKey:
    key_id: str
    key_hash: str
    created_at: datetime
    expires_at: datetime
    algorithm: EncryptionMethod
    status: str  # active, expired, revoked


class AdvancedSecurityService:
    """Service for advanced security features including encryption, key management, and security protocols."""
    
    def __init__(self):
        self.encryption_keys: Dict[str, EncryptionKey] = {}
        self.encryption_key_counter = 0
        self.active_cipher: Optional[Fernet] = None
        self.security_audit_log: List[Dict[str, Any]] = []
        self._initialize_encryption()
    
    def _initialize_encryption(self):
        """Initialize encryption with a master key."""
        # Generate a master key for encryption
        master_key = self._generate_encryption_key()
        self.active_cipher = Fernet(master_key)
        
        # Register the master key
        self._register_key(master_key, EncryptionMethod.AES_256_GCM)
    
    def _generate_encryption_key(self) -> bytes:
        """Generate a secure encryption key."""
        return Fernet.generate_key()
    
    def _register_key(self, key: bytes, algorithm: EncryptionMethod) -> EncryptionKey:
        """Register an encryption key."""
        self.encryption_key_counter += 1
        key_id = f"key_{self.encryption_key_counter}"
        
        key_hash = hashlib.sha256(key).hexdigest()
        
        encryption_key = EncryptionKey(
            key_id=key_id,
            key_hash=key_hash,
            created_at=datetime.now(),
            expires_at=datetime.now() + timedelta(days=90),  # 90-day rotation
            algorithm=algorithm,
            status="active"
        )
        
        self.encryption_keys[key_id] = encryption_key
        return encryption_key
    
    def encrypt_data(self, data: str, security_level: SecurityLevel = SecurityLevel.STANDARD) -> Dict[str, Any]:
        """Encrypt data with appropriate security level."""
        if not self.active_cipher:
            raise RuntimeError("Encryption not initialized")
        
        try:
            encrypted_data = self.active_cipher.encrypt(data.encode())
            
            # Log encryption operation
            self._log_security_event(
                "encryption",
                f"Data encrypted with {security_level.value} security level",
                {"data_length": len(data), "security_level": security_level.value}
            )
            
            return {
                "encrypted_data": base64.b64encode(encrypted_data).decode(),
                "key_id": list(self.encryption_keys.keys())[-1],
                "algorithm": "AES-256-GCM",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            self._log_security_event("encryption_error", str(e), {})
            raise
    
    def decrypt_data(self, encrypted_data: str) -> Dict[str, Any]:
        """Decrypt data."""
        if not self.active_cipher:
            raise RuntimeError("Encryption not initialized")
        
        try:
            encrypted_bytes = base64.b64decode(encrypted_data.encode())
            decrypted_data = self.active_cipher.decrypt(encrypted_bytes).decode()
            
            # Log decryption operation
            self._log_security_event(
                "decryption",
                "Data decrypted successfully",
                {"data_length": len(decrypted_data)}
            )
            
            return {
                "decrypted_data": decrypted_data,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            self._log_security_event("decryption_error", str(e), {})
            raise
    
    def rotate_encryption_key(self) -> EncryptionKey:
        """Rotate the encryption key."""
        old_key_id = list(self.encryption_keys.keys())[-1] if self.encryption_keys else None
        
        # Generate new key
        new_key = self._generate_encryption_key()
        new_key_obj = self._register_key(new_key, EncryptionMethod.AES_256_GCM)
        
        # Update active cipher
        self.active_cipher = Fernet(new_key)
        
        # Mark old key as expired
        if old_key_id and old_key_id in self.encryption_keys:
            self.encryption_keys[old_key_id].status = "expired"
        
        # Log key rotation
        self._log_security_event(
            "key_rotation",
            f"Encryption key rotated from {old_key_id} to {new_key_obj.key_id}",
            {"old_key_id": old_key_id, "new_key_id": new_key_obj.key_id}
        )
        
        return new_key_obj
    
    def revoke_key(self, key_id: str) -> bool:
        """Revoke an encryption key."""
        if key_id not in self.encryption_keys:
            return False
        
        self.encryption_keys[key_id].status = "revoked"
        
        # Log key revocation
        self._log_security_event(
            "key_revocation",
            f"Encryption key {key_id} revoked",
            {"key_id": key_id}
        )
        
        return True
    
    def get_key_status(self, key_id: str) -> Optional[Dict[str, Any]]:
        """Get status of an encryption key."""
        key = self.encryption_keys.get(key_id)
        if not key:
            return None
        
        return {
            "key_id": key.key_id,
            "key_hash": key.key_hash,
            "created_at": key.created_at.isoformat(),
            "expires_at": key.expires_at.isoformat(),
            "algorithm": key.algorithm.value,
            "status": key.status
        }
    
    def get_all_keys(self) -> List[Dict[str, Any]]:
        """Get all encryption keys."""
        return [
            self.get_key_status(key_id)
            for key_id in self.encryption_keys.keys()
        ]
    
    def check_key_expiry(self) -> List[str]:
        """Check for expired keys."""
        expired_keys = []
        current_time = datetime.now()
        
        for key_id, key in self.encryption_keys.items():
            if key.expires_at < current_time and key.status == "active":
                expired_keys.append(key_id)
                key.status = "expired"
        
        return expired_keys
    
    def _log_security_event(self, event_type: str, description: str, metadata: Dict[str, Any]):
        """Log a security event."""
        self.security_audit_log.append({
            "event_type": event_type,
            "description": description,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata
        })
        
        # Keep log size manageable
        if len(self.security_audit_log) > 10000:
            self.security_audit_log = self.security_audit_log[-5000:]
    
    def get_security_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get security audit log."""
        return self.security_audit_log[-limit:]
    
    def generate_security_token(self, user_id: str, expiry_hours: int = 24) -> str:
        """Generate a secure token for a user."""
        token_data = f"{user_id}:{datetime.now().timestamp()}:{secrets.token_hex(16)}"
        token_hash = hashlib.sha256(token_data.encode()).hexdigest()
        
        self._log_security_event(
            "token_generation",
            f"Security token generated for user {user_id}",
            {"user_id": user_id, "expiry_hours": expiry_hours}
        )
        
        return token_hash
    
    def validate_security_token(self, token: str, user_id: str) -> bool:
        """Validate a security token."""
        # In production, this would check against stored tokens
        # For now, perform basic validation
        self._log_security_event(
            "token_validation",
            f"Security token validation for user {user_id}",
            {"user_id": user_id, "valid": len(token) == 64}  # SHA256 hash length
        )
        
        return len(token) == 64  # Basic validation
    
    def perform_security_scan(self) -> Dict[str, Any]:
        """Perform a comprehensive security scan."""
        scan_results = {
            "scan_timestamp": datetime.now().isoformat(),
            "key_expiry_check": self.check_key_expiry(),
            "active_keys": len([k for k in self.encryption_keys.values() if k.status == "active"]),
            "expired_keys": len([k for k in self.encryption_keys.values() if k.status == "expired"]),
            "revoked_keys": len([k for k in self.encryption_keys.values() if k.status == "revoked"]),
            "audit_log_size": len(self.security_audit_log),
            "encryption_active": self.active_cipher is not None,
            "recommendations": []
        }
        
        # Generate recommendations
        if scan_results["expired_keys"] > 0:
            scan_results["recommendations"].append("Rotate expired encryption keys")
        
        if scan_results["active_keys"] > 5:
            scan_results["recommendations"].append("Review and clean up old encryption keys")
        
        if not scan_results["encryption_active"]:
            scan_results["recommendations"].append("Initialize encryption system")
        
        return scan_results


# Global advanced security service instance
advanced_security_service = AdvancedSecurityService()