import heapq
import math
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Node:
    id: str
    latitude: float
    longitude: float
    risk_level: float  # 0-1, higher is more risky


@dataclass
class Edge:
    from_node: str
    to_node: str
    distance: float
    risk: float


@dataclass
class Route:
    nodes: List[Node]
    total_distance: float
    total_risk: float
    estimated_time: float


class RoutingService:
    """Service for security-aware routing using A* algorithm."""
    
    def __init__(self):
        self.nodes: Dict[str, Node] = {}
        self.edges: Dict[str, List[Edge]] = {}
        self.risk_map: Dict[str, float] = {}
    
    def add_node(self, node: Node):
        """Add a node to the graph."""
        self.nodes[node.id] = node
        self.edges[node.id] = []
    
    def add_edge(self, edge: Edge):
        """Add an edge to the graph."""
        if edge.from_node in self.edges:
            self.edges[edge.from_node].append(edge)
    
    def set_risk_level(self, location_id: str, risk_level: float):
        """Set risk level for a location."""
        self.risk_map[location_id] = risk_level
    
    def haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two points using Haversine formula."""
        R = 6371000  # Earth's radius in meters
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        
        a = (math.sin(delta_lat / 2) ** 2 +
             math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2)
        c = 2 * math.asin(math.sqrt(a))
        
        return R * c
    
    def heuristic(self, node: Node, goal: Node) -> float:
        """Heuristic function for A* algorithm (distance + risk)."""
        distance = self.haversine_distance(
            node.latitude, node.longitude,
            goal.latitude, goal.longitude
        )
        risk = self.risk_map.get(node.id, 0.5)
        return distance * (1 + risk * 2)  # Weight risk heavily
    
    def a_star(self, start_id: str, goal_id: str) -> Optional[Route]:
        """Find optimal route using A* algorithm."""
        if start_id not in self.nodes or goal_id not in self.nodes:
            return None
        
        start = self.nodes[start_id]
        goal = self.nodes[goal_id]
        
        # Priority queue: (f_score, node_id)
        open_set = [(0, start_id)]
        came_from: Dict[str, str] = {}
        
        g_score: Dict[str, float] = {node_id: float('inf') for node_id in self.nodes}
        g_score[start_id] = 0
        
        f_score: Dict[str, float] = {node_id: float('inf') for node_id in self.nodes}
        f_score[start_id] = self.heuristic(start, goal)
        
        while open_set:
            current_f, current_id = heapq.heappop(open_set)
            
            if current_id == goal_id:
                return self._reconstruct_path(came_from, current_id)
            
            for edge in self.edges.get(current_id, []):
                neighbor_id = edge.to_node
                
                # Calculate tentative g_score
                tentative_g = g_score[current_id] + edge.distance * (1 + edge.risk)
                
                if tentative_g < g_score[neighbor_id]:
                    came_from[neighbor_id] = current_id
                    g_score[neighbor_id] = tentative_g
                    f_score[neighbor_id] = tentative_g + self.heuristic(
                        self.nodes[neighbor_id], goal
                    )
                    heapq.heappush(open_set, (f_score[neighbor_id], neighbor_id))
        
        return None  # No path found
    
    def _reconstruct_path(self, came_from: Dict[str, str], current_id: str) -> Route:
        """Reconstruct path from A* search."""
        path = []
        total_distance = 0
        total_risk = 0
        
        while current_id in came_from:
            node = self.nodes[current_id]
            path.append(node)
            
            # Find edge to previous node
            prev_id = came_from[current_id]
            for edge in self.edges.get(prev_id, []):
                if edge.to_node == current_id:
                    total_distance += edge.distance
                    total_risk += edge.risk
                    break
            
            current_id = prev_id
        
        # Add start node
        path.append(self.nodes[current_id])
        path.reverse()
        
        # Estimate time (assuming average speed of 30 km/h in urban areas)
        estimated_time = total_distance / (30 * 1000 / 3600)  # seconds
        
        return Route(
            nodes=path,
            total_distance=total_distance,
            total_risk=total_risk / len(path) if path else 0,
            estimated_time=estimated_time
        )
    
    def calculate_route(self, start_lat: float, start_lon: float,
                       end_lat: float, end_lon: float,
                       constraints: List[str] = None) -> Dict[str, Any]:
        """Calculate optimal security route between two points."""
        constraints = constraints or []
        
        # Find nearest nodes to start and end points
        start_node = self._find_nearest_node(start_lat, start_lon)
        end_node = self._find_nearest_node(end_lat, end_lon)
        
        if not start_node or not end_node:
            return {
                "error": "Could not find suitable nodes for start/end points",
                "route": None
            }
        
        # Apply constraints
        if "avoid_high_risk" in constraints:
            self._apply_risk_avoidance()
        
        # Calculate route
        route = self.a_star(start_node.id, end_node.id)
        
        if route:
            return {
                "route": {
                    "waypoints": [
                        {
                            "latitude": node.latitude,
                            "longitude": node.longitude,
                            "risk_level": self.risk_map.get(node.id, 0.5)
                        }
                        for node in route.nodes
                    ],
                    "total_distance": route.total_distance,
                    "total_risk": route.total_risk,
                    "estimated_time": route.estimated_time,
                    "waypoint_count": len(route.nodes)
                },
                "constraints_applied": constraints
            }
        else:
            return {
                "error": "Could not find a suitable route",
                "route": None
            }
    
    def _find_nearest_node(self, lat: float, lon: float) -> Optional[Node]:
        """Find the nearest node to a given point."""
        if not self.nodes:
            return None
        
        nearest_node = None
        min_distance = float('inf')
        
        for node in self.nodes.values():
            distance = self.haversine_distance(lat, lon, node.latitude, node.longitude)
            if distance < min_distance:
                min_distance = distance
                nearest_node = node
        
        return nearest_node
    
    def _apply_risk_avoidance(self):
        """Apply risk avoidance by increasing edge costs for high-risk areas."""
        for node_id, edges in self.edges.items():
            risk = self.risk_map.get(node_id, 0.5)
            if risk > 0.7:  # High risk threshold
                for edge in edges:
                    edge.risk *= 2  # Double the risk cost
    
    def generate_sample_network(self, center_lat: float = 35.6892, 
                               center_lon: float = 51.3890, 
                               radius: float = 0.01):
        """Generate a sample network for testing."""
        import random
        
        # Generate nodes
        for i in range(20):
            lat = center_lat + random.uniform(-radius, radius)
            lon = center_lon + random.uniform(-radius, radius)
            risk = random.uniform(0, 1)
            
            node = Node(
                id=f"node_{i}",
                latitude=lat,
                longitude=lon,
                risk_level=risk
            )
            self.add_node(node)
            self.set_risk_level(node.id, risk)
        
        # Generate edges (connect nearby nodes)
        node_ids = list(self.nodes.keys())
        for i, node_id in enumerate(node_ids):
            for j, other_id in enumerate(node_ids):
                if i != j:
                    node = self.nodes[node_id]
                    other = self.nodes[other_id]
                    distance = self.haversine_distance(
                        node.latitude, node.longitude,
                        other.latitude, other.longitude
                    )
                    
                    # Connect if within reasonable distance
                    if distance < 2000:  # 2km
                        avg_risk = (node.risk_level + other.risk_level) / 2
                        edge = Edge(
                            from_node=node_id,
                            to_node=other_id,
                            distance=distance,
                            risk=avg_risk
                        )
                        self.add_edge(edge)


# Global routing service instance
routing_service = RoutingService()
