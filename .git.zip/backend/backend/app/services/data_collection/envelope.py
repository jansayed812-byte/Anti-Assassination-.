from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
import uuid
import hashlib
import json
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.backends import default_backend


class SourceType(Enum):
    GNSS = "gnss"
    INS = "ins"
    WIFI = "wifi"
    BLE = "ble"
    CELLULAR = "cellular"
    TELEMETRY = "telemetry"
    CAMERA = "camera"
    VISION = "vision"


class FixType(Enum):
    NO_FIX = "no_fix"
    _2D = "2d"
    _3D = "3d"
    _3D_DIFF = "3d_diff"


@dataclass
class QualityMetrics:
    hdop: float  # Horizontal dilution of precision
    fix: str    # Fix type
    confidence: float  # Overall confidence score
    vdop: Optional[float] = None  # Vertical dilution of precision
    pdop: Optional[float] = None  # Position dilution of precision
    satellite_count: Optional[int] = None
    signal_strength: Optional[float] = None


@dataclass
class IntegrityInfo:
    hash: str  # SHA256 hash
    signature: Optional[str] = None  # Digital signature
    checksum: Optional[str] = None  # Additional checksum
    version: str = "1.0"


@dataclass
class DataEnvelope:
    """Standardized data collection envelope as per architecture spec."""
    event_id: str
    source_id: str
    source_type: str
    captured_at: str  # ISO 8601 format
    received_at: str  # ISO 8601 format
    sequence: int
    quality: Dict[str, Any]
    payload: Dict[str, Any]
    integrity: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert envelope to dictionary."""
        return asdict(self)
    
    def to_json(self) -> str:
        """Convert envelope to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    def validate_integrity(self) -> bool:
        """Validate the integrity hash."""
        payload_str = json.dumps(self.payload, sort_keys=True)
        calculated_hash = hashlib.sha256(payload_str.encode()).hexdigest()
        return calculated_hash == self.integrity.get("hash", "")


class EnvelopeFactory:
    """Factory for creating standardized data envelopes."""
    
    def __init__(self):
        self._sequence_counters: Dict[str, int] = {}
    
    def create_envelope(
        self,
        source_id: str,
        source_type: SourceType,
        payload: Dict[str, Any],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None,
        sign: bool = False
    ) -> DataEnvelope:
        """Create a new data envelope with proper structure."""
        
        # Generate unique event ID
        event_id = str(uuid.uuid4())
        
        # Get or initialize sequence counter
        if source_id not in self._sequence_counters:
            self._sequence_counters[source_id] = 0
        sequence = self._sequence_counters[source_id]
        self._sequence_counters[source_id] += 1
        
        # Set timestamps
        if captured_at is None:
            captured_at = datetime.utcnow()
        received_at = datetime.utcnow()
        
        # Calculate integrity hash
        payload_str = json.dumps(payload, sort_keys=True)
        hash_value = hashlib.sha256(payload_str.encode()).hexdigest()
        
        # Build integrity info
        integrity_info = {
            "hash": f"sha256:{hash_value}",
            "version": "1.0"
        }
        
        if sign:
            # In production, this would use actual signing
            integrity_info["signature"] = "placeholder_signature"
        
        # Build quality dict
        quality_dict = {
            "hdop": quality.hdop,
            "fix": quality.fix,
            "confidence": quality.confidence
        }
        
        if quality.vdop is not None:
            quality_dict["vdop"] = quality.vdop
        if quality.pdop is not None:
            quality_dict["pdop"] = quality.pdop
        if quality.satellite_count is not None:
            quality_dict["satellite_count"] = quality.satellite_count
        if quality.signal_strength is not None:
            quality_dict["signal_strength"] = quality.signal_strength
        
        return DataEnvelope(
            event_id=event_id,
            source_id=source_id,
            source_type=source_type.value,
            captured_at=captured_at.isoformat() + "Z",
            received_at=received_at.isoformat() + "Z",
            sequence=sequence,
            quality=quality_dict,
            payload=payload,
            integrity=integrity_info
        )
    
    def create_gnss_envelope(
        self,
        source_id: str,
        lat: float,
        lon: float,
        alt_m: float,
        speed_mps: float,
        heading: float,
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create GNSS-specific envelope."""
        payload = {
            "lat": lat,
            "lon": lon,
            "alt_m": alt_m,
            "speed_mps": speed_mps,
            "heading": heading,
            "satellites": quality.satellite_count or 0
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.GNSS,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_ins_envelope(
        self,
        source_id: str,
        lat: float,
        lon: float,
        alt_m: float,
        velocity: Dict[str, float],
        orientation: Dict[str, float],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create INS-specific envelope."""
        payload = {
            "lat": lat,
            "lon": lon,
            "alt_m": alt_m,
            "velocity": velocity,
            "orientation": orientation
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.INS,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_wifi_envelope(
        self,
        source_id: str,
        access_points: List[Dict[str, Any]],
        estimated_position: Dict[str, float],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create WiFi RTT envelope."""
        payload = {
            "access_points": access_points,
            "estimated_position": estimated_position
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.WIFI,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_ble_envelope(
        self,
        source_id: str,
        beacons: List[Dict[str, Any]],
        estimated_position: Dict[str, float],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create BLE beacon envelope."""
        payload = {
            "beacons": beacons,
            "estimated_position": estimated_position
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.BLE,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_cellular_envelope(
        self,
        source_id: str,
        cell_towers: List[Dict[str, Any]],
        estimated_position: Dict[str, float],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create cellular positioning envelope."""
        payload = {
            "cell_towers": cell_towers,
            "estimated_position": estimated_position
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.CELLULAR,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_telemetry_envelope(
        self,
        source_id: str,
        device_type: str,
        telemetry_data: Dict[str, Any],
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create device telemetry envelope."""
        payload = {
            "device_type": device_type,
            "telemetry": telemetry_data
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.TELEMETRY,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )
    
    def create_vision_envelope(
        self,
        source_id: str,
        detections: List[Dict[str, Any]],
        confidence: float,
        model_version: str,
        quality: QualityMetrics,
        captured_at: Optional[datetime] = None
    ) -> DataEnvelope:
        """Create vision inference envelope."""
        payload = {
            "detections": detections,
            "model_confidence": confidence,
            "model_version": model_version
        }
        
        return self.create_envelope(
            source_id=source_id,
            source_type=SourceType.VISION,
            payload=payload,
            quality=quality,
            captured_at=captured_at
        )


class OfflineBuffer:
    """Local buffer for offline scenarios with idempotency."""
    
    def __init__(self, max_size: int = 10000):
        self.buffer: List[DataEnvelope] = []
        self.max_size = max_size
        self._processed_ids: set = set()
    
    def add_envelope(self, envelope: DataEnvelope) -> bool:
        """Add envelope to buffer with idempotency check."""
        if envelope.event_id in self._processed_ids:
            return False  # Duplicate, skip
        
        if len(self.buffer) >= self.max_size:
            self.buffer.pop(0)  # Remove oldest
        
        self.buffer.append(envelope)
        self._processed_ids.add(envelope.event_id)
        return True
    
    def get_envelopes(self, limit: Optional[int] = None) -> List[DataEnvelope]:
        """Get envelopes from buffer."""
        if limit:
            return self.buffer[-limit:]
        return self.buffer.copy()
    
    def clear_processed(self, event_ids: List[str]) -> int:
        """Clear processed envelopes by event IDs."""
        cleared = 0
        self.buffer = [env for env in self.buffer if env.event_id not in event_ids]
        for event_id in event_ids:
            if event_id in self._processed_ids:
                self._processed_ids.remove(event_id)
                cleared += 1
        return cleared
    
    def get_buffer_size(self) -> int:
        """Get current buffer size."""
        return len(self.buffer)
    
    def get_buffer_status(self) -> Dict[str, Any]:
        """Get buffer status information."""
        return {
            "current_size": len(self.buffer),
            "max_size": self.max_size,
            "utilization": len(self.buffer) / self.max_size,
            "oldest_timestamp": self.buffer[0].captured_at if self.buffer else None,
            "newest_timestamp": self.buffer[-1].captured_at if self.buffer else None,
            "processed_count": len(self._processed_ids)
        }


# Global instances
envelope_factory = EnvelopeFactory()
offline_buffer = OfflineBuffer()