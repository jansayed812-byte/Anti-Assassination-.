from pymavlink import mavutil
from typing import Optional, Dict, Any, Callable
from dataclasses import dataclass
from datetime import datetime
import threading
import time


@dataclass
class DroneData:
    drone_id: str
    latitude: float
    longitude: float
    altitude: float
    heading: float
    speed: float
    battery: float
    timestamp: datetime


class MAVLinkService:
    """Service for MAVLink communication with drones."""
    
    def __init__(self, connection_string: str = "udpin:0.0.0.0:14550"):
        self.connection_string = connection_string
        self.mav_connection: Optional[mavutil.mavlink_connection] = None
        self.is_connected = False
        self.is_running = False
        self._thread: Optional[threading.Thread] = None
        self.callbacks = []
        self.current_drone_data: Optional[DroneData] = None
    
    def connect(self) -> bool:
        """Connect to MAVLink endpoint."""
        try:
            self.mav_connection = mavutil.mavlink_connection(self.connection_string)
            self.mav_connection.wait_heartbeat()
            self.is_connected = True
            print(f"Connected to MAVLink endpoint: {self.connection_string}")
            return True
        except Exception as e:
            print(f"Failed to connect to MAVLink: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from MAVLink endpoint."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        if self.mav_connection:
            self.mav_connection.close()
        self.is_connected = False
        print("Disconnected from MAVLink")
    
    def start_listening(self):
        """Start listening for MAVLink messages."""
        if not self.is_connected:
            if not self.connect():
                return False
        
        self.is_running = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        print("Started MAVLink listening")
        return True
    
    def stop_listening(self):
        """Stop listening for MAVLink messages."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        print("Stopped MAVLink listening")
    
    def _listen_loop(self):
        """Main loop for listening to MAVLink messages."""
        while self.is_running and self.mav_connection:
            try:
                msg = self.mav_connection.recv_match()
                if msg:
                    self._process_message(msg)
            except Exception as e:
                print(f"Error receiving MAVLink message: {e}")
                time.sleep(0.1)
    
    def _process_message(self, msg):
        """Process incoming MAVLink message."""
        try:
            if msg.get_type() == 'GLOBAL_POSITION_INT':
                # Extract position data
                drone_data = DroneData(
                    drone_id=str(self.mav_connection.target_system),
                    latitude=msg.lat / 1e7,
                    longitude=msg.lon / 1e7,
                    altitude=msg.alt / 1e3,
                    heading=msg.hdg / 100,
                    speed=msg.vel / 100,
                    battery=0.0,  # Would come from SYS_STATUS message
                    timestamp=datetime.now()
                )
                
                self.current_drone_data = drone_data
                
                # Notify callbacks
                for callback in self.callbacks:
                    try:
                        callback(drone_data)
                    except Exception as e:
                        print(f"Error in MAVLink callback: {e}")
            
            elif msg.get_type() == 'SYS_STATUS':
                # Extract battery data
                if self.current_drone_data:
                    battery = msg.battery_remaining / 100  # Percentage
                    self.current_drone_data.battery = battery
            
        except Exception as e:
            print(f"Error processing MAVLink message: {e}")
    
    def add_callback(self, callback: Callable[[DroneData], None]):
        """Add a callback for drone data updates."""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback: Callable[[DroneData], None]):
        """Remove a callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def get_current_drone_data(self) -> Optional[DroneData]:
        """Get current drone data."""
        return self.current_drone_data
    
    def send_command(self, command_type: int, params: list) -> bool:
        """Send a command to the drone."""
        if not self.is_connected or not self.mav_connection:
            return False
        
        try:
            self.mav_connection.mav.command_long_send(
                self.mav_connection.target_system,
                self.mav_connection.target_component,
                command_type,
                0,  # confirmation
                *params
            )
            return True
        except Exception as e:
            print(f"Error sending MAVLink command: {e}")
            return False
    
    def arm_drone(self) -> bool:
        """Arm the drone."""
        return self.send_command(
            mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
            [1, 0, 0, 0, 0, 0, 0]
        )
    
    def disarm_drone(self) -> bool:
        """Disarm the drone."""
        return self.send_command(
            mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
            [0, 0, 0, 0, 0, 0, 0]
        )
    
    def takeoff(self, altitude: float) -> bool:
        """Command drone to takeoff."""
        return self.send_command(
            mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
            [0, 0, 0, 0, altitude, 0, 0]
        )
    
    def land(self) -> bool:
        """Command drone to land."""
        return self.send_command(
            mavutil.mavlink.MAV_CMD_NAV_LAND,
            [0, 0, 0, 0, 0, 0, 0]
        )
    
    def goto_position(self, latitude: float, longitude: float, altitude: float) -> bool:
        """Command drone to go to specific position."""
        if not self.is_connected or not self.mav_connection:
            return False
        
        try:
            self.mav_connection.mav.set_position_target_global_int_send(
                0,  # time_boot_ms
                self.mav_connection.target_system,
                self.mav_connection.target_component,
                mavutil.mavlink.MAV_FRAME_GLOBAL_RELATIVE_ALT_INT,
                int(0b110111111000),  # type_mask (only x, y, z)
                int(latitude * 1e7),  # x
                int(longitude * 1e7),  # y
                altitude,  # z
                0, 0, 0,  # vx, vy, vz
                0, 0, 0,  # afx, afy, afz
                0, 0  # yaw, yaw_rate
            )
            return True
        except Exception as e:
            print(f"Error sending goto command: {e}")
            return False
    
    def simulate_drone_data(self) -> DroneData:
        """Generate simulated drone data for testing."""
        import random
        return DroneData(
            drone_id="sim_drone_1",
            latitude=35.6892 + random.uniform(-0.001, 0.001),
            longitude=51.3890 + random.uniform(-0.001, 0.001),
            altitude=100.0 + random.uniform(-10, 10),
            heading=random.uniform(0, 360),
            speed=random.uniform(0, 20),
            battery=random.uniform(50, 100),
            timestamp=datetime.now()
        )


# Global MAVLink service instance
mavlink_service = MAVLinkService()
