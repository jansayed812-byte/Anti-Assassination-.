from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
import threading
import time
from .mavlink_service import MAVLinkService, DroneData


@dataclass
class Device:
    device_id: str
    device_type: str  # GPS, DRONE, IOT, BEACON
    name: str
    status: str  # online, offline, error
    last_seen: datetime
    battery_level: float
    configuration: Dict[str, Any]
    data: Optional[Dict[str, Any]] = None


class DeviceManager:
    """Manager for handling multiple external devices."""
    
    def __init__(self):
        self.devices: Dict[str, Device] = {}
        self.mavlink_service = MAVLinkService()
        self.is_running = False
        self._thread: Optional[threading.Thread] = None
        self.update_interval = 5.0  # Check device status every 5 seconds
        self.callbacks = []
    
    def start(self):
        """Start the device manager."""
        if self.is_running:
            return
        
        self.is_running = True
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()
        
        # Start MAVLink service
        self.mavlink_service.add_callback(self._on_drone_data)
        self.mavlink_service.start_listening()
        
        print("Device manager started")
    
    def stop(self):
        """Stop the device manager."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        
        self.mavlink_service.stop_listening()
        print("Device manager stopped")
    
    def _update_loop(self):
        """Main update loop for device status checking."""
        while self.is_running:
            try:
                # Check device status
                self._check_device_status()
                
                # Sleep for update interval
                time.sleep(self.update_interval)
            except Exception as e:
                print(f"Error in device manager update loop: {e}")
                time.sleep(1)
    
    def _check_device_status(self):
        """Check status of all devices."""
        current_time = datetime.now()
        timeout_threshold = 60  # seconds
        
        for device_id, device in self.devices.items():
            time_since_last_seen = (current_time - device.last_seen).total_seconds()
            
            if time_since_last_seen > timeout_threshold and device.status == "online":
                device.status = "offline"
                print(f"Device {device_id} went offline")
    
    def _on_drone_data(self, drone_data: DroneData):
        """Callback for drone data updates."""
        device_id = drone_data.drone_id
        
        if device_id not in self.devices:
            # Auto-register drone
            self.register_device(
                device_id=device_id,
                device_type="DRONE",
                name=f"Drone {device_id}",
                configuration={}
            )
        
        # Update device data
        device = self.devices[device_id]
        device.status = "online"
        device.last_seen = datetime.now()
        device.battery_level = drone_data.battery
        device.data = {
            "latitude": drone_data.latitude,
            "longitude": drone_data.longitude,
            "altitude": drone_data.altitude,
            "heading": drone_data.heading,
            "speed": drone_data.speed
        }
        
        # Notify callbacks
        for callback in self.callbacks:
            try:
                callback(device_id, device.data)
            except Exception as e:
                print(f"Error in device callback: {e}")
    
    def register_device(self, device_id: str, device_type: str, name: str, 
                       configuration: Dict[str, Any]) -> bool:
        """Register a new device."""
        if device_id in self.devices:
            return False
        
        device = Device(
            device_id=device_id,
            device_type=device_type,
            name=name,
            status="offline",
            last_seen=datetime.now(),
            battery_level=100.0,
            configuration=configuration
        )
        
        self.devices[device_id] = device
        print(f"Registered device: {device_id} ({device_type})")
        return True
    
    def unregister_device(self, device_id: str) -> bool:
        """Unregister a device."""
        if device_id not in self.devices:
            return False
        
        del self.devices[device_id]
        print(f"Unregistered device: {device_id}")
        return True
    
    def get_device(self, device_id: str) -> Optional[Device]:
        """Get device information."""
        return self.devices.get(device_id)
    
    def get_all_devices(self) -> List[Dict[str, Any]]:
        """Get all devices."""
        return [
            {
                "device_id": device.device_id,
                "device_type": device.device_type,
                "name": device.name,
                "status": device.status,
                "last_seen": device.last_seen.isoformat(),
                "battery_level": device.battery_level,
                "configuration": device.configuration,
                "data": device.data
            }
            for device in self.devices.values()
        ]
    
    def get_devices_by_type(self, device_type: str) -> List[Device]:
        """Get devices by type."""
        return [
            device for device in self.devices.values()
            if device.device_type == device_type
        ]
    
    def update_device_status(self, device_id: str, status: str) -> bool:
        """Update device status."""
        if device_id not in self.devices:
            return False
        
        self.devices[device_id].status = status
        self.devices[device_id].last_seen = datetime.now()
        return True
    
    def update_device_data(self, device_id: str, data: Dict[str, Any]) -> bool:
        """Update device data."""
        if device_id not in self.devices:
            return False
        
        self.devices[device_id].data = data
        self.devices[device_id].last_seen = datetime.now()
        self.devices[device_id].status = "online"
        return True
    
    def send_command_to_device(self, device_id: str, command: str, 
                              params: Dict[str, Any]) -> bool:
        """Send a command to a specific device."""
        device = self.devices.get(device_id)
        if not device:
            return False
        
        if device.device_type == "DRONE":
            # Handle drone commands via MAVLink
            if command == "arm":
                return self.mavlink_service.arm_drone()
            elif command == "disarm":
                return self.mavlink_service.disarm_drone()
            elif command == "takeoff":
                return self.mavlink_service.takeoff(params.get("altitude", 10))
            elif command == "land":
                return self.mavlink_service.land()
            elif command == "goto":
                return self.mavlink_service.goto_position(
                    params.get("latitude", 0),
                    params.get("longitude", 0),
                    params.get("altitude", 0)
                )
        
        # For other device types, implement accordingly
        return False
    
    def add_callback(self, callback):
        """Add a callback for device updates."""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback):
        """Remove a callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get device manager statistics."""
        device_counts = {}
        for device in self.devices.values():
            device_type = device.device_type
            device_counts[device_type] = device_counts.get(device_type, 0) + 1
        
        online_count = sum(1 for d in self.devices.values() if d.status == "online")
        
        return {
            "total_devices": len(self.devices),
            "online_devices": online_count,
            "offline_devices": len(self.devices) - online_count,
            "by_type": device_counts
        }


# Global device manager instance
device_manager = DeviceManager()
