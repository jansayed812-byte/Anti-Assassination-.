import requests
import json
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime


@dataclass
class WiFiScanResult:
    bssid: str
    ssid: str
    signal_strength: int  # dBm
    frequency: int  # MHz


@dataclass
class WiFiPosition:
    latitude: float
    longitude: float
    accuracy: float
    timestamp: datetime
    source: str = "WIFI"


class WiFiPositioningService:
    """Service for Wi-Fi-based positioning using public APIs."""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        # Mozilla Location Service (free, no API key required)
        self.mls_url = "https://location.services.mozilla.com/v1/geolocate"
        # Google Geolocation API (requires API key)
        self.google_url = "https://www.googleapis.com/geolocation/v1/geolocate"
    
    def get_position_from_scan(self, scan_results: List[WiFiScanResult]) -> Optional[WiFiPosition]:
        """Get position from Wi-Fi scan results using Mozilla Location Service."""
        if not scan_results:
            return None
        
        try:
            # Format data for Mozilla Location Service
            wifi_data = [
                {
                    "macAddress": result.bssid,
                    "signalStrength": result.signal_strength,
                    "channel": self._frequency_to_channel(result.frequency)
                }
                for result in scan_results
            ]
            
            payload = {
                "wifiAccessPoints": wifi_data
            }
            
            # Try Mozilla Location Service first (free)
            response = requests.post(
                self.mls_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "location" in data:
                    return WiFiPosition(
                        latitude=data["location"]["lat"],
                        longitude=data["location"]["lng"],
                        accuracy=data.get("accuracy", 100.0),
                        timestamp=datetime.now(),
                        source="WIFI"
                    )
            
            # Fallback to Google API if key is available
            if self.api_key:
                return self._get_position_google(scan_results)
            
        except Exception as e:
            print(f"Error getting Wi-Fi position: {e}")
        
        return None
    
    def _get_position_google(self, scan_results: List[WiFiScanResult]) -> Optional[WiFiPosition]:
        """Get position using Google Geolocation API."""
        try:
            wifi_data = [
                {
                    "macAddress": result.bssid,
                    "signalStrength": result.signal_strength,
                    "channel": self._frequency_to_channel(result.frequency)
                }
                for result in scan_results
            ]
            
            payload = {
                "wifiAccessPoints": wifi_data
            }
            
            response = requests.post(
                f"{self.google_url}?key={self.api_key}",
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "location" in data:
                    return WiFiPosition(
                        latitude=data["location"]["lat"],
                        longitude=data["location"]["lng"],
                        accuracy=data.get("accuracy", 100.0),
                        timestamp=datetime.now(),
                        source="WIFI"
                    )
        except Exception as e:
            print(f"Error getting Google Wi-Fi position: {e}")
        
        return None
    
    def _frequency_to_channel(self, frequency: int) -> int:
        """Convert WiFi frequency to channel number."""
        if 2412 <= frequency <= 2484:
            return (frequency - 2407) // 5
        elif 5160 <= frequency <= 5865:
            return (frequency - 5000) // 5
        return 0
    
    def simulate_scan(self) -> List[WiFiScanResult]:
        """Generate simulated Wi-Fi scan results for testing."""
        import random
        return [
            WiFiScanResult(
                bssid=f"00:11:22:33:44:{i:02x}",
                ssid=f"Network_{i}",
                signal_strength=random.randint(-90, -30),
                frequency=random.choice([2412, 2437, 2462, 5180, 5200, 5745])
            )
            for i in range(5)
        ]
    
    def simulate_position(self) -> WiFiPosition:
        """Generate simulated Wi-Fi position for testing."""
        import random
        return WiFiPosition(
            latitude=35.6892 + random.uniform(-0.0005, 0.0005),
            longitude=51.3890 + random.uniform(-0.0005, 0.0005),
            accuracy=random.uniform(20, 100),
            timestamp=datetime.now(),
            source="WIFI"
        )
