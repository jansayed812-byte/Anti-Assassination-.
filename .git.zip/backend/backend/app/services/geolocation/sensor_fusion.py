import numpy as np
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class PositionSource(Enum):
    GPS = "GPS"
    WIFI = "WIFI"
    BLUETOOTH = "BLUETOOTH"
    CELLULAR = "CELLULAR"
    INS = "INS"


@dataclass
class PositionMeasurement:
    latitude: float
    longitude: float
    altitude: float
    accuracy: float
    timestamp: datetime
    source: PositionSource
    weight: float = 1.0


class KalmanFilter:
    """Kalman filter for sensor fusion and position estimation."""
    
    def __init__(self, initial_lat: float, initial_lon: float, initial_alt: float = 0.0):
        # State vector: [lat, lon, alt, lat_vel, lon_vel, alt_vel]
        self.x = np.array([initial_lat, initial_lon, initial_alt, 0.0, 0.0, 0.0])
        
        # State covariance matrix
        self.P = np.eye(6) * 1.0
        
        # State transition matrix (assuming constant velocity model)
        self.F = np.eye(6)
        self.F[0, 3] = 1.0  # lat += lat_vel * dt
        self.F[1, 4] = 1.0  # lon += lon_vel * dt
        self.F[2, 5] = 1.0  # alt += alt_vel * dt
        
        # Measurement matrix (we observe position only)
        self.H = np.zeros((3, 6))
        self.H[0, 0] = 1.0  # observe lat
        self.H[1, 1] = 1.0  # observe lon
        self.H[2, 2] = 1.0  # observe alt
        
        # Process noise covariance
        self.Q = np.eye(6) * 0.01
        
        # Measurement noise covariance (will be updated based on accuracy)
        self.R = np.eye(3) * 1.0
        
        self.last_update = datetime.now()
    
    def predict(self, dt: float):
        """Predict next state based on motion model."""
        # Update state transition matrix with time step
        self.F[0, 3] = dt
        self.F[1, 4] = dt
        self.F[2, 5] = dt
        
        # Predict state
        self.x = self.F @ self.x
        
        # Predict covariance
        self.P = self.F @ self.P @ self.F.T + self.Q
        
        self.last_update = datetime.now()
    
    def update(self, measurement: PositionMeasurement):
        """Update state with new measurement."""
        # Update measurement noise based on accuracy
        accuracy = max(measurement.accuracy, 1.0)  # Avoid division by zero
        self.R = np.eye(3) * (accuracy ** 2)
        
        # Measurement vector
        z = np.array([measurement.latitude, measurement.longitude, measurement.altitude])
        
        # Calculate Kalman gain
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        
        # Update state
        y = z - self.H @ self.x  # Innovation
        self.x = self.x + K @ y
        
        # Update covariance
        I = np.eye(6)
        self.P = (I - K @ self.H) @ self.P
        
        self.last_update = datetime.now()
    
    def get_position(self) -> Dict[str, float]:
        """Get current estimated position."""
        return {
            "latitude": self.x[0],
            "longitude": self.x[1],
            "altitude": self.x[2],
            "velocity_lat": self.x[3],
            "velocity_lon": self.x[4],
            "velocity_alt": self.x[5]
        }
    
    def get_velocity(self) -> Dict[str, float]:
        """Get current estimated velocity."""
        speed = np.sqrt(self.x[3]**2 + self.x[4]**2 + self.x[5]**2)
        heading = np.degrees(np.arctan2(self.x[4], self.x[3]))
        if heading < 0:
            heading += 360
        
        return {
            "speed": speed,
            "heading": heading,
            "vertical_speed": self.x[5]
        }


class SensorFusionService:
    """Service for fusing position data from multiple sources."""
    
    def __init__(self, initial_lat: float = 35.6892, initial_lon: float = 51.3890):
        self.kalman_filter = KalmanFilter(initial_lat, initial_lon)
        self.measurements: List[PositionMeasurement] = []
        self.source_weights = {
            PositionSource.GPS: 1.0,
            PositionSource.WIFI: 0.7,
            PositionSource.BLUETOOTH: 0.5,
            PositionSource.CELLULAR: 0.6,
            PositionSource.INS: 0.4
        }
    
    def add_measurement(self, measurement: PositionMeasurement):
        """Add a new measurement from any source."""
        # Apply source weight
        measurement.weight = self.source_weights.get(measurement.source, 0.5)
        
        # Store measurement
        self.measurements.append(measurement)
        
        # Keep only recent measurements (last 60 seconds)
        cutoff = datetime.now().timestamp() - 60
        self.measurements = [
            m for m in self.measurements 
            if m.timestamp.timestamp() > cutoff
        ]
        
        # Update Kalman filter
        self.kalman_filter.update(measurement)
    
    def get_fused_position(self) -> Dict[str, Any]:
        """Get fused position estimate."""
        position = self.kalman_filter.get_position()
        velocity = self.kalman_filter.get_velocity()
        
        # Calculate overall accuracy
        if self.measurements:
            accuracies = [m.accuracy for m in self.measurements]
            avg_accuracy = sum(accuracies) / len(accuracies)
        else:
            avg_accuracy = 10.0
        
        return {
            **position,
            **velocity,
            "accuracy": avg_accuracy,
            "timestamp": datetime.now(),
            "source_count": len(self.measurements),
            "sources": list(set(m.source.value for m in self.measurements))
        }
    
    def predict_position(self, dt: float) -> Dict[str, Any]:
        """Predict position at future time step."""
        self.kalman_filter.predict(dt)
        return self.get_fused_position()
    
    def get_source_status(self) -> Dict[str, Any]:
        """Get status of all position sources."""
        source_counts = {}
        source_accuracies = {}
        
        for measurement in self.measurements:
            source = measurement.source.value
            source_counts[source] = source_counts.get(source, 0) + 1
            if source not in source_accuracies:
                source_accuracies[source] = []
            source_accuracies[source].append(measurement.accuracy)
        
        avg_accuracies = {
            source: sum(accs) / len(accs) if accs else 0
            for source, accs in source_accuracies.items()
        }
        
        return {
            "counts": source_counts,
            "average_accuracies": avg_accuracies,
            "total_measurements": len(self.measurements)
        }
    
    def reset(self, initial_lat: float = 35.6892, initial_lon: float = 51.3890):
        """Reset the fusion service with new initial position."""
        self.kalman_filter = KalmanFilter(initial_lat, initial_lon)
        self.measurements = []
