import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import math


@dataclass
class FusedPosition:
    """Result of multi-source sensor fusion."""
    latitude: float
    longitude: float
    altitude: float
    velocity_north: float
    velocity_east: float
    velocity_down: float
    heading: float
    pitch: float
    roll: float
    position_covariance: np.ndarray  # 3x3 covariance matrix
    velocity_covariance: np.ndarray  # 3x3 covariance matrix
    timestamp: datetime
    source_contributions: Dict[str, float]
    confidence: float
    quality_score: float
    is_dead_reckoning: bool


class ExtendedKalmanFilter:
    """
    Extended Kalman Filter for multi-source sensor fusion.
    Implements the fusion process as specified in architecture:
    1. Convert all measurements to local ENU coordinates and common time
    2. Remove out-of-range speed/acceleration samples and stale samples
    3. Predict with INS; correct drift with GNSS, WiFi, BLE, cellular based on actual covariance
    4. Calculate residual and robustly reject inconsistent measurements
    5. Publish position, velocity, heading, altitude, covariance and source contribution at ≥5Hz
    6. In absence of GNSS, INS enters dead-reckoning mode with explicit uncertainty increase
    """
    
    def __init__(self, initial_position: Optional[Tuple[float, float, float]] = None):
        # State vector: [x, y, z, vx, vy, vz, roll, pitch, yaw]
        self.state = np.zeros(9)
        
        if initial_position:
            # Convert lat/lon/alt to ENU (simplified)
            self.state[0:3] = self._lla_to_enu(*initial_position)
        
        # Covariance matrix (9x9)
        self.P = np.eye(9) * 1.0  # Initial uncertainty
        
        # Process noise covariance
        self.Q = np.eye(9) * 0.01
        
        # Measurement noise for different sources
        self.R_sources = {
            'gnss': np.eye(3) * 5.0,      # GNSS: ~5m accuracy
            'wifi': np.eye(3) * 15.0,      # WiFi: ~15m accuracy
            'ble': np.eye(3) * 10.0,       # BLE: ~10m accuracy
            'cellular': np.eye(3) * 50.0,  # Cellular: ~50m accuracy
            'ins': np.eye(6) * 0.5,       # INS: velocity/orientation
        }
        
        # Source contribution tracking
        self.source_contributions: Dict[str, float] = {
            'gnss': 0.0,
            'wifi': 0.0,
            'ble': 0.0,
            'cellular': 0.0,
            'ins': 0.0
        }
        
        # Dead reckoning mode
        self.is_dead_reckoning = False
        self.last_gnss_time: Optional[datetime] = None
        self.dead_reckoning_start_time: Optional[datetime] = None
        
        # Rejected measurements for audit
        self.rejected_measurements: List[Dict[str, Any]] = []
        
        # Calibration parameters (would be determined from ground truth)
        self.calibration_bias = np.zeros(9)
        self.calibration_scale = np.ones(9)
    
    def _lla_to_enu(self, lat: float, lon: float, alt: float) -> np.ndarray:
        """Convert WGS84 lat/lon/alt to local ENU coordinates (simplified)."""
        # In production, this would use proper geodetic transformations
        # For now, use a simplified local coordinate system
        # Assume reference point at (35.7, 51.4, 1200) - Tehran area
        ref_lat, ref_lon, ref_alt = 35.7, 51.4, 1200.0
        
        # Simple approximation for small areas
        earth_radius = 6371000.0  # meters
        lat_rad = math.radians(lat)
        ref_lat_rad = math.radians(ref_lat)
        
        x = (lon - ref_lon) * earth_radius * math.cos(ref_lat_rad)
        y = (lat - ref_lat) * earth_radius
        z = alt - ref_alt
        
        return np.array([x, y, z])
    
    def _enu_to_lla(self, enu: np.ndarray) -> Tuple[float, float, float]:
        """Convert ENU coordinates back to lat/lon/alt."""
        ref_lat, ref_lon, ref_alt = 35.7, 51.4, 1200.0
        earth_radius = 6371000.0
        ref_lat_rad = math.radians(ref_lat)
        
        x, y, z = enu
        
        lon = ref_lon + x / (earth_radius * math.cos(ref_lat_rad))
        lat = ref_lat + y / earth_radius
        alt = ref_alt + z
        
        return (lat, lon, alt)
    
    def predict(self, dt: float):
        """Prediction step using INS model."""
        # State transition matrix (constant velocity model)
        F = np.eye(9)
        F[0, 3] = dt  # x += vx * dt
        F[1, 4] = dt  # y += vy * dt
        F[2, 5] = dt  # z += vz * dt
        
        # Predict state
        self.state = F @ self.state
        
        # Predict covariance
        self.P = F @ self.P @ F.T + self.Q
        
        # Apply calibration
        self.state = (self.state - self.calibration_bias) * self.calibration_scale
    
    def update_gnss(self, measurement: np.ndarray, quality: float):
        """Update with GNSS measurement."""
        self._update_position_measurement(measurement, 'gnss', quality)
        self.last_gnss_time = datetime.utcnow()
        self.is_dead_reckoning = False
    
    def update_wifi(self, measurement: np.ndarray, quality: float):
        """Update with WiFi RTT measurement."""
        self._update_position_measurement(measurement, 'wifi', quality)
    
    def update_ble(self, measurement: np.ndarray, quality: float):
        """Update with BLE beacon measurement."""
        self._update_position_measurement(measurement, 'ble', quality)
    
    def update_cellular(self, measurement: np.ndarray, quality: float):
        """Update with cellular positioning measurement."""
        self._update_position_measurement(measurement, 'cellular', quality)
    
    def update_ins(self, velocity: np.ndarray, orientation: np.ndarray, quality: float):
        """Update with INS velocity and orientation."""
        # Measurement matrix for INS (velocity + orientation)
        H = np.zeros((6, 9))
        H[0, 3] = 1  # vx
        H[1, 4] = 1  # vy
        H[2, 5] = 1  # vz
        H[3, 6] = 1  # roll
        H[4, 7] = 1  # pitch
        H[5, 8] = 1  # yaw
        
        # Combined measurement
        z = np.concatenate([velocity, orientation])
        
        # Adjust measurement noise based on quality
        R = self.R_sources['ins'] / quality
        
        # Kalman gain
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)
        
        # Update state
        y = z - H @ self.state
        self.state = self.state + K @ y
        
        # Update covariance
        I = np.eye(9)
        self.P = (I - K @ H) @ self.P
        
        # Track contribution
        self.source_contributions['ins'] = np.trace(K @ H) / 6.0
    
    def _update_position_measurement(self, measurement: np.ndarray, source: str, quality: float):
        """Common update logic for position measurements."""
        # Measurement matrix (position only)
        H = np.zeros((3, 9))
        H[0, 0] = 1  # x
        H[1, 1] = 1  # y
        H[2, 2] = 1  # z
        
        # Adjust measurement noise based on quality and source
        R = self.R_sources[source] / quality
        
        # Robust rejection: check if measurement is consistent
        predicted_pos = self.state[0:3]
        residual = measurement - predicted_pos
        residual_norm = np.linalg.norm(residual)
        
        # Mahalanobis distance for consistency check
        S = H @ self.P @ H.T + R
        mahalanobis = np.sqrt(residual.T @ np.linalg.inv(S) @ residual)
        
        # Reject if measurement is too inconsistent (threshold = 5 sigma)
        if mahalanobis > 5.0:
            self.rejected_measurements.append({
                'source': source,
                'measurement': measurement.tolist(),
                'residual': residual.tolist(),
                'mahalanobis': float(mahalanobis),
                'timestamp': datetime.utcnow().isoformat()
            })
            return
        
        # Kalman gain
        K = self.P @ H.T @ np.linalg.inv(S)
        
        # Update state
        self.state = self.state + K @ residual
        
        # Update covariance
        I = np.eye(9)
        self.P = (I - K @ H) @ self.P
        
        # Track contribution
        self.source_contributions[source] = np.trace(K @ H) / 3.0
    
    def check_dead_reckoning(self, timeout_seconds: float = 30.0):
        """Check if we should enter dead reckoning mode."""
        if self.last_gnss_time is None:
            self.is_dead_reckoning = True
            return
        
        time_since_gnss = (datetime.utcnow() - self.last_gnss_time).total_seconds()
        
        if time_since_gnss > timeout_seconds:
            if not self.is_dead_reckoning:
                self.is_dead_reckoning = True
                self.dead_reckoning_start_time = datetime.utcnow()
            
            # Increase uncertainty explicitly in dead reckoning mode
            dead_reckoning_time = (datetime.utcnow() - self.dead_reckoning_start_time).total_seconds()
            uncertainty_growth = 1.0 + dead_reckoning_time / 10.0  # 10% growth per second
            self.P[0:3, 0:3] *= uncertainty_growth
        else:
            self.is_dead_reckoning = False
    
    def get_fused_position(self) -> FusedPosition:
        """Get current fused position with all metadata."""
        # Extract ENU position
        enu_pos = self.state[0:3]
        enu_vel = self.state[3:6]
        orientation = self.state[6:9]
        
        # Convert back to LLA
        lat, lon, alt = self._enu_to_lla(enu_pos)
        
        # Calculate heading from yaw
        heading = math.degrees(orientation[2]) % 360
        pitch = math.degrees(orientation[1])
        roll = math.degrees(orientation[0])
        
        # Calculate velocity components
        velocity_north = enu_vel[1]
        velocity_east = enu_vel[0]
        velocity_down = -enu_vel[2]
        
        # Extract covariances
        position_cov = self.P[0:3, 0:3]
        velocity_cov = self.P[3:6, 3:6]
        
        # Calculate overall confidence
        trace_P = np.trace(self.P)
        confidence = 1.0 / (1.0 + trace_P / 100.0)  # Normalize to 0-1
        
        # Calculate quality score based on source contributions
        total_contribution = sum(self.source_contributions.values())
        quality_score = total_contribution if total_contribution > 0 else 0.0
        
        # Normalize contributions
        if total_contribution > 0:
            normalized_contributions = {
                k: v / total_contribution 
                for k, v in self.source_contributions.items()
            }
        else:
            normalized_contributions = self.source_contributions.copy()
        
        return FusedPosition(
            latitude=lat,
            longitude=lon,
            altitude=alt,
            velocity_north=velocity_north,
            velocity_east=velocity_east,
            velocity_down=velocity_down,
            heading=heading,
            pitch=pitch,
            roll=roll,
            position_covariance=position_cov,
            velocity_covariance=velocity_cov,
            timestamp=datetime.utcnow(),
            source_contributions=normalized_contributions,
            confidence=confidence,
            quality_score=quality_score,
            is_dead_reckoning=self.is_dead_reckoning
        )
    
    def reset(self, initial_position: Optional[Tuple[float, float, float]] = None):
        """Reset filter to initial state."""
        self.state = np.zeros(9)
        self.P = np.eye(9) * 1.0
        self.source_contributions = {k: 0.0 for k in self.source_contributions}
        self.is_dead_reckoning = False
        self.last_gnss_time = None
        self.dead_reckoning_start_time = None
        self.rejected_measurements = []
        
        if initial_position:
            self.state[0:3] = self._lla_to_enu(*initial_position)


class MultiSourceFusionEngine:
    """Engine for coordinating multi-source sensor fusion."""
    
    def __init__(self):
        self.ekf = ExtendedKalmanFilter()
        self.last_update_time = datetime.utcnow()
        self.update_frequency = 5.0  # 5 Hz minimum
        self.measurement_buffer: List[Dict[str, Any]] = []
    
    def process_measurement(self, source_type: str, measurement: Dict[str, Any], quality: float):
        """Process a measurement from a specific source."""
        # Check for stale measurements (older than 1 second)
        captured_at = datetime.fromisoformat(measurement.get('captured_at', datetime.utcnow().isoformat()))
        age = (datetime.utcnow() - captured_at).total_seconds()
        
        if age > 1.0:
            # Stale measurement, reject
            self.ekf.rejected_measurements.append({
                'source': source_type,
                'reason': 'stale_measurement',
                'age_seconds': age,
                'timestamp': datetime.utcnow().isoformat()
            })
            return
        
        # Convert measurement to ENU coordinates
        if source_type == 'gnss':
            enu_pos = self.ekf._lla_to_enu(
                measurement['lat'],
                measurement['lon'],
                measurement['alt_m']
            )
            self.ekf.update_gnss(enu_pos, quality)
        
        elif source_type == 'wifi':
            if 'estimated_position' in measurement:
                enu_pos = self.ekf._lla_to_enu(
                    measurement['estimated_position']['lat'],
                    measurement['estimated_position']['lon'],
                    measurement['estimated_position'].get('alt', 0)
                )
                self.ekf.update_wifi(enu_pos, quality)
        
        elif source_type == 'ble':
            if 'estimated_position' in measurement:
                enu_pos = self.ekf._lla_to_enu(
                    measurement['estimated_position']['lat'],
                    measurement['estimated_position']['lon'],
                    measurement['estimated_position'].get('alt', 0)
                )
                self.ekf.update_ble(enu_pos, quality)
        
        elif source_type == 'cellular':
            if 'estimated_position' in measurement:
                enu_pos = self.ekf._lla_to_enu(
                    measurement['estimated_position']['lat'],
                    measurement['estimated_position']['lon'],
                    measurement['estimated_position'].get('alt', 0)
                )
                self.ekf.update_cellular(enu_pos, quality)
        
        elif source_type == 'ins':
            velocity = np.array([
                measurement.get('velocity_north', 0),
                measurement.get('velocity_east', 0),
                measurement.get('velocity_down', 0)
            ])
            orientation = np.array([
                math.radians(measurement.get('roll', 0)),
                math.radians(measurement.get('pitch', 0)),
                math.radians(measurement.get('heading', 0))
            ])
            self.ekf.update_ins(velocity, orientation, quality)
    
    def update(self, dt: float):
        """Perform prediction step and check dead reckoning."""
        self.ekf.predict(dt)
        self.ekf.check_dead_reckoning()
        self.last_update_time = datetime.utcnow()
    
    def get_fused_position(self) -> FusedPosition:
        """Get current fused position."""
        return self.ekf.get_fused_position()
    
    def get_rejected_measurements(self) -> List[Dict[str, Any]]:
        """Get list of rejected measurements for audit."""
        return self.ekf.rejected_measurements.copy()
    
    def clear_rejected_measurements(self):
        """Clear rejected measurements list."""
        self.ekf.rejected_measurements = []


# Global fusion engine instance
fusion_engine = MultiSourceFusionEngine()