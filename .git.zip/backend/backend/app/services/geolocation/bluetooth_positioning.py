import math
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime


@dataclass
class BeaconData:
    uuid: str
    major: int
    minor: int
    rssi: int  # Received Signal Strength Indicator
    tx_power: int  # Transmit power at 1 meter


@dataclass
class BluetoothPosition:
    latitude: float
    longitude: float
    accuracy: float
    timestamp: datetime
    source: str = "BLUETOOTH"


class BluetoothPositioningService:
    """Service for Bluetooth-based positioning using beacons."""
    
    def __init__(self):
        self.known_beacons: Dict[str, Dict[str, float]] = {}  # UUID -> {lat, lon}
        self.rssi_at_1m = -59  # Typical RSSI at 1 meter
    
    def register_beacon(self, uuid: str, latitude: float, longitude: float):
        """Register a known beacon location."""
        self.known_beacons[uuid] = {
            "latitude": latitude,
            "longitude": longitude
        }
    
    def get_position_from_beacons(self, beacon_data: List[BeaconData]) -> Optional[BluetoothPosition]:
        """Calculate position based on nearby beacons using trilateration."""
        if len(beacon_data) < 3:
            return None
        
        try:
            # Calculate distance to each beacon based on RSSI
            beacon_positions = []
            for beacon in beacon_data:
                if beacon.uuid in self.known_beacons:
                    distance = self._rssi_to_distance(beacon.rssi, beacon.tx_power)
                    beacon_positions.append({
                        "lat": self.known_beacons[beacon.uuid]["latitude"],
                        "lon": self.known_beacons[beacon.uuid]["longitude"],
                        "distance": distance
                    })
            
            if len(beacon_positions) >= 3:
                position = self._trilaterate(beacon_positions)
                if position:
                    return BluetoothPosition(
                        latitude=position["lat"],
                        longitude=position["lon"],
                        accuracy=position["accuracy"],
                        timestamp=datetime.now(),
                        source="BLUETOOTH"
                    )
        
        except Exception as e:
            print(f"Error calculating Bluetooth position: {e}")
        
        return None
    
    def _rssi_to_distance(self, rssi: int, tx_power: int) -> float:
        """Convert RSSI to distance using path loss model."""
        if rssi == 0:
            return -1.0
        
        ratio = rssi * 1.0 / tx_power
        if ratio < 1.0:
            return ratio ** 10
        else:
            return 0.89976 * (ratio ** 7.7095) + 0.111
    
    def _trilaterate(self, beacon_positions: List[Dict[str, float]]) -> Optional[Dict[str, float]]:
        """Perform trilateration to find position."""
        if len(beacon_positions) < 3:
            return None
        
        try:
            # Use first two beacons to find possible positions
            x1, y1, r1 = (
                beacon_positions[0]["lon"],
                beacon_positions[0]["lat"],
                beacon_positions[0]["distance"]
            )
            x2, y2, r2 = (
                beacon_positions[1]["lon"],
                beacon_positions[1]["lat"],
                beacon_positions[1]["distance"]
            )
            x3, y3, r3 = (
                beacon_positions[2]["lon"],
                beacon_positions[2]["lat"],
                beacon_positions[2]["distance"]
            )
            
            # Calculate intersection points
            A = 2 * x2 - 2 * x1
            B = 2 * y2 - 2 * y1
            C = r1 ** 2 - r2 ** 2 - x1 ** 2 + x2 ** 2 - y1 ** 2 + y2 ** 2
            D = 2 * x3 - 2 * x1
            E = 2 * y3 - 2 * y1
            F = r1 ** 2 - r3 ** 2 - x1 ** 2 + x3 ** 2 - y1 ** 2 + y3 ** 2
            
            # Solve for intersection
            det = A * E - B * D
            if abs(det) < 1e-10:
                return None
            
            x = (C * E - B * F) / det
            y = (A * F - C * D) / det
            
            # Calculate accuracy based on distance consistency
            distances = [
                math.sqrt((x - bp["lon"]) ** 2 + (y - bp["lat"]) ** 2)
                for bp in beacon_positions
            ]
            accuracy = max(abs(d - bp["distance"]) for d, bp in zip(distances, beacon_positions))
            
            return {
                "lat": y,
                "lon": x,
                "accuracy": accuracy * 111000  # Convert to meters
            }
        
        except Exception as e:
            print(f"Error in trilateration: {e}")
            return None
    
    def scan_beacons(self) -> List[BeaconData]:
        """Scan for nearby Bluetooth beacons."""
        # This requires bluetooth library and hardware
        # For simulation, return empty list
        return []
    
    def simulate_beacons(self) -> List[BeaconData]:
        """Generate simulated beacon data for testing."""
        import random
        return [
            BeaconData(
                uuid=f"uuid-{i}",
                major=random.randint(1, 65535),
                minor=random.randint(1, 65535),
                rssi=random.randint(-90, -40),
                tx_power=-59
            )
            for i in range(5)
        ]
    
    def simulate_position(self) -> BluetoothPosition:
        """Generate simulated Bluetooth position for testing."""
        import random
        return BluetoothPosition(
            latitude=35.6892 + random.uniform(-0.0002, 0.0002),
            longitude=51.3890 + random.uniform(-0.0002, 0.0002),
            accuracy=random.uniform(5, 20),
            timestamp=datetime.now(),
            source="BLUETOOTH"
        )
