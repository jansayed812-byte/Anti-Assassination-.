import requests
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime


@dataclass
class CellTowerData:
    cell_id: str
    lac: int  # Location Area Code
    mcc: int  # Mobile Country Code
    mnc: int  # Mobile Network Code
    signal_strength: int  # dBm


@dataclass
class CellularPosition:
    latitude: float
    longitude: float
    accuracy: float
    timestamp: datetime
    source: str = "CELLULAR"


class CellularPositioningService:
    """Service for cellular-based positioning using cell tower triangulation."""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        # OpenCellID API (free with registration)
        self.opencellid_url = "https://opencellid.org/cell/get"
        # Google Geolocation API
        self.google_url = "https://www.googleapis.com/geolocation/v1/geolocate"
    
    def get_position_from_towers(self, tower_data: List[CellTowerData]) -> Optional[CellularPosition]:
        """Get position from cell tower data using triangulation."""
        if not tower_data:
            return None
        
        try:
            # Try OpenCellID API first
            position = self._get_position_opencellid(tower_data)
            if position:
                return position
            
            # Fallback to Google API if key is available
            if self.api_key:
                return self._get_position_google(tower_data)
            
        except Exception as e:
            print(f"Error getting cellular position: {e}")
        
        return None
    
    def _get_position_opencellid(self, tower_data: List[CellTowerData]) -> Optional[CellularPosition]:
        """Get position using OpenCellID API."""
        try:
            # Use the tower with strongest signal
            strongest_tower = max(tower_data, key=lambda x: x.signal_strength)
            
            params = {
                "mcc": strongest_tower.mcc,
                "mnc": strongest_tower.mnc,
                "lac": strongest_tower.lac,
                "cellid": strongest_tower.cell_id,
                "format": "json"
            }
            
            if self.api_key:
                params["key"] = self.api_key
            
            response = requests.get(self.opencellid_url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if "lat" in data and "lon" in data:
                    return CellularPosition(
                        latitude=float(data["lat"]),
                        longitude=float(data["lon"]),
                        accuracy=data.get("accuracy", 1000.0),
                        timestamp=datetime.now(),
                        source="CELLULAR"
                    )
        except Exception as e:
            print(f"Error getting OpenCellID position: {e}")
        
        return None
    
    def _get_position_google(self, tower_data: List[CellTowerData]) -> Optional[CellularPosition]:
        """Get position using Google Geolocation API."""
        try:
            cell_towers = [
                {
                    "cellId": tower.cell_id,
                    "locationAreaCode": tower.lac,
                    "mobileCountryCode": tower.mcc,
                    "mobileNetworkCode": tower.mnc,
                    "signalStrength": tower.signal_strength
                }
                for tower in tower_data
            ]
            
            payload = {
                "cellTowers": cell_towers
            }
            
            response = requests.post(
                f"{self.google_url}?key={self.api_key}",
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "location" in data:
                    return CellularPosition(
                        latitude=data["location"]["lat"],
                        longitude=data["location"]["lng"],
                        accuracy=data.get("accuracy", 1000.0),
                        timestamp=datetime.now(),
                        source="CELLULAR"
                    )
        except Exception as e:
            print(f"Error getting Google cellular position: {e}")
        
        return None
    
    def triangulate_position(self, tower_data: List[CellTowerData], 
                           tower_locations: Dict[str, Dict[str, float]]) -> Optional[CellularPosition]:
        """Perform triangulation using known tower locations."""
        if len(tower_data) < 3:
            return None
        
        try:
            # Calculate weighted position based on signal strength
            total_weight = 0
            weighted_lat = 0
            weighted_lon = 0
            
            for tower in tower_data:
                tower_key = f"{tower.mcc}_{tower.mnc}_{tower.lac}_{tower.cell_id}"
                if tower_key in tower_locations:
                    # Weight by signal strength (higher signal = higher weight)
                    weight = 10 ** (tower.signal_strength / 10)
                    location = tower_locations[tower_key]
                    
                    weighted_lat += location["latitude"] * weight
                    weighted_lon += location["longitude"] * weight
                    total_weight += weight
            
            if total_weight > 0:
                avg_lat = weighted_lat / total_weight
                avg_lon = weighted_lon / total_weight
                
                # Estimate accuracy based on signal strength and number of towers
                avg_signal = sum(t.signal_strength for t in tower_data) / len(tower_data)
                accuracy = max(100, 1000 * (10 ** (avg_signal / 10)))
                
                return CellularPosition(
                    latitude=avg_lat,
                    longitude=avg_lon,
                    accuracy=accuracy,
                    timestamp=datetime.now(),
                    source="CELLULAR"
                )
        
        except Exception as e:
            print(f"Error in triangulation: {e}")
        
        return None
    
    def simulate_towers(self) -> List[CellTowerData]:
        """Generate simulated cell tower data for testing."""
        import random
        return [
            CellTowerData(
                cell_id=str(random.randint(10000, 99999)),
                lac=random.randint(1, 65535),
                mcc=432,  # Iran MCC
                mnc=random.randint(1, 99),
                signal_strength=random.randint(-110, -60)
            )
            for i in range(5)
        ]
    
    def simulate_position(self) -> CellularPosition:
        """Generate simulated cellular position for testing."""
        import random
        return CellularPosition(
            latitude=35.6892 + random.uniform(-0.001, 0.001),
            longitude=51.3890 + random.uniform(-0.001, 0.001),
            accuracy=random.uniform(100, 1000),
            timestamp=datetime.now(),
            source="CELLULAR"
        )
