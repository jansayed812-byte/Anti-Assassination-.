from typing import Optional, Dict, Any, List
from datetime import datetime
import asyncio
import threading
import time

from .gps_service import GPSService, GPSData
from .wifi_positioning import WiFiPositioningService, WiFiPosition
from .bluetooth_positioning import BluetoothPositioningService, BluetoothPosition
from .cellular_positioning import CellularPositioningService, CellularPosition
from .sensor_fusion import SensorFusionService, PositionMeasurement, PositionSource


class GeolocationService:
    """Unified service for geolocation using multiple sources with sensor fusion."""
    
    def __init__(self):
        self.gps_service = GPSService()
        self.wifi_service = WiFiPositioningService()
        self.bluetooth_service = BluetoothPositioningService()
        self.cellular_service = CellularPositioningService()
        self.sensor_fusion = SensorFusionService()
        
        self.is_running = False
        self.update_interval = 1.0  # seconds
        self._thread: Optional[threading.Thread] = None
        self.callbacks = []
        
        self.current_position: Optional[Dict[str, Any]] = None
        self.last_update: Optional[datetime] = None
    
    def start(self):
        """Start the geolocation service."""
        if self.is_running:
            return
        
        self.is_running = True
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()
        
        # Try to connect to GPS
        if self.gps_service.connect():
            self.gps_service.start_reading(self._on_gps_data)
    
    def stop(self):
        """Stop the geolocation service."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        self.gps_service.disconnect()
    
    def add_callback(self, callback):
        """Add a callback to be called when position updates."""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback):
        """Remove a callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def _update_loop(self):
        """Main update loop for geolocation service."""
        while self.is_running:
            try:
                # Update position from all sources
                self._update_from_all_sources()
                
                # Sleep for update interval
                time.sleep(self.update_interval)
            except Exception as e:
                print(f"Error in geolocation update loop: {e}")
                time.sleep(1)
    
    def _update_from_all_sources(self):
        """Update position from all available sources."""
        measurements = []
        
        # Get GPS data (if available)
        if hasattr(self.gps_service, 'serial_connection') and self.gps_service.serial_connection:
            # GPS data comes via callback
            pass
        else:
            # Simulate GPS for testing
            gps_data = self.gps_service.simulate_data()
            measurements.append(PositionMeasurement(
                latitude=gps_data.latitude,
                longitude=gps_data.longitude,
                altitude=gps_data.altitude,
                accuracy=gps_data.accuracy,
                timestamp=gps_data.timestamp,
                source=PositionSource.GPS
            ))
        
        # Get Wi-Fi position
        wifi_scan = self.wifi_service.simulate_scan()
        wifi_position = self.wifi_service.get_position_from_scan(wifi_scan)
        if wifi_position:
            measurements.append(PositionMeasurement(
                latitude=wifi_position.latitude,
                longitude=wifi_position.longitude,
                altitude=0.0,
                accuracy=wifi_position.accuracy,
                timestamp=wifi_position.timestamp,
                source=PositionSource.WIFI
            ))
        
        # Get Bluetooth position
        bluetooth_beacons = self.bluetooth_service.simulate_beacons()
        bluetooth_position = self.bluetooth_service.get_position_from_beacons(bluetooth_beacons)
        if bluetooth_position:
            measurements.append(PositionMeasurement(
                latitude=bluetooth_position.latitude,
                longitude=bluetooth_position.longitude,
                altitude=0.0,
                accuracy=bluetooth_position.accuracy,
                timestamp=bluetooth_position.timestamp,
                source=PositionSource.BLUETOOTH
            ))
        
        # Get Cellular position
        cellular_towers = self.cellular_service.simulate_towers()
        cellular_position = self.cellular_service.get_position_from_towers(cellular_towers)
        if cellular_position:
            measurements.append(PositionMeasurement(
                latitude=cellular_position.latitude,
                longitude=cellular_position.longitude,
                altitude=0.0,
                accuracy=cellular_position.accuracy,
                timestamp=cellular_position.timestamp,
                source=PositionSource.CELLULAR
            ))
        
        # Add measurements to sensor fusion
        for measurement in measurements:
            self.sensor_fusion.add_measurement(measurement)
        
        # Get fused position
        self.current_position = self.sensor_fusion.get_fused_position()
        self.last_update = datetime.now()
        
        # Notify callbacks
        for callback in self.callbacks:
            try:
                callback(self.current_position)
            except Exception as e:
                print(f"Error in position callback: {e}")
    
    def _on_gps_data(self, gps_data: GPSData):
        """Callback for GPS data."""
        measurement = PositionMeasurement(
            latitude=gps_data.latitude,
            longitude=gps_data.longitude,
            altitude=gps_data.altitude,
            accuracy=gps_data.accuracy,
            timestamp=gps_data.timestamp,
            source=PositionSource.GPS
        )
        self.sensor_fusion.add_measurement(measurement)
    
    def get_current_position(self) -> Optional[Dict[str, Any]]:
        """Get current fused position."""
        return self.current_position
    
    def get_position_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get position history from sensor fusion measurements."""
        return [
            {
                "latitude": m.latitude,
                "longitude": m.longitude,
                "altitude": m.altitude,
                "accuracy": m.accuracy,
                "timestamp": m.timestamp.isoformat(),
                "source": m.source.value
            }
            for m in self.sensor_fusion.measurements[-limit:]
        ]
    
    def get_source_status(self) -> Dict[str, Any]:
        """Get status of all position sources."""
        return self.sensor_fusion.get_source_status()
    
    def predict_position(self, dt: float) -> Dict[str, Any]:
        """Predict position at future time step."""
        return self.sensor_fusion.predict_position(dt)
    
    def reset(self, initial_lat: float = 35.6892, initial_lon: float = 51.3890):
        """Reset the geolocation service."""
        self.sensor_fusion.reset(initial_lat, initial_lon)
        self.current_position = None
        self.last_update = None


# Global instance
geolocation_service = GeolocationService()
