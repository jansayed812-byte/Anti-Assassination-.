import serial
import threading
import time
from typing import Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class GPSData:
    latitude: float
    longitude: float
    altitude: float
    accuracy: float
    speed: float
    heading: float
    satellites: int
    timestamp: datetime
    source: str = "GPS"


class GPSService:
    """Service for handling GPS receiver communication and data parsing."""
    
    def __init__(self, port: str = "/dev/ttyUSB0", baudrate: int = 9600):
        self.port = port
        self.baudrate = baudrate
        self.serial_connection: Optional[serial.Serial] = None
        self.is_running = False
        self.callback = None
        self._thread: Optional[threading.Thread] = None
    
    def connect(self) -> bool:
        """Connect to GPS receiver via serial port."""
        try:
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=1
            )
            return True
        except Exception as e:
            print(f"Failed to connect to GPS: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from GPS receiver."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        if self.serial_connection:
            self.serial_connection.close()
    
    def start_reading(self, callback):
        """Start reading GPS data in background thread."""
        self.callback = callback
        self.is_running = True
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()
    
    def _read_loop(self):
        """Background thread for reading GPS data."""
        while self.is_running and self.serial_connection:
            try:
                line = self.serial_connection.readline().decode('utf-8', errors='ignore').strip()
                if line:
                    data = self._parse_nmea(line)
                    if data and self.callback:
                        self.callback(data)
            except Exception as e:
                print(f"Error reading GPS data: {e}")
                time.sleep(0.1)
    
    def _parse_nmea(self, line: str) -> Optional[GPSData]:
        """Parse NMEA sentence from GPS receiver."""
        try:
            if line.startswith('$GPGGA') or line.startswith('$GNGGA'):
                return self._parse_gga(line)
            elif line.startswith('$GPRMC') or line.startswith('$GNRMC'):
                return self._parse_rmc(line)
        except Exception as e:
            print(f"Error parsing NMEA: {e}")
        return None
    
    def _parse_gga(self, line: str) -> Optional[GPSData]:
        """Parse GGA sentence (position data)."""
        parts = line.split(',')
        if len(parts) < 15:
            return None
        
        try:
            # Parse latitude
            lat_deg = float(parts[2][:2]) if parts[2] else 0
            lat_min = float(parts[2][2:]) if len(parts[2]) > 2 else 0
            latitude = lat_deg + lat_min / 60
            if parts[3] == 'S':
                latitude = -latitude
            
            # Parse longitude
            lon_deg = float(parts[4][:3]) if parts[4] else 0
            lon_min = float(parts[4][3:]) if len(parts[4]) > 3 else 0
            longitude = lon_deg + lon_min / 60
            if parts[5] == 'W':
                longitude = -longitude
            
            # Parse other data
            altitude = float(parts[9]) if parts[9] else 0
            satellites = int(parts[7]) if parts[7] else 0
            accuracy = float(parts[8]) if parts[8] else 0
            
            return GPSData(
                latitude=latitude,
                longitude=longitude,
                altitude=altitude,
                accuracy=accuracy,
                speed=0.0,
                heading=0.0,
                satellites=satellites,
                timestamp=datetime.now(),
                source="GPS"
            )
        except (ValueError, IndexError):
            return None
    
    def _parse_rmc(self, line: str) -> Optional[GPSData]:
        """Parse RMC sentence (movement data)."""
        parts = line.split(',')
        if len(parts) < 12:
            return None
        
        try:
            # Parse latitude
            lat_deg = float(parts[3][:2]) if parts[3] else 0
            lat_min = float(parts[3][2:]) if len(parts[3]) > 2 else 0
            latitude = lat_deg + lat_min / 60
            if parts[4] == 'S':
                latitude = -latitude
            
            # Parse longitude
            lon_deg = float(parts[5][:3]) if parts[5] else 0
            lon_min = float(parts[5][3:]) if len(parts[5]) > 3 else 0
            longitude = lon_deg + lon_min / 60
            if parts[6] == 'W':
                longitude = -longitude
            
            # Parse speed (knots to m/s)
            speed_knots = float(parts[7]) if parts[7] else 0
            speed = speed_knots * 0.514444
            
            # Parse heading
            heading = float(parts[8]) if parts[8] else 0
            
            return GPSData(
                latitude=latitude,
                longitude=longitude,
                altitude=0.0,
                accuracy=0.0,
                speed=speed,
                heading=heading,
                satellites=0,
                timestamp=datetime.now(),
                source="GPS"
            )
        except (ValueError, IndexError):
            return None
    
    def simulate_data(self) -> GPSData:
        """Generate simulated GPS data for testing."""
        import random
        return GPSData(
            latitude=35.6892 + random.uniform(-0.001, 0.001),
            longitude=51.3890 + random.uniform(-0.001, 0.001),
            altitude=1200.0 + random.uniform(-10, 10),
            accuracy=5.0 + random.uniform(-2, 2),
            speed=random.uniform(0, 20),
            heading=random.uniform(0, 360),
            satellites=random.randint(8, 12),
            timestamp=datetime.now(),
            source="GPS"
        )
