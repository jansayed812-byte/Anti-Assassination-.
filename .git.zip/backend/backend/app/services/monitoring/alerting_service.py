from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import json


class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AlertStatus(Enum):
    ACTIVE = "active"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"


@dataclass
class Alert:
    id: str
    severity: AlertSeverity
    title: str
    description: str
    source: str
    status: AlertStatus
    created_at: datetime
    acknowledged_at: Optional[datetime]
    resolved_at: Optional[datetime]
    acknowledged_by: Optional[str]
    resolved_by: Optional[str]
    metadata: Dict[str, Any]


class AlertingService:
    """Service for system monitoring and alert management."""
    
    def __init__(self):
        self.alerts: Dict[str, Alert] = {}
        self.alert_rules: Dict[str, Dict[str, Any]] = {}
        self.alert_callbacks: List[Callable[[Alert], None]] = []
        self.alert_counter = 0
        self._initialize_alert_rules()
    
    def _initialize_alert_rules(self):
        """Initialize alert rules for system monitoring."""
        self.alert_rules = {
            "high_latency": {
                "name": "High Latency",
                "condition": "e2e_latency > 1.0",
                "severity": AlertSeverity.WARNING,
                "description": "End-to-end latency exceeds 1 second threshold"
            },
            "system_unavailable": {
                "name": "System Unavailable",
                "condition": "availability < 99.0",
                "severity": AlertSeverity.CRITICAL,
                "description": "System availability below 99%"
            },
            "position_accuracy_low": {
                "name": "Low Position Accuracy",
                "condition": "position_accuracy > 10.0",
                "severity": AlertSeverity.WARNING,
                "description": "Position accuracy exceeds 10 meters"
            },
            "device_offline": {
                "name": "Device Offline",
                "condition": "device_status == 'offline'",
                "severity": AlertSeverity.ERROR,
                "description": "Device has gone offline"
            },
            "threat_detected": {
                "name": "Threat Detected",
                "condition": "threat_level == 'high' or threat_level == 'critical'",
                "severity": AlertSeverity.CRITICAL,
                "description": "High or critical threat detected"
            },
            "sla_violation": {
                "name": "SLA Violation",
                "condition": "sla_compliance == false",
                "severity": AlertSeverity.ERROR,
                "description": "SLA compliance violation detected"
            },
            "database_connection_failed": {
                "name": "Database Connection Failed",
                "condition": "db_connection == 'failed'",
                "severity": AlertSeverity.CRITICAL,
                "description": "Database connection has failed"
            },
            "memory_usage_high": {
                "name": "High Memory Usage",
                "condition": "memory_usage > 90.0",
                "severity": AlertSeverity.WARNING,
                "description": "Memory usage exceeds 90%"
            },
            "disk_space_low": {
                "name": "Low Disk Space",
                "condition": "disk_space < 10.0",
                "severity": AlertSeverity.ERROR,
                "description": "Available disk space below 10%"
            },
            "authentication_failure": {
                "name": "Authentication Failure",
                "condition": "auth_failure_count > 5",
                "severity": AlertSeverity.WARNING,
                "description": "Multiple authentication failures detected"
            }
        }
    
    def create_alert(self, severity: AlertSeverity, title: str, description: str,
                    source: str, metadata: Dict[str, Any] = None) -> Alert:
        """Create a new alert."""
        self.alert_counter += 1
        alert_id = f"alert_{self.alert_counter}_{int(datetime.now().timestamp())}"
        
        alert = Alert(
            id=alert_id,
            severity=severity,
            title=title,
            description=description,
            source=source,
            status=AlertStatus.ACTIVE,
            created_at=datetime.now(),
            acknowledged_at=None,
            resolved_at=None,
            acknowledged_by=None,
            resolved_by=None,
            metadata=metadata or {}
        )
        
        self.alerts[alert_id] = alert
        
        # Notify callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                print(f"Error in alert callback: {e}")
        
        return alert
    
    def acknowledge_alert(self, alert_id: str, user_id: str) -> bool:
        """Acknowledge an alert."""
        alert = self.alerts.get(alert_id)
        if not alert or alert.status != AlertStatus.ACTIVE:
            return False
        
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_at = datetime.now()
        alert.acknowledged_by = user_id
        
        return True
    
    def resolve_alert(self, alert_id: str, user_id: str) -> bool:
        """Resolve an alert."""
        alert = self.alerts.get(alert_id)
        if not alert:
            return False
        
        alert.status = AlertStatus.RESOLVED
        alert.resolved_at = datetime.now()
        alert.resolved_by = user_id
        
        return True
    
    def suppress_alert(self, alert_id: str) -> bool:
        """Suppress an alert."""
        alert = self.alerts.get(alert_id)
        if not alert:
            return False
        
        alert.status = AlertStatus.SUPPRESSED
        return True
    
    def get_alert(self, alert_id: str) -> Optional[Alert]:
        """Get a specific alert."""
        return self.alerts.get(alert_id)
    
    def get_alerts_by_status(self, status: AlertStatus) -> List[Alert]:
        """Get alerts by status."""
        return [alert for alert in self.alerts.values() if alert.status == status]
    
    def get_alerts_by_severity(self, severity: AlertSeverity) -> List[Alert]:
        """Get alerts by severity."""
        return [alert for alert in self.alerts.values() if alert.severity == severity]
    
    def get_active_alerts(self) -> List[Alert]:
        """Get all active alerts."""
        return self.get_alerts_by_status(AlertStatus.ACTIVE)
    
    def get_alert_statistics(self) -> Dict[str, Any]:
        """Get alert statistics."""
        total_alerts = len(self.alerts)
        active_alerts = len(self.get_alerts_by_status(AlertStatus.ACTIVE))
        acknowledged_alerts = len(self.get_alerts_by_status(AlertStatus.ACKNOWLEDGED))
        resolved_alerts = len(self.get_alerts_by_status(AlertStatus.RESOLVED))
        
        severity_counts = {
            severity.value: len(self.get_alerts_by_severity(severity))
            for severity in AlertSeverity
        }
        
        return {
            "total_alerts": total_alerts,
            "active_alerts": active_alerts,
            "acknowledged_alerts": acknowledged_alerts,
            "resolved_alerts": resolved_alerts,
            "severity_breakdown": severity_counts,
            "resolution_rate": resolved_alerts / total_alerts if total_alerts > 0 else 0
        }
    
    def add_alert_callback(self, callback: Callable[[Alert], None]):
        """Add a callback for new alerts."""
        self.alert_callbacks.append(callback)
    
    def remove_alert_callback(self, callback: Callable[[Alert], None]):
        """Remove an alert callback."""
        if callback in self.alert_callbacks:
            self.alert_callbacks.remove(callback)
    
    def check_alert_rules(self, metrics: Dict[str, Any]) -> List[Alert]:
        """Check alert rules against current metrics."""
        triggered_alerts = []
        
        for rule_id, rule in self.alert_rules.items():
            if self._evaluate_condition(rule["condition"], metrics):
                alert = self.create_alert(
                    severity=rule["severity"],
                    title=rule["name"],
                    description=rule["description"],
                    source="alert_rule",
                    metadata={"rule_id": rule_id, "metrics": metrics}
                )
                triggered_alerts.append(alert)
        
        return triggered_alerts
    
    def _evaluate_condition(self, condition: str, metrics: Dict[str, Any]) -> bool:
        """Evaluate an alert condition against metrics."""
        # Simplified condition evaluation
        # In production, this would use a proper expression parser
        
        try:
            # Extract metric and comparison
            if ">" in condition:
                parts = condition.split(">")
                metric = parts[0].strip()
                threshold = float(parts[1].strip())
                return metrics.get(metric, 0) > threshold
            elif "<" in condition:
                parts = condition.split("<")
                metric = parts[0].strip()
                threshold = float(parts[1].strip())
                return metrics.get(metric, 0) < threshold
            elif "==" in condition:
                parts = condition.split("==")
                metric = parts[0].strip()
                value = parts[1].strip().strip("'\"")
                return str(metrics.get(metric, "")) == value
            else:
                return False
        except Exception:
            return False
    
    def cleanup_old_alerts(self, days: int = 30) -> int:
        """Clean up alerts older than specified days."""
        cutoff_date = datetime.now() - timedelta(days=days)
        removed_count = 0
        
        alert_ids_to_remove = [
            alert_id for alert_id, alert in self.alerts.items()
            if alert.created_at < cutoff_date and alert.status == AlertStatus.RESOLVED
        ]
        
        for alert_id in alert_ids_to_remove:
            del self.alerts[alert_id]
            removed_count += 1
        
        return removed_count
    
    def get_alert_rules(self) -> Dict[str, Dict[str, Any]]:
        """Get all alert rules."""
        return self.alert_rules
    
    def simulate_alert(self, severity: AlertSeverity = AlertSeverity.WARNING) -> Alert:
        """Simulate an alert for testing."""
        return self.create_alert(
            severity=severity,
            title="Simulated Alert",
            description="This is a simulated alert for testing purposes",
            source="simulation",
            metadata={"simulated": True}
        )


# Global alerting service instance
alerting_service = AlertingService()
