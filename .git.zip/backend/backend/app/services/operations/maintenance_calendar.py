from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import json


class MaintenanceFrequency(Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    SEMIANNUAL = "semiannual"


class MaintenanceStatus(Enum):
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    FAILED = "failed"


@dataclass
class MaintenanceTask:
    id: str
    title: str
    description: str
    frequency: MaintenanceFrequency
    estimated_duration_hours: float
    priority: str  # low, medium, high, critical
    dependencies: List[str]
    status: MaintenanceStatus
    last_completed: Optional[datetime]
    next_scheduled: datetime
    assigned_to: Optional[str]
    notes: str


class MaintenanceCalendarService:
    """Service for managing maintenance calendar and operational tasks."""
    
    def __init__(self):
        self.tasks: Dict[str, MaintenanceTask] = {}
        self.task_history: List[Dict[str, Any]] = []
        self._initialize_tasks()
    
    def _initialize_tasks(self):
        """Initialize maintenance tasks as specified in DEFENDERS.md."""
        # Daily tasks
        self._add_task(MaintenanceTask(
            id="daily_health_check",
            title="Daily Health Check",
            description="Check alertmanager + health endpoints",
            frequency=MaintenanceFrequency.DAILY,
            estimated_duration_hours=0.5,
            priority="high",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(hours=1),
            assigned_to="operations_team",
            notes="Verify all system health endpoints are responding"
        ))
        
        self._add_task(MaintenanceTask(
            id="daily_buffer_check",
            title="Daily Buffer Depth Check",
            description="Check offline buffer depth of edge nodes",
            frequency=MaintenanceFrequency.DAILY,
            estimated_duration_hours=0.25,
            priority="medium",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(hours=2),
            assigned_to="operations_team",
            notes="Ensure offline buffers are not overflowing"
        ))
        
        # Weekly tasks
        self._add_task(MaintenanceTask(
            id="weekly_alert_drill",
            title="Weekly Alert Drill",
            description="Drill level 4 alert procedures",
            frequency=MaintenanceFrequency.WEEKLY,
            estimated_duration_hours=1.0,
            priority="high",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=7),
            assigned_to="security_team",
            notes="Practice PANIC scenario response"
        ))
        
        self._add_task(MaintenanceTask(
            id="weekly_ai_regression",
            title="Weekly AI Regression Check",
            description="Review AI metrics (mAP, coverage)",
            frequency=MaintenanceFrequency.WEEKLY,
            estimated_duration_hours=2.0,
            priority="medium",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=7),
            assigned_to="ml_team",
            notes="Monitor for model performance degradation"
        ))
        
        # Monthly tasks
        self._add_task(MaintenanceTask(
            id="monthly_dr_drill",
            title="Monthly DR Drill",
            description="Full DR drill with RTO/RPO measurement",
            frequency=MaintenanceFrequency.MONTHLY,
            estimated_duration_hours=4.0,
            priority="critical",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=30),
            assigned_to="operations_team",
            notes="Complete disaster recovery testing"
        ))
        
        self._add_task(MaintenanceTask(
            id="monthly_key_rotation",
            title="Monthly Key Rotation",
            description="Rotate keys with Vault automation + 4-eye verification",
            frequency=MaintenanceFrequency.MONTHLY,
            estimated_duration_hours=2.0,
            priority="critical",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=30),
            assigned_to="security_team",
            notes="Rotate encryption keys and secrets"
        ))
        
        self._add_task(MaintenanceTask(
            id="monthly_bug_review",
            title="Monthly Bug Review",
            description="Review open bugs + prioritize",
            frequency=MaintenanceFrequency.MONTHLY,
            estimated_duration_hours=3.0,
            priority="medium",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=30),
            assigned_to="dev_team",
            notes="Review and prioritize open issues"
        ))
        
        # Quarterly tasks
        self._add_task(MaintenanceTask(
            id="quarterly_pentest",
            title="Quarterly Penetration Test",
            description="Pentest + ISO/NIST compliance review",
            frequency=MaintenanceFrequency.QUARTERLY,
            estimated_duration_hours=40.0,
            priority="critical",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=90),
            assigned_to="security_team",
            notes="Conduct security assessment and compliance review"
        ))
        
        self._add_task(MaintenanceTask(
            id="quarterly_model_retrain",
            title="Quarterly Model Retraining",
            description="Retrain intel model with new data + active learning",
            frequency=MaintenanceFrequency.QUARTERLY,
            estimated_duration_hours=20.0,
            priority="high",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=90),
            assigned_to="ml_team",
            notes="Update ML models with new intelligence data"
        ))
        
        self._add_task(MaintenanceTask(
            id="quarterly_runbook_review",
            title="Quarterly Runbook Review",
            description="Review runbooks with operations team",
            frequency=MaintenanceFrequency.QUARTERLY,
            estimated_duration_hours=8.0,
            priority="medium",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=90),
            assigned_to="operations_team",
            notes="Update operational procedures"
        ))
        
        # Semiannual tasks
        self._add_task(MaintenanceTask(
            id="semiannual_accuracy_campaign",
            title="Semiannual Accuracy Campaign",
            description="Field accuracy testing on golden routes",
            frequency=MaintenanceFrequency.SEMIANNUAL,
            estimated_duration_hours=40.0,
            priority="high",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=180),
            assigned_to="operations_team",
            notes="Field test positioning accuracy on standard routes"
        ))
        
        self._add_task(MaintenanceTask(
            id="semiannual_failover",
            title="Semiannual Data Center Failover",
            description="Manual data center failover test",
            frequency=MaintenanceFrequency.SEMIANNUAL,
            estimated_duration_hours=8.0,
            priority="critical",
            dependencies=[],
            status=MaintenanceStatus.SCHEDULED,
            last_completed=None,
            next_scheduled=datetime.now() + timedelta(days=180),
            assigned_to="operations_team",
            notes="Test disaster recovery failover procedures"
        ))
    
    def _add_task(self, task: MaintenanceTask):
        """Add a maintenance task."""
        self.tasks[task.id] = task
    
    def get_task(self, task_id: str) -> Optional[MaintenanceTask]:
        """Get a specific maintenance task."""
        return self.tasks.get(task_id)
    
    def get_all_tasks(self) -> List[MaintenanceTask]:
        """Get all maintenance tasks."""
        return list(self.tasks.values())
    
    def get_tasks_by_frequency(self, frequency: MaintenanceFrequency) -> List[MaintenanceTask]:
        """Get tasks by frequency."""
        return [task for task in self.tasks.values() if task.frequency == frequency]
    
    def get_tasks_by_status(self, status: MaintenanceStatus) -> List[MaintenanceTask]:
        """Get tasks by status."""
        return [task for task in self.tasks.values() if task.status == status]
    
    def get_upcoming_tasks(self, days: int = 7) -> List[MaintenanceTask]:
        """Get tasks scheduled in the next N days."""
        cutoff_date = datetime.now() + timedelta(days=days)
        return [
            task for task in self.tasks.values()
            if task.next_scheduled <= cutoff_date and task.status == MaintenanceStatus.SCHEDULED
        ]
    
    def complete_task(self, task_id: str, notes: str = "") -> bool:
        """Mark a maintenance task as completed."""
        task = self.tasks.get(task_id)
        if not task:
            return False
        
        # Record history
        self.task_history.append({
            "task_id": task_id,
            "title": task.title,
            "completed_at": datetime.now().isoformat(),
            "notes": notes,
            "duration_hours": task.estimated_duration_hours
        })
        
        # Update task
        task.status = MaintenanceStatus.COMPLETED
        task.last_completed = datetime.now()
        
        # Schedule next occurrence
        task.next_scheduled = self._calculate_next_schedule(task.frequency)
        task.status = MaintenanceStatus.SCHEDULED
        
        return True
    
    def _calculate_next_schedule(self, frequency: MaintenanceFrequency) -> datetime:
        """Calculate next scheduled date based on frequency."""
        now = datetime.now()

        if frequency == MaintenanceFrequency.DAILY:
            return now + timedelta(days=1)
        elif frequency == MaintenanceFrequency.WEEKLY:
            return now + timedelta(weeks=1)
        elif frequency == MaintenanceFrequency.MONTHLY:
            return now + timedelta(days=30)
        elif frequency == MaintenanceFrequency.QUARTERLY:
            return now + timedelta(days=90)
        elif frequency == MaintenanceFrequency.SEMIANNUAL:
            return now + timedelta(days=180)
        else:
            return now + timedelta(days=1)

    def start_task(self, task_id: str) -> bool:
        """Mark a maintenance task as in progress."""
        task = self.tasks.get(task_id)
        if not task:
            return False

        # Check dependencies
        for dep_id in task.dependencies:
            dep_task = self.tasks.get(dep_id)
            if dep_task and dep_task.status != MaintenanceStatus.COMPLETED:
                return False

        task.status = MaintenanceStatus.IN_PROGRESS
        return True

    def fail_task(self, task_id: str, error_message: str = "") -> bool:
        """Mark a maintenance task as failed."""
        task = self.tasks.get(task_id)
        if not task:
            return False

        # Record history
        self.task_history.append({
            "task_id": task_id,
            "title": task.title,
            "failed_at": datetime.now().isoformat(),
            "error": error_message,
            "duration_hours": task.estimated_duration_hours
        })

        task.status = MaintenanceStatus.FAILED
        task.notes = f"Failed: {error_message}"

        # Reschedule for retry
        task.next_scheduled = datetime.now() + timedelta(days=1)
        task.status = MaintenanceStatus.SCHEDULED

        return True

    def get_overdue_tasks(self) -> List[MaintenanceTask]:
        """Get tasks that are overdue."""
        return [
            task for task in self.tasks.values()
            if task.next_scheduled < datetime.now() and task.status == MaintenanceStatus.SCHEDULED
        ]

    def get_dependent_tasks(self, task_id: str) -> List[MaintenanceTask]:
        """Get tasks that depend on the specified task."""
        return [
            task for task in self.tasks.values()
            if task_id in task.dependencies
        ]

    def reschedule_task(self, task_id: str, new_date: datetime, reason: str = "") -> bool:
        """Reschedule a maintenance task to a new date."""
        task = self.tasks.get(task_id)
        if not task:
            return False

        task.next_scheduled = new_date
        task.notes = f"Rescheduled: {reason}"

        return True

    def assign_task(self, task_id: str, assignee: str) -> bool:
        """Assign a maintenance task to a person/team."""
        task = self.tasks.get(task_id)
        if not task:
            return False

        task.assigned_to = assignee
        return True

    def generate_maintenance_report(self, period: str = "monthly") -> Dict[str, Any]:
        """Generate comprehensive maintenance report."""
        if period == "monthly":
            start_date = datetime.now() - timedelta(days=30)
        elif period == "quarterly":
            start_date = datetime.now() - timedelta(days=90)
        else:
            start_date = datetime.now() - timedelta(days=7)

        end_date = datetime.now()

        # Filter history by period
        period_history = [
            entry for entry in self.task_history
            if start_date <= datetime.fromisoformat(entry.get("completed_at", entry.get("failed_at", ""))) <= end_date
        ]

        completed_count = sum(1 for entry in period_history if "completed_at" in entry)
        failed_count = sum(1 for entry in period_history if "failed_at" in entry)
        total_hours = sum(entry.get("duration_hours", 0) for entry in period_history)

        return {
            "report_type": "Maintenance Report",
            "period": period,
            "generated_at": datetime.now().isoformat(),
            "period_start": start_date.isoformat(),
            "period_end": end_date.isoformat(),
            "summary": {
                "total_tasks_executed": len(period_history),
                "completed_tasks": completed_count,
                "failed_tasks": failed_count,
                "success_rate": completed_count / len(period_history) if period_history else 0,
                "total_hours_spent": total_hours,
                "average_hours_per_task": total_hours / len(period_history) if period_history else 0
            },
            "by_frequency": self._get_summary_by_frequency(period_history),
            "by_team": self._get_summary_by_team(period_history),
            "recent_failures": [entry for entry in period_history if "failed_at" in entry][-5:],
            "upcoming_critical": [
                task for task in self.get_upcoming_tasks(30)
                if task.priority == "critical"
            ]
        }

    def _get_summary_by_frequency(self, history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get summary by maintenance frequency."""
        summary = {}
        for entry in history:
            task_id = entry["task_id"]
            task = self.tasks.get(task_id)
            if task:
                freq = task.frequency.value
                if freq not in summary:
                    summary[freq] = {"count": 0, "hours": 0}
                summary[freq]["count"] += 1
                summary[freq]["hours"] += entry.get("duration_hours", 0)
        return summary

    def _get_summary_by_team(self, history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get summary by team."""
        summary = {}
        for entry in history:
            task_id = entry["task_id"]
            task = self.tasks.get(task_id)
            if task and task.assigned_to:
                team = task.assigned_to
                if team not in summary:
                    summary[team] = {"count": 0, "hours": 0}
                summary[team]["count"] += 1
                summary[team]["hours"] += entry.get("duration_hours", 0)
        return summary
    
    def skip_task(self, task_id: str, reason: str = "") -> bool:
        """Skip a maintenance task."""
        task = self.tasks.get(task_id)
        if not task:
            return False
        
        task.status = MaintenanceStatus.SKIPPED
        task.notes = reason
        
        # Schedule next occurrence
        task.next_scheduled = self._calculate_next_schedule(task.frequency)
        task.status = MaintenanceStatus.SCHEDULED
        
        return True
    
    def get_maintenance_calendar(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Get maintenance calendar for a date range."""
        tasks_in_range = [
            task for task in self.tasks.values()
            if start_date <= task.next_scheduled <= end_date
        ]
        
        return {
            "period": {
                "start": start_date.isoformat(),
                "end": end_date.isoformat()
            },
            "tasks": [
                {
                    "id": task.id,
                    "title": task.title,
                    "description": task.description,
                    "frequency": task.frequency.value,
                    "estimated_duration_hours": task.estimated_duration_hours,
                    "priority": task.priority,
                    "scheduled": task.next_scheduled.isoformat(),
                    "assigned_to": task.assigned_to
                }
                for task in tasks_in_range
            ],
            "count": len(tasks_in_range)
        }
    
    def get_maintenance_summary(self) -> Dict[str, Any]:
        """Get summary of maintenance status."""
        total_tasks = len(self.tasks)
        completed_this_month = sum(
            1 for task in self.tasks.values()
            if task.last_completed and (datetime.now() - task.last_completed).days <= 30
        )
        
        upcoming_this_week = len(self.get_upcoming_tasks(7))
        overdue_tasks = [
            task for task in self.tasks.values()
            if task.next_scheduled < datetime.now() and task.status == MaintenanceStatus.SCHEDULED
        ]
        
        return {
            "total_tasks": total_tasks,
            "completed_this_month": completed_this_month,
            "upcoming_this_week": upcoming_this_week,
            "overdue_tasks": len(overdue_tasks),
            "task_history_count": len(self.task_history),
            "tasks_by_frequency": {
                freq.value: len(self.get_tasks_by_frequency(MaintenanceFrequency(freq)))
                for freq in MaintenanceFrequency
            },
            "tasks_by_status": {
                status.value: len(self.get_tasks_by_status(MaintenanceStatus(status)))
                for status in MaintenanceStatus
            }
        }


# Global maintenance calendar service instance
maintenance_calendar_service = MaintenanceCalendarService()
