from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import statistics


class SLAMetric(Enum):
    AVAILABILITY = "availability"
    E2E_LATENCY = "e2e_latency"
    ALERT_DELIVERY = "alert_delivery"
    POSITION_ACCURACY = "position_accuracy"
    DISASTER_RECOVERY = "disaster_recovery"
    THROUGHPUT = "throughput"
    ERROR_RATE = "error_rate"
    STORAGE_CAPACITY = "storage_capacity"
    DATABASE_PERFORMANCE = "database_performance"
    NETWORK_BANDWIDTH = "network_bandwidth"


class SLAStatus(Enum):
    COMPLIANT = "compliant"
    WARNING = "warning"
    VIOLATION = "violation"


@dataclass
class SLATarget:
    metric: SLAMetric
    target_value: float
    unit: str
    measurement_window: str
    penalty_action: str


@dataclass
class SLAMeasurement:
    metric: SLAMetric
    value: float
    timestamp: datetime
    status: SLAStatus
    details: str


class SLAMonitorService:
    """Service for monitoring SLA compliance and operational metrics."""
    
    def __init__(self):
        self.sla_targets: Dict[SLAMetric, SLATarget] = {}
        self.measurements: Dict[SLAMetric, List[SLAMeasurement]] = {}
        self.violations: List[Dict[str, Any]] = []
        self._initialize_targets()
    
    def _initialize_targets(self):
        """Initialize SLA targets as specified in DEFENDERS.md §23.1."""
        self.sla_targets = {
            SLAMetric.AVAILABILITY: SLATarget(
                metric=SLAMetric.AVAILABILITY,
                target_value=99.9,
                unit="%",
                measurement_window="monthly",
                penalty_action="mandatory_postmortem",
                description="Core system availability measured by Prometheus"
            ),
            SLAMetric.E2E_LATENCY: SLATarget(
                metric=SLAMetric.E2E_LATENCY,
                target_value=1.0,
                unit="seconds",
                measurement_window="continuous",
                penalty_action="rollback_last_release",
                description="End-to-end latency p99 measured in soak layer"
            ),
            SLAMetric.ALERT_DELIVERY: SLATarget(
                metric=SLAMetric.ALERT_DELIVERY,
                target_value=100.0,
                unit="%",
                measurement_window="continuous",
                penalty_action="root_cause_analysis_48h",
                description="Alert delivery rate measured by counter"
            ),
            SLAMetric.POSITION_ACCURACY: SLATarget(
                metric=SLAMetric.POSITION_ACCURACY,
                target_value=5.0,
                unit="meters",
                measurement_window="monthly_campaign",
                penalty_action="recalibrate_fusion",
                description="CEP95 accuracy: <5m rural, <10m urban"
            ),
            SLAMetric.DISASTER_RECOVERY: SLATarget(
                metric=SLAMetric.DISASTER_RECOVERY,
                target_value=5.0,
                unit="minutes",
                measurement_window="monthly_drill",
                penalty_action="review_ha_architecture",
                description="RTO for disaster recovery scenarios"
            ),
            SLAMetric.THROUGHPUT: SLATarget(
                metric=SLAMetric.THROUGHPUT,
                target_value=1000,
                unit="requests/second",
                measurement_window="continuous",
                penalty_action="scale_infrastructure",
                description="System throughput capacity"
            ),
            SLAMetric.ERROR_RATE: SLATarget(
                metric=SLAMetric.ERROR_RATE,
                target_value=0.1,
                unit="%",
                measurement_window="continuous",
                penalty_action="investigate_and_fix",
                description="System error rate"
            ),
            SLAMetric.STORAGE_CAPACITY: SLATarget(
                metric=SLAMetric.STORAGE_CAPACITY,
                target_value=80.0,
                unit="%",
                measurement_window="daily",
                penalty_action="expand_storage",
                description="Storage capacity utilization threshold"
            ),
            SLAMetric.DATABASE_PERFORMANCE: SLATarget(
                metric=SLAMetric.DATABASE_PERFORMANCE,
                target_value=100,
                unit="milliseconds",
                measurement_window="continuous",
                penalty_action="optimize_queries",
                description="Database query response time p95"
            ),
            SLAMetric.NETWORK_BANDWIDTH: SLATarget(
                metric=SLAMetric.NETWORK_BANDWIDTH,
                target_value=70.0,
                unit="%",
                measurement_window="continuous",
                penalty_action="upgrade_network",
                description="Network bandwidth utilization"
            )
        }
    
    def record_measurement(self, metric: SLAMetric, value: float,
                          details: str = "") -> SLAMeasurement:
        """Record a measurement for an SLA metric."""
        target = self.sla_targets.get(metric)
        if not target:
            raise ValueError(f"Unknown metric: {metric}")

        # Determine status based on metric type
        higher_is_better = [
            SLAMetric.AVAILABILITY,
            SLAMetric.ALERT_DELIVERY,
            SLAMetric.THROUGHPUT
        ]

        if metric in higher_is_better:
            # Higher is better
            status = SLAStatus.COMPLIANT if value >= target.target_value else SLAStatus.VIOLATION
        else:
            # Lower is better
            status = SLAStatus.COMPLIANT if value <= target.target_value else SLAStatus.VIOLATION

        measurement = SLAMeasurement(
            metric=metric,
            value=value,
            timestamp=datetime.now(),
            status=status,
            details=details
        )

        # Store measurement
        if metric not in self.measurements:
            self.measurements[metric] = []
        self.measurements[metric].append(measurement)

        # Keep only last 1000 measurements per metric
        if len(self.measurements[metric]) > 1000:
            self.measurements[metric] = self.measurements[metric][-1000:]

        # Record violation if applicable
        if status == SLAStatus.VIOLATION:
            self.violations.append({
                "metric": metric.value,
                "value": value,
                "target": target.target_value,
                "unit": target.unit,
                "timestamp": datetime.now().isoformat(),
                "penalty_action": target.penalty_action,
                "details": details,
                "severity": self._assess_violation_severity(metric, value, target.target_value)
            })

        return measurement
    
    def _assess_violation_severity(self, metric: SLAMetric, value: float, target: float) -> str:
        """Assess severity of SLA violation."""
        if metric == SLAMetric.AVAILABILITY:
            if value < 95.0:
                return "critical"
            elif value < 98.0:
                return "high"
            else:
                return "medium"
        elif metric == SLAMetric.E2E_LATENCY:
            if value > target * 3:
                return "critical"
            elif value > target * 2:
                return "high"
            else:
                return "medium"
        elif metric == SLAMetric.ALERT_DELIVERY:
            if value < 95.0:
                return "critical"
            elif value < 99.0:
                return "high"
            else:
                return "medium"
        elif metric == SLAMetric.DISASTER_RECOVERY:
            if value > target * 5:
                return "critical"
            elif value > target * 2:
                return "high"
            else:
                return "medium"
        else:
            return "medium"

    def get_metric_status(self, metric: SLAMetric) -> Dict[str, Any]:
        """Get current status for a specific metric."""
        target = self.sla_targets.get(metric)
        measurements = self.measurements.get(metric, [])

        if not measurements:
            return {
                "metric": metric.value,
                "target": target.target_value if target else None,
                "unit": target.unit if target else None,
                "current_value": None,
                "status": "no_data",
                "measurements_count": 0,
                "description": target.description if target else None
            }

        latest = measurements[-1]

        # Calculate statistics
        values = [m.value for m in measurements]
        avg_value = statistics.mean(values)
        min_value = min(values)
        max_value = max(values)

        # Calculate percentile (p95, p99)
        sorted_values = sorted(values)
        p95 = sorted_values[int(len(sorted_values) * 0.95)] if len(sorted_values) >= 20 else None
        p99 = sorted_values[int(len(sorted_values) * 0.99)] if len(sorted_values) >= 100 else None

        return {
            "metric": metric.value,
            "target": target.target_value,
            "unit": target.unit,
            "current_value": latest.value,
            "status": latest.status.value,
            "average_value": avg_value,
            "min_value": min_value,
            "max_value": max_value,
            "p95": p95,
            "p99": p99,
            "measurements_count": len(measurements),
            "last_measured": latest.timestamp.isoformat(),
            "description": target.description if target else None,
            "measurement_window": target.measurement_window if target else None
        }
    
    def get_all_metrics_status(self) -> Dict[str, Any]:
        """Get status for all SLA metrics."""
        return {
            "timestamp": datetime.now().isoformat(),
            "metrics": {
                metric.value: self.get_metric_status(metric)
                for metric in SLAMetric
            },
            "overall_compliance": self._calculate_overall_compliance()
        }
    
    def _calculate_overall_compliance(self) -> str:
        """Calculate overall SLA compliance."""
        compliant_count = 0
        total_count = 0
        
        for metric in SLAMetric:
            measurements = self.measurements.get(metric, [])
            if measurements:
                total_count += 1
                if measurements[-1].status == SLAStatus.COMPLIANT:
                    compliant_count += 1
        
        if total_count == 0:
            return "no_data"
        
        compliance_rate = compliant_count / total_count
        
        if compliance_rate >= 0.9:
            return "excellent"
        elif compliance_rate >= 0.7:
            return "good"
        elif compliance_rate >= 0.5:
            return "warning"
        else:
            return "critical"
    
    def get_violations(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent SLA violations."""
        return self.violations[-limit:]
    
    def get_compliance_report(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Generate compliance report for a time period."""
        report = {
            "period": {
                "start": start_date.isoformat(),
                "end": end_date.isoformat()
            },
            "metrics": {}
        }
        
        for metric in SLAMetric:
            measurements = self.measurements.get(metric, [])
            # Filter by date range
            period_measurements = [
                m for m in measurements
                if start_date <= m.timestamp <= end_date
            ]
            
            if period_measurements:
                values = [m.value for m in period_measurements]
                target = self.sla_targets[metric]
                
                compliant_count = sum(
                    1 for m in period_measurements
                    if m.status == SLAStatus.COMPLIANT
                )
                
                report["metrics"][metric.value] = {
                    "target": target.target_value,
                    "unit": target.unit,
                    "total_measurements": len(period_measurements),
                    "compliant_measurements": compliant_count,
                    "compliance_rate": compliant_count / len(period_measurements),
                    "average_value": statistics.mean(values),
                    "min_value": min(values),
                    "max_value": max(values)
                }
        
        return report
    
    def simulate_measurement(self, metric: SLAMetric) -> SLAMeasurement:
        """Simulate a measurement for testing."""
        import random
        target = self.sla_targets[metric]

        # Generate value near target with some variance
        if metric in [SLAMetric.AVAILABILITY, SLAMetric.ALERT_DELIVERY]:
            # Higher is better
            value = target.target_value + random.uniform(-2, 0.5)
        else:
            # Lower is better
            value = target.target_value + random.uniform(-0.5, 2)

        return self.record_measurement(metric, value, "simulated_measurement")

    def get_trend_analysis(self, metric: SLAMetric, days: int = 30) -> Dict[str, Any]:
        """Analyze trend for a specific metric over time period."""
        measurements = self.measurements.get(metric, [])
        if not measurements:
            return {"error": "No measurements available"}

        # Filter by time period
        cutoff_date = datetime.now() - timedelta(days=days)
        period_measurements = [m for m in measurements if m.timestamp >= cutoff_date]

        if len(period_measurements) < 2:
            return {"error": "Insufficient measurements for trend analysis"}

        # Calculate trend
        values = [m.value for m in period_measurements]
        timestamps = [m.timestamp.timestamp() for m in period_measurements]

        # Simple linear regression for trend
        import math
        n = len(values)
        sum_x = sum(timestamps)
        sum_y = sum(values)
        sum_xy = sum(x * y for x, y in zip(timestamps, values))
        sum_x2 = sum(x * x for x in timestamps)

        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
        intercept = (sum_y - slope * sum_x) / n

        # Determine trend direction
        higher_is_better = metric in [SLAMetric.AVAILABILITY, SLAMetric.ALERT_DELIVERY, SLAMetric.THROUGHPUT]
        if higher_is_better:
            trend = "improving" if slope > 0 else "degrading"
        else:
            trend = "improving" if slope < 0 else "degrading"

        return {
            "metric": metric.value,
            "period_days": days,
            "measurements_count": len(period_measurements),
            "trend": trend,
            "slope": slope,
            "intercept": intercept,
            "current_value": values[-1],
            "period_start_value": values[0],
            "change": values[-1] - values[0],
            "change_percentage": ((values[-1] - values[0]) / values[0] * 100) if values[0] != 0 else 0
        }

    def forecast_metric(self, metric: SLAMetric, days_ahead: int = 7) -> Dict[str, Any]:
        """Forecast metric value based on historical trend."""
        trend_analysis = self.get_trend_analysis(metric, days=30)
        if "error" in trend_analysis:
            return trend_analysis

        # Simple linear forecast
        slope = trend_analysis["slope"]
        current_value = trend_analysis["current_value"]
        current_timestamp = datetime.now().timestamp()
        future_timestamp = (datetime.now() + timedelta(days=days_ahead)).timestamp()

        forecast_value = slope * (future_timestamp - current_timestamp) + current_value

        target = self.sla_targets[metric]
        higher_is_better = metric in [SLAMetric.AVAILABILITY, SLAMetric.ALERT_DELIVERY, SLAMetric.THROUGHPUT]

        if higher_is_better:
            forecast_status = "compliant" if forecast_value >= target.target_value else "violation"
        else:
            forecast_status = "compliant" if forecast_value <= target.target_value else "violation"

        return {
            "metric": metric.value,
            "days_ahead": days_ahead,
            "forecast_value": forecast_value,
            "target": target.target_value,
            "unit": target.unit,
            "forecast_status": forecast_status,
            "confidence": "low",  # Would be calculated with more sophisticated methods
            "based_on_trend": trend_analysis["trend"]
        }

    def get_sla_dashboard(self) -> Dict[str, Any]:
        """Get comprehensive SLA dashboard data."""
        dashboard = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": self._calculate_overall_compliance(),
            "metrics": {},
            "alerts": [],
            "summary": {
                "total_metrics": len(SLAMetric),
                "compliant": 0,
                "warning": 0,
                "violation": 0,
                "no_data": 0
            }
        }

        for metric in SLAMetric:
            status = self.get_metric_status(metric)
            dashboard["metrics"][metric.value] = status

            # Update summary
            if status["status"] == "compliant":
                dashboard["summary"]["compliant"] += 1
            elif status["status"] == "violation":
                dashboard["summary"]["violation"] += 1
                dashboard["alerts"].append({
                    "metric": metric.value,
                    "severity": "high",
                    "message": f"{metric.value} SLA violation detected"
                })
            elif status["status"] == "no_data":
                dashboard["summary"]["no_data"] += 1
                dashboard["alerts"].append({
                    "metric": metric.value,
                    "severity": "medium",
                    "message": f"No data available for {metric.value}"
                })

        return dashboard

    def generate_sla_report(self, period: str = "monthly") -> Dict[str, Any]:
        """Generate comprehensive SLA report for specified period."""
        if period == "monthly":
            start_date = datetime.now() - timedelta(days=30)
        elif period == "quarterly":
            start_date = datetime.now() - timedelta(days=90)
        else:
            start_date = datetime.now() - timedelta(days=7)

        end_date = datetime.now()

        compliance_report = self.get_compliance_report(start_date, end_date)

        return {
            "report_type": "SLA Report",
            "period": period,
            "generated_at": datetime.now().isoformat(),
            "period_start": start_date.isoformat(),
            "period_end": end_date.isoformat(),
            "summary": {
                "total_violations": len(self.violations),
                "metrics_monitored": len(SLAMetric),
                "overall_compliance": self._calculate_overall_compliance()
            },
            "metrics": compliance_report["metrics"],
            "violations": self.get_violations(limit=50),
            "recommendations": self._generate_sla_recommendations()
        }

    def _generate_sla_recommendations(self) -> List[str]:
        """Generate recommendations based on SLA performance."""
        recommendations = []

        # Check recent violations
        recent_violations = [v for v in self.violations
                           if datetime.fromisoformat(v["timestamp"]) > datetime.now() - timedelta(days=7)]

        if recent_violations:
            violation_metrics = set(v["metric"] for v in recent_violations)

            if "availability" in violation_metrics:
                recommendations.append("Investigate system availability issues - consider scaling infrastructure")
            if "e2e_latency" in violation_metrics:
                recommendations.append("Optimize end-to-end latency - review system bottlenecks")
            if "alert_delivery" in violation_metrics:
                recommendations.append("Review alert delivery system - ensure notification reliability")
            if "position_accuracy" in violation_metrics:
                recommendations.append("Recalibrate sensor fusion algorithms")
            if "disaster_recovery" in violation_metrics:
                recommendations.append("Review and improve disaster recovery procedures")

        # General recommendations
        if len(recent_violations) > 5:
            recommendations.append("High number of violations - consider comprehensive system review")

        if not recommendations:
            recommendations.append("SLA performance is within acceptable ranges - maintain current practices")

        return recommendations


# Global SLA monitor service instance
sla_monitor_service = SLAMonitorService()
