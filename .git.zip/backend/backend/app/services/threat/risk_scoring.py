from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import numpy as np
import json


class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RiskFactor:
    """Individual risk factor with its contribution."""
    name: str
    value: float
    weight: float
    contribution: float
    source: str
    timestamp: datetime
    confidence: float


@dataclass
class RiskScore:
    """Comprehensive risk score with explainability."""
    overall_score: float
    risk_level: RiskLevel
    factors: List[RiskFactor]
    formula: str
    contributing_factors: Dict[str, float]
    last_observation_time: datetime
    geographic_bounds: Dict[str, Any]
    risk_reduction_path: Optional[List[Dict[str, Any]]]
    human_verifier: Optional[str]
    verifier_confidence: Optional[float]
    provenance: Dict[str, Any]
    timestamp: datetime


class RiskScoringEngine:
    """
    Risk scoring engine with explainability as per architecture spec.
    
    Formula: risk = severity × likelihood × exposure × data_confidence
    
    Final score must be published with:
    - Contributing factors
    - Last observation time
    - Geographic bounds
    - Risk reduction path
    - Human verifier confirmation
    
    Model score without explanation or provenance is not sufficient for operational use.
    """
    
    def __init__(self):
        self.factor_weights = {
            'severity': 0.3,
            'likelihood': 0.25,
            'exposure': 0.25,
            'data_confidence': 0.2
        }
        
        self.risk_thresholds = {
            RiskLevel.LOW: 0.25,
            RiskLevel.MEDIUM: 0.5,
            RiskLevel.HIGH: 0.75,
            RiskLevel.CRITICAL: 0.9
        }
        
        self.historical_scores: List[RiskScore] = []
        self.max_history = 1000
    
    def calculate_risk(
        self,
        severity: float,
        likelihood: float,
        exposure: float,
        data_confidence: float,
        location: Dict[str, float],
        threat_type: str,
        sources: List[str],
        provenance: Optional[Dict[str, Any]] = None
    ) -> RiskScore:
        """
        Calculate risk score using the formula: risk = severity × likelihood × exposure × data_confidence
        
        Args:
            severity: Severity of threat (0-1)
            likelihood: Probability of threat occurrence (0-1)
            exposure: Level of exposure to threat (0-1)
            data_confidence: Confidence in data quality (0-1)
            location: Geographic location {lat, lon, alt}
            threat_type: Type of threat
            sources: Data sources used
            provenance: Data provenance information
        """
        
        # Validate inputs
        severity = np.clip(severity, 0.0, 1.0)
        likelihood = np.clip(likelihood, 0.0, 1.0)
        exposure = np.clip(exposure, 0.0, 1.0)
        data_confidence = np.clip(data_confidence, 0.0, 1.0)
        
        # Calculate individual factors
        factors = [
            RiskFactor(
                name='severity',
                value=severity,
                weight=self.factor_weights['severity'],
                contribution=severity * self.factor_weights['severity'],
                source='threat_intelligence',
                timestamp=datetime.utcnow(),
                confidence=data_confidence
            ),
            RiskFactor(
                name='likelihood',
                value=likelihood,
                weight=self.factor_weights['likelihood'],
                contribution=likelihood * self.factor_weights['likelihood'],
                source='statistical_model',
                timestamp=datetime.utcnow(),
                confidence=data_confidence
            ),
            RiskFactor(
                name='exposure',
                value=exposure,
                weight=self.factor_weights['exposure'],
                contribution=exposure * self.factor_weights['exposure'],
                source='location_analysis',
                timestamp=datetime.utcnow(),
                confidence=data_confidence
            ),
            RiskFactor(
                name='data_confidence',
                value=data_confidence,
                weight=self.factor_weights['data_confidence'],
                contribution=data_confidence * self.factor_weights['data_confidence'],
                source='data_quality',
                timestamp=datetime.utcnow(),
                confidence=1.0  # Self-confidence
            )
        ]
        
        # Calculate overall risk score
        overall_score = severity * likelihood * exposure * data_confidence
        
        # Determine risk level
        risk_level = self._determine_risk_level(overall_score)
        
        # Build contributing factors dict
        contributing_factors = {
            'severity': severity,
            'likelihood': likelihood,
            'exposure': exposure,
            'data_confidence': data_confidence
        }
        
        # Calculate geographic bounds (1km radius around location)
        geographic_bounds = self._calculate_geographic_bounds(location)
        
        # Generate risk reduction path
        risk_reduction_path = self._generate_risk_reduction_path(
            location, risk_level, threat_type
        )
        
        # Build provenance
        if provenance is None:
            provenance = {
                'data_sources': sources,
                'model_version': '1.0',
                'calculation_method': 'weighted_multiplication',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        risk_score = RiskScore(
            overall_score=overall_score,
            risk_level=risk_level,
            factors=factors,
            formula="risk = severity × likelihood × exposure × data_confidence",
            contributing_factors=contributing_factors,
            last_observation_time=datetime.utcnow(),
            geographic_bounds=geographic_bounds,
            risk_reduction_path=risk_reduction_path,
            human_verifier=None,  # Requires human verification
            verifier_confidence=None,
            provenance=provenance,
            timestamp=datetime.utcnow()
        )
        
        # Store in history
        self._store_risk_score(risk_score)
        
        return risk_score
    
    def _determine_risk_level(self, score: float) -> RiskLevel:
        """Determine risk level based on score."""
        if score >= self.risk_thresholds[RiskLevel.CRITICAL]:
            return RiskLevel.CRITICAL
        elif score >= self.risk_thresholds[RiskLevel.HIGH]:
            return RiskLevel.HIGH
        elif score >= self.risk_thresholds[RiskLevel.MEDIUM]:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW
    
    def _calculate_geographic_bounds(self, location: Dict[str, float]) -> Dict[str, Any]:
        """Calculate geographic bounds around location (1km radius)."""
        lat = location.get('lat', 0)
        lon = location.get('lon', 0)
        alt = location.get('alt', 0)
        
        # Approximate 1km in degrees (simplified)
        lat_offset = 0.009  # ~1km at equator
        lon_offset = 0.009  # ~1km at equator
        
        return {
            'center': {'lat': lat, 'lon': lon, 'alt': alt},
            'bounds': {
                'min_lat': lat - lat_offset,
                'max_lat': lat + lat_offset,
                'min_lon': lon - lon_offset,
                'max_lon': lon + lon_offset,
                'min_alt': alt - 100,
                'max_alt': alt + 100
            },
            'radius_km': 1.0,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def _generate_risk_reduction_path(
        self,
        location: Dict[str, float],
        risk_level: RiskLevel,
        threat_type: str
    ) -> List[Dict[str, Any]]:
        """Generate risk reduction path based on risk level and threat type."""
        path = []
        
        if risk_level in [RiskLevel.HIGH, RiskLevel.CRITICAL]:
            # Immediate actions
            path.append({
                'action': 'evacuate',
                'priority': 'immediate',
                'destination': self._find_safe_location(location),
                'estimated_time_minutes': 5,
                'reason': f'{risk_level.value} risk from {threat_type}'
            })
        
        if risk_level == RiskLevel.CRITICAL:
            # Additional critical actions
            path.append({
                'action': 'establish_perimeter',
                'priority': 'immediate',
                'radius_m': 500,
                'reason': 'Critical threat containment'
            })
            path.append({
                'action': 'alert_authorities',
                'priority': 'immediate',
                'reason': 'Critical threat notification'
            })
        
        if risk_level == RiskLevel.HIGH:
            path.append({
                'action': 'increase_surveillance',
                'priority': 'high',
                'duration_minutes': 30,
                'reason': 'High threat monitoring'
            })
        
        if risk_level == RiskLevel.MEDIUM:
            path.append({
                'action': 'monitor_situation',
                'priority': 'medium',
                'duration_minutes': 15,
                'reason': 'Medium threat observation'
            })
        
        if risk_level == RiskLevel.LOW:
            path.append({
                'action': 'continue_normal_operations',
                'priority': 'low',
                'reason': 'Low risk level'
            })
        
        return path
    
    def _find_safe_location(self, current_location: Dict[str, float]) -> Dict[str, float]:
        """Find nearest safe location (simplified)."""
        # In production, this would query a database of safe locations
        # For now, return a location 2km away
        lat = current_location.get('lat', 0)
        lon = current_location.get('lon', 0)
        
        return {
            'lat': lat + 0.018,  # ~2km
            'lon': lon + 0.018,
            'alt': current_location.get('alt', 0)
        }
    
    def verify_risk_score(
        self,
        risk_score: RiskScore,
        verifier: str,
        verifier_confidence: float,
        override_level: Optional[RiskLevel] = None
    ) -> RiskScore:
        """
        Human verification of risk score.
        
        Model score without human verification is not sufficient for operational use.
        """
        risk_score.human_verifier = verifier
        risk_score.verifier_confidence = verifier_confidence
        
        if override_level is not None:
            risk_score.risk_level = override_level
            # Recalculate overall score based on override
            if override_level == RiskLevel.CRITICAL:
                risk_score.overall_score = 0.95
            elif override_level == RiskLevel.HIGH:
                risk_score.overall_score = 0.8
            elif override_level == RiskLevel.MEDIUM:
                risk_score.overall_score = 0.6
            else:
                risk_score.overall_score = 0.3
        
        # Add verification to provenance
        risk_score.provenance['human_verification'] = {
            'verifier': verifier,
            'confidence': verifier_confidence,
            'timestamp': datetime.utcnow().isoformat(),
            'override_level': override_level.value if override_level else None
        }
        
        return risk_score
    
    def _store_risk_score(self, risk_score: RiskScore):
        """Store risk score in history."""
        self.historical_scores.append(risk_score)
        
        # Maintain max history size
        if len(self.historical_scores) > self.max_history:
            self.historical_scores.pop(0)
    
    def get_risk_trend(self, location: Dict[str, float], hours: int = 24) -> Dict[str, Any]:
        """Get risk trend for a location over time period."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        recent_scores = [
            score for score in self.historical_scores
            if score.timestamp >= cutoff_time
        ]
        
        if not recent_scores:
            return {
                'trend': 'no_data',
                'scores': [],
                'average_score': 0.0,
                'max_score': 0.0,
                'min_score': 0.0
            }
        
        scores = [score.overall_score for score in recent_scores]
        
        # Calculate trend
        if len(scores) >= 2:
            if scores[-1] > scores[0]:
                trend = 'increasing'
            elif scores[-1] < scores[0]:
                trend = 'decreasing'
            else:
                trend = 'stable'
        else:
            trend = 'insufficient_data'
        
        return {
            'trend': trend,
            'scores': scores,
            'average_score': np.mean(scores),
            'max_score': np.max(scores),
            'min_score': np.min(scores),
            'score_count': len(scores),
            'time_period_hours': hours
        }
    
    def get_risk_explanation(self, risk_score: RiskScore) -> str:
        """Generate human-readable explanation of risk score."""
        explanation = f"""
Risk Assessment Report
======================
Overall Risk Score: {risk_score.overall_score:.3f}
Risk Level: {risk_score.risk_level.value}
Timestamp: {risk_score.timestamp.isoformat()}

Formula: {risk_score.formula}

Contributing Factors:
"""
        
        for factor in risk_score.factors:
            explanation += f"- {factor.name}: {factor.value:.3f} (weight: {factor.weight:.2f}, contribution: {factor.contribution:.3f})\n"
        
        explanation += f"""
Geographic Context:
- Center: {risk_score.geographic_bounds['center']}
- Bounds: {risk_score.geographic_bounds['bounds']}
- Radius: {risk_score.geographic_bounds['radius_km']} km

Risk Reduction Path:
"""
        
        for i, step in enumerate(risk_score.risk_reduction_path, 1):
            explanation += f"{i}. {step['action']} (Priority: {step['priority']}) - {step['reason']}\n"
        
        if risk_score.human_verifier:
            explanation += f"""
Human Verification:
- Verifier: {risk_score.human_verifier}
- Confidence: {risk_score.verifier_confidence:.2f}
"""
        
        explanation += f"""
Data Provenance:
{json.dumps(risk_score.provenance, indent=2)}
"""
        
        return explanation