import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime
import threading
import time
from app.ml.threat_detector import ThreatDetector


class ThreatAnalysisService:
    """Service for AI-powered threat analysis and risk assessment."""
    
    def __init__(self):
        self.threat_detector = ThreatDetector()
        self.is_running = False
        self._thread: Optional[threading.Thread] = None
        self.update_interval = 0.2  # 5Hz update rate
        self.callbacks = []
        self.current_risk_map: Dict[str, Any] = {}
        self.threat_history: List[Dict[str, Any]] = []
    
    def start(self):
        """Start the threat analysis service."""
        if self.is_running:
            return
        
        # Load ML model
        if not self.threat_detector.load_model():
            print("Failed to load threat detection model")
            return
        
        self.is_running = True
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()
        print("Threat analysis service started")
    
    def stop(self):
        """Stop the threat analysis service."""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2)
        print("Threat analysis service stopped")
    
    def add_callback(self, callback):
        """Add a callback for threat updates."""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback):
        """Remove a callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def _update_loop(self):
        """Main update loop for threat analysis."""
        while self.is_running:
            try:
                # Update risk map
                self._update_risk_map()
                
                # Sleep for update interval
                time.sleep(self.update_interval)
            except Exception as e:
                print(f"Error in threat analysis update loop: {e}")
                time.sleep(1)
    
    def _update_risk_map(self):
        """Update the real-time risk map."""
        # This would normally process video streams or images
        # For now, we'll maintain the current state
        self.current_risk_map = {
            "timestamp": datetime.now().isoformat(),
            "update_rate": 5.0,  # 5Hz
            "regions": self._generate_risk_regions()
        }
    
    def _generate_risk_regions(self) -> List[Dict[str, Any]]:
        """Generate risk regions for the map."""
        # In production, this would be based on actual threat data
        # For now, return empty regions
        return []
    
    def analyze_image(self, image: np.ndarray, location: Dict[str, float]) -> Dict[str, Any]:
        """Analyze an image for threats."""
        return self.threat_detector.analyze_scene(image, location)
    
    def detect_movement(self, frame1: np.ndarray, frame2: np.ndarray) -> List[Dict[str, Any]]:
        """Detect movement between two frames."""
        return self.threat_detector.detect_movement(frame1, frame2)
    
    def identify_blind_spots(self, image: np.ndarray, 
                            detected_objects: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Identify blind spots in the scene."""
        # Convert detected objects to DetectedObject format
        from app.ml.threat_detector import DetectedObject
        
        obj_list = [
            DetectedObject(
                class_id=obj.get("class_id", 0),
                class_name=obj.get("class_name", "unknown"),
                confidence=obj.get("confidence", 0.0),
                bbox=obj.get("bbox", [0, 0, 0, 0]),
                center=obj.get("center", (0, 0)),
                timestamp=datetime.now()
            )
            for obj in detected_objects
        ]
        
        return self.threat_detector.identify_blind_spots(image, obj_list)
    
    def get_risk_map(self) -> Dict[str, Any]:
        """Get the current risk map."""
        return self.current_risk_map
    
    def get_threat_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get threat history."""
        return self.threat_history[-limit:]
    
    def calculate_risk_score(self, location: Dict[str, float], 
                           time_of_day: str = "day") -> Dict[str, Any]:
        """Calculate risk score for a specific location."""
        # This would use historical data, location features, etc.
        # For MVP, return a basic implementation
        base_risk = 0.3
        
        # Adjust based on time of day
        time_multiplier = {
            "day": 1.0,
            "night": 1.5,
            "evening": 1.2
        }
        
        risk_score = base_risk * time_multiplier.get(time_of_day, 1.0)
        
        return {
            "location": location,
            "risk_score": min(risk_score, 1.0),
            "risk_level": "low" if risk_score < 0.4 else "medium" if risk_score < 0.7 else "high",
            "factors": ["time_of_day", "location_type"],
            "timestamp": datetime.now().isoformat()
        }
    
    def generate_alert(self, threat: Dict[str, Any]) -> Dict[str, Any]:
        """Generate an alert for a detected threat."""
        severity = threat.get("severity", "medium")
        
        alert = {
            "alert_id": f"alert_{datetime.now().timestamp()}",
            "threat_id": threat.get("id"),
            "severity": severity,
            "threat_type": threat.get("threat_type", "unknown"),
            "location": threat.get("location", {}),
            "timestamp": datetime.now().isoformat(),
            "message": f"Threat detected: {threat.get('threat_type', 'unknown')} with {severity} severity",
            "action_required": severity in ["high", "critical"]
        }
        
        # Add to history
        self.threat_history.append(alert)
        
        # Keep history manageable
        if len(self.threat_history) > 1000:
            self.threat_history = self.threat_history[-1000:]
        
        return alert
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get threat analysis statistics."""
        if not self.threat_history:
            return {
                "total_threats": 0,
                "by_severity": {},
                "by_type": {},
                "recent_activity": []
            }
        
        severity_counts = {}
        type_counts = {}
        
        for threat in self.threat_history:
            severity = threat.get("severity", "unknown")
            threat_type = threat.get("threat_type", "unknown")
            
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            type_counts[threat_type] = type_counts.get(threat_type, 0) + 1
        
        return {
            "total_threats": len(self.threat_history),
            "by_severity": severity_counts,
            "by_type": type_counts,
            "recent_activity": self.threat_history[-10:]
        }


# Global threat analysis service instance
threat_analysis_service = ThreatAnalysisService()
