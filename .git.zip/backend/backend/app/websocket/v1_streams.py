from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
import json
import asyncio
import uuid
from fastapi import WebSocket, WebSocketDisconnect
from app.services.geolocation.ekf_fusion import fusion_engine
from app.services.threat.risk_scoring import risk_scoring_engine


@dataclass
class StreamMessage:
    """Standardized message for WebSocket streams."""
    message_id: str
    sequence: int
    timestamp: str
    topic: str
    payload: Dict[str, Any]
    metadata: Dict[str, Any]


class StreamConnection:
    """Manages a single WebSocket connection."""
    
    def __init__(self, websocket: WebSocket, client_id: str):
        self.websocket = websocket
        self.client_id = client_id
        self.sequence = 0
        self.topics: set = set()
        self.last_heartbeat = datetime.utcnow()
        self.connected_at = datetime.utcnow()
    
    async def send_message(self, message: StreamMessage):
        """Send a message to this connection."""
        try:
            await self.websocket.send_json(message.__dict__)
            self.sequence += 1
        except Exception as e:
            print(f"Error sending message to {self.client_id}: {e}")
            raise
    
    async def send_heartbeat(self):
        """Send heartbeat message."""
        heartbeat = StreamMessage(
            message_id=str(uuid.uuid4()),
            sequence=self.sequence,
            timestamp=datetime.utcnow().isoformat(),
            topic="heartbeat",
            payload={"status": "alive"},
            metadata={"client_id": self.client_id}
        )
        await self.send_message(heartbeat)
        self.last_heartbeat = datetime.utcnow()
    
    def update_heartbeat(self):
        """Update last heartbeat time."""
        self.last_heartbeat = datetime.utcnow()
    
    def is_alive(self, timeout_seconds: float = 30.0) -> bool:
        """Check if connection is alive based on heartbeat."""
        age = (datetime.utcnow() - self.last_heartbeat).total_seconds()
        return age < timeout_seconds


class StreamManager:
    """
    Manages WebSocket streams as per architecture spec.
    
    Channels:
    - wss://gateway.example/v1/stream/telemetry
    - wss://gateway.example/v1/stream/risk
    - wss://gateway.example/v1/stream/alerts
    
    All channels must have:
    - Authentication
    - Topic-based authorization
    - Heartbeat
    - Sequence numbers
    - Reconnect with backoff
    """
    
    def __init__(self):
        self.connections: Dict[str, StreamConnection] = {}
        self.topic_subscribers: Dict[str, set] = {
            "telemetry": set(),
            "risk": set(),
            "alerts": set()
        }
        self.heartbeat_interval = 15.0  # seconds
        self.heartbeat_task: Optional[asyncio.Task] = None
        self.message_history: List[StreamMessage] = []
        self.max_history = 1000
    
    async def connect(self, websocket: WebSocket, client_id: str, topics: List[str]):
        """Accept and register a new WebSocket connection."""
        await websocket.accept()
        
        connection = StreamConnection(websocket, client_id)
        self.connections[client_id] = connection
        
        # Subscribe to topics
        for topic in topics:
            if topic in self.topic_subscribers:
                self.topic_subscribers[topic].add(client_id)
                connection.topics.add(topic)
        
        # Send initial connection message
        welcome_message = StreamMessage(
            message_id=str(uuid.uuid4()),
            sequence=0,
            timestamp=datetime.utcnow().isoformat(),
            topic="connection",
            payload={
                "status": "connected",
                "topics": list(connection.topics),
                "heartbeat_interval": self.heartbeat_interval
            },
            metadata={"client_id": client_id}
        )
        await connection.send_message(welcome_message)
        
        # Start heartbeat if not already running
        if self.heartbeat_task is None:
            self.heartbeat_task = asyncio.create_task(self._heartbeat_loop())
    
    def disconnect(self, client_id: str):
        """Disconnect a client."""
        if client_id in self.connections:
            connection = self.connections[client_id]
            
            # Unsubscribe from topics
            for topic in connection.topics:
                if topic in self.topic_subscribers:
                    self.topic_subscribers[topic].discard(client_id)
            
            del self.connections[client_id]
    
    async def broadcast_to_topic(self, topic: str, payload: Dict[str, Any]):
        """Broadcast a message to all subscribers of a topic."""
        if topic not in self.topic_subscribers:
            return
        
        message = StreamMessage(
            message_id=str(uuid.uuid4()),
            sequence=0,  # Will be incremented per connection
            timestamp=datetime.utcnow().isoformat(),
            topic=topic,
            payload=payload,
            metadata={"topic": topic}
        )
        
        # Store in history
        self._store_message(message)
        
        # Send to all subscribers
        for client_id in self.topic_subscribers[topic].copy():
            if client_id in self.connections:
                connection = self.connections[client_id]
                try:
                    message.sequence = connection.sequence
                    await connection.send_message(message)
                except Exception as e:
                    print(f"Error broadcasting to {client_id}: {e}")
                    self.disconnect(client_id)
    
    async def _heartbeat_loop(self):
        """Send periodic heartbeats to all connections."""
        while True:
            try:
                await asyncio.sleep(self.heartbeat_interval)
                
                # Check for dead connections
                dead_clients = []
                for client_id, connection in self.connections.items():
                    if not connection.is_alive():
                        dead_clients.append(client_id)
                    else:
                        try:
                            await connection.send_heartbeat()
                        except Exception as e:
                            print(f"Heartbeat failed for {client_id}: {e}")
                            dead_clients.append(client_id)
                
                # Disconnect dead clients
                for client_id in dead_clients:
                    self.disconnect(client_id)
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Heartbeat loop error: {e}")
    
    def _store_message(self, message: StreamMessage):
        """Store message in history."""
        self.message_history.append(message)
        
        # Maintain max history size
        if len(self.message_history) > self.max_history:
            self.message_history.pop(0)
    
    def get_message_history(self, topic: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get message history, optionally filtered by topic."""
        messages = self.message_history
        
        if topic:
            messages = [m for m in messages if m.topic == topic]
        
        messages = messages[-limit:]
        
        return [m.__dict__ for m in messages]
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get connection statistics."""
        return {
            "total_connections": len(self.connections),
            "topic_subscribers": {
                topic: len(subscribers)
                for topic, subscribers in self.topic_subscribers.items()
            },
            "heartbeat_interval": self.heartbeat_interval,
            "message_history_size": len(self.message_history)
        }
    
    async def shutdown(self):
        """Shutdown the stream manager."""
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
            try:
                await self.heartbeat_task
            except asyncio.CancelledError:
                pass
        
        # Close all connections
        for client_id in list(self.connections.keys()):
            try:
                await self.connections[client_id].websocket.close()
            except:
                pass
        
        self.connections.clear()


class TelemetryStream:
    """Telemetry stream handler."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.update_frequency = 5.0  # 5 Hz as per architecture
        self.running = False
        self.task: Optional[asyncio.Task] = None
    
    async def start(self):
        """Start telemetry stream."""
        if self.running:
            return
        
        self.running = True
        self.task = asyncio.create_task(self._telemetry_loop())
    
    async def stop(self):
        """Stop telemetry stream."""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
    
    async def _telemetry_loop(self):
        """Main telemetry loop."""
        while self.running:
            try:
                # Get latest fused position
                fused_pos = fusion_engine.get_fused_position()
                
                # Build telemetry payload
                telemetry_payload = {
                    "position": {
                        "latitude": fused_pos.latitude,
                        "longitude": fused_pos.longitude,
                        "altitude": fused_pos.altitude
                    },
                    "velocity": {
                        "north": fused_pos.velocity_north,
                        "east": fused_pos.velocity_east,
                        "down": fused_pos.velocity_down
                    },
                    "orientation": {
                        "heading": fused_pos.heading,
                        "pitch": fused_pos.pitch,
                        "roll": fused_pos.roll
                    },
                    "quality": {
                        "confidence": fused_pos.confidence,
                        "quality_score": fused_pos.quality_score,
                        "is_dead_reckoning": fused_pos.is_dead_reckoning
                    },
                    "sources": fused_pos.source_contributions,
                    "timestamp": fused_pos.timestamp.isoformat()
                }
                
                # Broadcast to telemetry topic
                await self.stream_manager.broadcast_to_topic("telemetry", telemetry_payload)
                
                # Wait for next update
                await asyncio.sleep(1.0 / self.update_frequency)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Telemetry loop error: {e}")
                await asyncio.sleep(1.0)


class RiskStream:
    """Risk stream handler."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.update_frequency = 1.0  # 1 Hz for risk updates
        self.running = False
        self.task: Optional[asyncio.Task] = None
    
    async def start(self):
        """Start risk stream."""
        if self.running:
            return
        
        self.running = True
        self.task = asyncio.create_task(self._risk_loop())
    
    async def stop(self):
        """Stop risk stream."""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
    
    async def _risk_loop(self):
        """Main risk loop."""
        while self.running:
            try:
                # Get latest risk scores from history
                risk_history = risk_scoring_engine.historical_scores
                
                if risk_history:
                    latest_risk = risk_history[-1]
                    
                    # Build risk payload
                    risk_payload = {
                        "overall_score": latest_risk.overall_score,
                        "risk_level": latest_risk.risk_level.value,
                        "factors": [
                            {
                                "name": f.name,
                                "value": f.value,
                                "contribution": f.contribution
                            }
                            for f in latest_risk.factors
                        ],
                        "geographic_bounds": latest_risk.geographic_bounds,
                        "timestamp": latest_risk.timestamp.isoformat(),
                        "verified": latest_risk.human_verifier is not None
                    }
                    
                    # Broadcast to risk topic
                    await self.stream_manager.broadcast_to_topic("risk", risk_payload)
                
                # Wait for next update
                await asyncio.sleep(1.0 / self.update_frequency)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Risk loop error: {e}")
                await asyncio.sleep(1.0)


class AlertStream:
    """Alert stream handler."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.running = False
        self.task: Optional[asyncio.Task] = None
        self.alert_queue: asyncio.Queue = asyncio.Queue()
    
    async def start(self):
        """Start alert stream."""
        if self.running:
            return
        
        self.running = True
        self.task = asyncio.create_task(self._alert_loop())
    
    async def stop(self):
        """Stop alert stream."""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
    
    async def publish_alert(self, alert: Dict[str, Any]):
        """Publish an alert to the stream."""
        await self.alert_queue.put(alert)
    
    async def _alert_loop(self):
        """Main alert loop."""
        while self.running:
            try:
                # Wait for alert (with timeout)
                try:
                    alert = await asyncio.wait_for(self.alert_queue.get(), timeout=1.0)
                    
                    # Build alert payload
                    alert_payload = {
                        "alert_id": alert.get("id", str(uuid.uuid4())),
                        "severity": alert.get("severity", "medium"),
                        "type": alert.get("type", "general"),
                        "message": alert.get("message", ""),
                        "location": alert.get("location", {}),
                        "timestamp": datetime.utcnow().isoformat(),
                        "metadata": alert.get("metadata", {})
                    }
                    
                    # Broadcast to alerts topic
                    await self.stream_manager.broadcast_to_topic("alerts", alert_payload)
                    
                except asyncio.TimeoutError:
                    # No alert, continue
                    pass
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Alert loop error: {e}")
                await asyncio.sleep(1.0)


# Global instances
stream_manager = StreamManager()
telemetry_stream = TelemetryStream(stream_manager)
risk_stream = RiskStream(stream_manager)
alert_stream = AlertStream(stream_manager)