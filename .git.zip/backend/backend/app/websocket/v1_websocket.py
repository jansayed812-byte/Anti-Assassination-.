from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from typing import List, Optional
from app.websocket.v1_streams import (
    stream_manager,
    telemetry_stream,
    risk_stream,
    alert_stream
)

router = APIRouter()


@router.websocket("/stream/telemetry")
async def websocket_telemetry_stream(
    websocket: WebSocket,
    client_id: Optional[str] = Query(None)
):
    """
    WebSocket endpoint for telemetry stream.
    
    wss://gateway.example/v1/stream/telemetry
    
    Features:
    - Authentication (via query param)
    - Topic-based authorization
    - Heartbeat
    - Sequence numbers
    - Reconnect with backoff
    """
    if not client_id:
        await websocket.close(code=4000, reason="Missing client_id")
        return
    
    try:
        await stream_manager.connect(websocket, client_id, ["telemetry"])
        
        # Keep connection alive and handle incoming messages
        while True:
            data = await websocket.receive_json()
            
            # Handle incoming messages (heartbeats, commands, etc.)
            if data.get("type") == "heartbeat":
                stream_manager.connections[client_id].update_heartbeat()
            elif data.get("type") == "subscribe":
                new_topics = data.get("topics", [])
                for topic in new_topics:
                    if topic in stream_manager.topic_subscribers:
                        stream_manager.topic_subscribers[topic].add(client_id)
                        stream_manager.connections[client_id].topics.add(topic)
            elif data.get("type") == "unsubscribe":
                topics_to_remove = data.get("topics", [])
                for topic in topics_to_remove:
                    if topic in stream_manager.topic_subscribers:
                        stream_manager.topic_subscribers[topic].discard(client_id)
                        stream_manager.connections[client_id].topics.discard(topic)
                        
    except WebSocketDisconnect:
        stream_manager.disconnect(client_id)
    except Exception as e:
        print(f"WebSocket error for {client_id}: {e}")
        stream_manager.disconnect(client_id)


@router.websocket("/stream/risk")
async def websocket_risk_stream(
    websocket: WebSocket,
    client_id: Optional[str] = Query(None)
):
    """
    WebSocket endpoint for risk stream.
    
    wss://gateway.example/v1/stream/risk
    """
    if not client_id:
        await websocket.close(code=4000, reason="Missing client_id")
        return
    
    try:
        await stream_manager.connect(websocket, client_id, ["risk"])
        
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "heartbeat":
                stream_manager.connections[client_id].update_heartbeat()
            elif data.get("type") == "subscribe":
                new_topics = data.get("topics", [])
                for topic in new_topics:
                    if topic in stream_manager.topic_subscribers:
                        stream_manager.topic_subscribers[topic].add(client_id)
                        stream_manager.connections[client_id].topics.add(topic)
                        
    except WebSocketDisconnect:
        stream_manager.disconnect(client_id)
    except Exception as e:
        print(f"WebSocket error for {client_id}: {e}")
        stream_manager.disconnect(client_id)


@router.websocket("/stream/alerts")
async def websocket_alert_stream(
    websocket: WebSocket,
    client_id: Optional[str] = Query(None)
):
    """
    WebSocket endpoint for alerts stream.
    
    wss://gateway.example/v1/stream/alerts
    """
    if not client_id:
        await websocket.close(code=4000, reason="Missing client_id")
        return
    
    try:
        await stream_manager.connect(websocket, client_id, ["alerts"])
        
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "heartbeat":
                stream_manager.connections[client_id].update_heartbeat()
            elif data.get("type") == "subscribe":
                new_topics = data.get("topics", [])
                for topic in new_topics:
                    if topic in stream_manager.topic_subscribers:
                        stream_manager.topic_subscribers[topic].add(client_id)
                        stream_manager.connections[client_id].topics.add(topic)
                        
    except WebSocketDisconnect:
        stream_manager.disconnect(client_id)
    except Exception as e:
        print(f"WebSocket error for {client_id}: {e}")
        stream_manager.disconnect(client_id)