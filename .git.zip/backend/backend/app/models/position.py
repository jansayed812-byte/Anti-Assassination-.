from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from ..core.database import Base


class Position(Base):
    __tablename__ = "positions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    device_id = Column(String, index=True)
    
    # Position data
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    altitude = Column(Float, default=0.0)
    accuracy = Column(Float, default=0.0)
    
    # Movement data
    speed = Column(Float, default=0.0)
    heading = Column(Float, default=0.0)
    
    # Source information
    source = Column(String)  # GPS, WIFI, BLUETOOTH, CELLULAR, INS
    satellites = Column(Integer, default=0)
    
    # Metadata
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    additional_data = Column(JSON, default={})
    
    user = relationship("User", backref="positions")
