from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON, Float
from sqlalchemy.sql import func
from ..core.database import Base


class Device(Base):
    __tablename__ = "devices"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String, unique=True, index=True, nullable=False)
    device_type = Column(String, nullable=False)  # GPS, DRONE, IOT, BEACON
    name = Column(String)
    model = Column(String)
    
    # Status
    is_active = Column(Boolean, default=True)
    status = Column(String, default="offline")  # online, offline, error
    last_seen = Column(DateTime(timezone=True))
    battery_level = Column(Float, default=100.0)
    
    # Configuration
    configuration = Column(JSON, default={})
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
