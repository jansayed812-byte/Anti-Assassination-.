import cv2
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from ultralytics import YOLO
import torch


@dataclass
class DetectedObject:
    class_id: int
    class_name: str
    confidence: float
    bbox: List[int]  # [x1, y1, x2, y2]
    center: Tuple[float, float]  # (x, y)
    timestamp: datetime


class ThreatDetector:
    """AI-powered threat detection using YOLOv8."""
    
    def __init__(self, model_path: str = "yolov8n.pt"):
        self.model = None
        self.model_path = model_path
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.threat_classes = {
            "person": "suspicious_person",
            "car": "suspicious_vehicle",
            "truck": "suspicious_vehicle",
            "bus": "suspicious_vehicle",
            "motorcycle": "suspicious_vehicle",
            "bicycle": "suspicious_vehicle",
            "knife": "weapon",
            "scissors": "weapon",
            "cell phone": "communication_device"
        }
        self.severity_mapping = {
            "weapon": "critical",
            "suspicious_person": "high",
            "suspicious_vehicle": "medium",
            "communication_device": "low"
        }
    
    def load_model(self) -> bool:
        """Load the YOLOv8 model."""
        try:
            self.model = YOLO(self.model_path)
            print(f"Loaded YOLOv8 model from {self.model_path} on {self.device}")
            return True
        except Exception as e:
            print(f"Error loading model: {e}")
            return False
    
    def detect_objects(self, image: np.ndarray, conf_threshold: float = 0.5) -> List[DetectedObject]:
        """Detect objects in an image using YOLOv8."""
        if self.model is None:
            print("Model not loaded")
            return []
        
        try:
            results = self.model(image, conf=conf_threshold, device=self.device)
            detected_objects = []
            
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    class_id = int(box.cls[0])
                    class_name = result.names[class_id]
                    confidence = float(box.conf[0])
                    bbox = box.xyxy[0].tolist()
                    bbox = [int(x) for x in bbox]
                    
                    # Calculate center point
                    center_x = (bbox[0] + bbox[2]) / 2
                    center_y = (bbox[1] + bbox[3]) / 2
                    
                    detected_objects.append(DetectedObject(
                        class_id=class_id,
                        class_name=class_name,
                        confidence=confidence,
                        bbox=bbox,
                        center=(center_x, center_y),
                        timestamp=datetime.now()
                    ))
            
            return detected_objects
        
        except Exception as e:
            print(f"Error detecting objects: {e}")
            return []
    
    def classify_threats(self, detected_objects: List[DetectedObject], 
                        location: Dict[str, float]) -> List[Dict[str, Any]]:
        """Classify detected objects as threats."""
        threats = []
        
        for obj in detected_objects:
            threat_type = self.threat_classes.get(obj.class_name, "unknown")
            severity = self.severity_mapping.get(threat_type, "low")
            
            # Create threat ID
            threat_id = f"{threat_type}_{obj.timestamp.timestamp()}_{obj.class_id}"
            
            threat = {
                "id": threat_id,
                "threat_type": threat_type,
                "severity": severity,
                "confidence": obj.confidence,
                "location": location,
                "bbox": obj.bbox,
                "timestamp": obj.timestamp,
                "description": f"Detected {obj.class_name} with {obj.confidence:.2f} confidence"
            }
            
            threats.append(threat)
        
        return threats
    
    def analyze_scene(self, image: np.ndarray, location: Dict[str, float]) -> Dict[str, Any]:
        """Analyze a scene and return threat assessment."""
        detected_objects = self.detect_objects(image)
        threats = self.classify_threats(detected_objects, location)
        
        # Calculate overall risk level
        risk_level = self._calculate_risk_level_dict(threats)
        
        return {
            "detected_objects": len(detected_objects),
            "threats": [
                {
                    "id": t["id"],
                    "threat_type": t["threat_type"],
                    "severity": t["severity"],
                    "confidence": t["confidence"],
                    "location": t["location"],
                    "bbox": t["bbox"],
                    "timestamp": t["timestamp"].isoformat(),
                    "description": t["description"]
                }
                for t in threats
            ],
            "risk_level": risk_level,
            "analysis_timestamp": datetime.now().isoformat()
        }
    
    def _calculate_risk_level_dict(self, threats: List[Dict[str, Any]]) -> str:
        """Calculate overall risk level based on detected threats."""
        if not threats:
            return "none"
        
        severity_weights = {
            "critical": 4,
            "high": 3,
            "medium": 2,
            "low": 1
        }
        
        total_weight = sum(severity_weights.get(t["severity"], 1) for t in threats)
        
        if total_weight >= 8:
            return "critical"
        elif total_weight >= 5:
            return "high"
        elif total_weight >= 3:
            return "medium"
        else:
            return "low"
    
    def detect_movement(self, frame1: np.ndarray, frame2: np.ndarray, 
                       threshold: int = 25) -> List[Dict[str, Any]]:
        """Detect movement between two frames."""
        try:
            # Convert to grayscale
            gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
            
            # Calculate absolute difference
            diff = cv2.absdiff(gray1, gray2)
            
            # Apply threshold
            _, thresh = cv2.threshold(diff, threshold, 255, cv2.THRESH_BINARY)
            
            # Find contours
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            movements = []
            for contour in contours:
                if cv2.contourArea(contour) > 100:  # Filter small movements
                    x, y, w, h = cv2.boundingRect(contour)
                    movements.append({
                        "bbox": [x, y, x + w, y + h],
                        "area": cv2.contourArea(contour),
                        "center": (x + w / 2, y + h / 2)
                    })
            
            return movements
        
        except Exception as e:
            print(f"Error detecting movement: {e}")
            return []
    
    def identify_blind_spots(self, image: np.ndarray, 
                           detected_objects: List[DetectedObject]) -> List[Dict[str, Any]]:
        """Identify potential blind spots in the scene."""
        height, width = image.shape[:2]
        
        # Create a mask of covered areas by detected objects
        mask = np.zeros((height, width), dtype=np.uint8)
        
        for obj in detected_objects:
            x1, y1, x2, y2 = obj.bbox
            mask[y1:y2, x1:x2] = 255
        
        # Find areas without coverage (blind spots)
        _, binary_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        blind_spots = []
        for contour in contours:
            if cv2.contourArea(contour) > 1000:  # Minimum area for blind spot
                x, y, w, h = cv2.boundingRect(contour)
                blind_spots.append({
                    "bbox": [x, y, x + w, y + h],
                    "area": cv2.contourArea(contour),
                    "center": (x + w / 2, y + h / 2),
                    "percentage": (cv2.contourArea(contour) / (width * height)) * 100
                })
        
        return blind_spots
    
    def annotate_image(self, image: np.ndarray, threats: List[Dict[str, Any]]) -> np.ndarray:
        """Annotate image with detected threats."""
        annotated = image.copy()
        
        for threat in threats:
            x1, y1, x2, y2 = threat["bbox"]
            
            # Choose color based on severity
            color_map = {
                "critical": (0, 0, 255),    # Red
                "high": (0, 165, 255),      # Orange
                "medium": (0, 255, 255),    # Yellow
                "low": (0, 255, 0)          # Green
            }
            color = color_map.get(threat["severity"], (255, 255, 255))
            
            # Draw bounding box
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            
            # Draw label
            label = f"{threat['threat_type']}: {threat['confidence']:.2f}"
            cv2.putText(annotated, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return annotated
    
    def simulate_detection(self, image: np.ndarray, location: Dict[str, float]) -> Dict[str, Any]:
        """Simulate threat detection for testing."""
        height, width = image.shape[:2]
        
        # Simulate detected objects
        simulated_objects = [
            DetectedObject(
                class_id=0,
                class_name="person",
                confidence=0.85,
                bbox=[width // 4, height // 4, width // 2, height // 2],
                center=(width * 3 // 8, height * 3 // 8),
                timestamp=datetime.now()
            )
        ]
        
        threats = self.classify_threats(simulated_objects, location)
        
        return {
            "detected_objects": len(simulated_objects),
            "threats": threats,
            "risk_level": self._calculate_risk_level_dict(threats),
            "analysis_timestamp": datetime.now().isoformat(),
            "simulated": True
        }
