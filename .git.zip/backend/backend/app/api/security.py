from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from app.services.security.routing_service import routing_service
from app.services.security.escort_service import escort_planning_service

router = APIRouter()


class RouteRequest(BaseModel):
    start_location: Dict[str, float]
    end_location: Dict[str, float]
    constraints: List[str] = []


class TeamMember(BaseModel):
    id: str
    name: str
    role: str
    position: Dict[str, float]
    status: str = "available"


class EscortPlanRequest(BaseModel):
    team_id: str
    start_location: Dict[str, float]
    end_location: Dict[str, float]
    constraints: List[str] = []


@router.post("/route")
async def calculate_route(request: RouteRequest):
    """Calculate optimal security route using A* algorithm."""
    try:
        # Generate sample network if not exists
        if not routing_service.nodes:
            routing_service.generate_sample_network(
                request.start_location["latitude"],
                request.start_location["longitude"]
            )
        
        result = routing_service.calculate_route(
            request.start_location["latitude"],
            request.start_location["longitude"],
            request.end_location["latitude"],
            request.end_location["longitude"],
            request.constraints
        )
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/team/register")
async def register_team(team_id: str, members: List[TeamMember]):
    """Register a security team."""
    try:
        from app.services.security.escort_service import TeamMember as EscortTeamMember
        
        team_members = [
            EscortTeamMember(
                id=m.id,
                name=m.name,
                role=m.role,
                position=m.position,
                status=m.status
            )
            for m in members
        ]
        
        escort_planning_service.register_team(team_id, team_members)
        return {"status": "success", "message": f"Team {team_id} registered"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/escort-plan")
async def create_escort_plan(request: EscortPlanRequest):
    """Create security escort plan with force distribution."""
    try:
        plan = escort_planning_service.create_escort_plan(
            request.team_id,
            request.start_location,
            request.end_location,
            request.constraints
        )
        
        if plan:
            return {"status": "success", "plan": escort_planning_service.get_plan(plan.plan_id)}
        else:
            return {"status": "error", "message": "Could not create escort plan"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/escort-plan/{plan_id}")
async def get_escort_plan(plan_id: str):
    """Get escort plan details."""
    plan = escort_planning_service.get_plan(plan_id)
    if plan:
        return plan
    else:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found")


@router.get("/escort-plans")
async def get_all_escort_plans():
    """Get all escort plans."""
    return escort_planning_service.get_all_plans()


@router.post("/escort-plan/{plan_id}/activate")
async def activate_escort_plan(plan_id: str):
    """Activate an escort plan."""
    success = escort_planning_service.activate_plan(plan_id)
    if success:
        return {"status": "success", "message": f"Plan {plan_id} activated"}
    else:
        raise HTTPException(status_code=404, detail=f"Plan not found")


@router.post("/escort-plan/{plan_id}/complete")
async def complete_escort_plan(plan_id: str):
    """Mark an escort plan as completed."""
    success = escort_planning_service.complete_plan(plan_id)
    if success:
        return {"status": "success", "message": f"Plan {plan_id} completed"}
    else:
        raise HTTPException(status_code=404, detail="Plan not found")


@router.post("/escort-plan/{plan_id}/cancel")
async def cancel_escort_plan(plan_id: str):
    """Cancel an escort plan."""
    success = escort_planning_service.cancel_plan(plan_id)
    if success:
        return {"status": "success", "message": f"Plan {plan_id} cancelled"}
    else:
        raise HTTPException(status_code=404, detail="Plan not found")


@router.get("/team/{team_id}")
async def get_team_status(team_id: str):
    """Get team status."""
    status = escort_planning_service.get_team_status(team_id)
    if status:
        return status
    else:
        raise HTTPException(status_code=404, detail=f"Team {team_id} not found")


@router.get("/checkpoints")
async def get_control_points(area: str = "default"):
    """Get security control points for an area."""
    # For MVP, return sample checkpoints
    return {
        "area": area,
        "checkpoints": [
            {
                "id": "cp_1",
                "name": "Main Entrance",
                "location": {"latitude": 35.6892, "longitude": 51.3890},
                "priority": 1
            },
            {
                "id": "cp_2",
                "name": "North Gate",
                "location": {"latitude": 35.6900, "longitude": 51.3900},
                "priority": 2
            }
        ]
    }


@router.post("/emergency-plan")
async def create_emergency_plan(situation: Dict[str, Any]):
    """Create emergency response plan."""
    return {
        "status": "success",
        "plan": {
            "type": "emergency_response",
            "situation": situation,
            "actions": [
                "Secure perimeter",
                "Contact authorities",
                "Evacuate if necessary",
                "Rendezvous at safe location"
            ],
            "priority": "high"
        }
    }
