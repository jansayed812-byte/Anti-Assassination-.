from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List
from app.services.training.training_service import training_service, UserRole

router = APIRouter()


class TrainingStart(BaseModel):
    user_id: str
    role: str
    module_id: str


class TrainingProgress(BaseModel):
    user_id: str
    module_id: str
    progress: float


class TrainingComplete(BaseModel):
    user_id: str
    module_id: str
    score: float


@router.get("/modules")
async def get_all_modules():
    """Get all available training modules."""
    modules = training_service.modules
    return {
        "modules": [
            {
                "id": module.id,
                "title": module.title,
                "description": module.description,
                "duration_hours": module.duration_hours,
                "target_roles": [role.value for role in module.target_roles],
                "content": module.content,
                "assessment_method": module.assessment_method,
                "pass_score": module.pass_score
            }
            for module in modules.values()
        ],
        "count": len(modules)
    }


@router.get("/modules/{module_id}")
async def get_module(module_id: str):
    """Get a specific training module."""
    module = training_service.get_module(module_id)
    if module:
        return {
            "id": module.id,
            "title": module.title,
            "description": module.description,
            "duration_hours": module.duration_hours,
            "target_roles": [role.value for role in module.target_roles],
            "content": module.content,
            "assessment_method": module.assessment_method,
            "pass_score": module.pass_score
        }
    else:
        raise HTTPException(status_code=404, detail=f"Module {module_id} not found")


@router.get("/plans/role/{role}")
async def get_role_training_plan(role: str):
    """Get training plan for a specific role."""
    try:
        role_enum = UserRole(role)
        plan = training_service.get_role_training_plan(role_enum)
        return plan
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid role")


@router.get("/plans")
async def get_all_training_plans():
    """Get training plans for all roles."""
    return training_service.get_all_training_plans()


@router.post("/start")
async def start_training(data: TrainingStart):
    """Start a training module for a user."""
    try:
        role_enum = UserRole(data.role)
        success = training_service.start_training(data.user_id, role_enum, data.module_id)
        
        if success:
            return {"status": "success", "message": f"Training started for user {data.user_id}"}
        else:
            return {"status": "error", "message": "Could not start training (invalid module or role)"}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid role")


@router.post("/progress")
async def update_progress(data: TrainingProgress):
    """Update training progress for a user."""
    success = training_service.update_progress(data.user_id, data.module_id, data.progress)
    
    if success:
        return {"status": "success", "message": "Progress updated"}
    else:
        return {"status": "error", "message": "Could not update progress"}


@router.post("/complete")
async def complete_training(data: TrainingComplete):
    """Complete a training module with assessment score."""
    success = training_service.complete_training(data.user_id, data.module_id, data.score)
    
    if success:
        return {"status": "success", "message": "Training completed"}
    else:
        return {"status": "error", "message": "Could not complete training"}


@router.get("/progress/{user_id}")
async def get_user_progress(user_id: str):
    """Get training progress for a user."""
    return training_service.get_user_progress(user_id)


@router.post("/reset/{user_id}/{module_id}")
async def reset_user_training(user_id: str, module_id: str):
    """Reset a user's training progress for a module."""
    success = training_service.reset_user_training(user_id, module_id)
    
    if success:
        return {"status": "success", "message": "Training reset for retake"}
    else:
        return {"status": "error", "message": "Could not reset training"}


@router.get("/statistics")
async def get_training_statistics():
    """Get overall training statistics."""
    return training_service.get_training_statistics()