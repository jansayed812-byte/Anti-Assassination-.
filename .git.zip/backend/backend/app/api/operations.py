from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from datetime import datetime
from app.services.operations.sla_monitor import sla_monitor_service, SLAMetric
from app.services.operations.maintenance_calendar import maintenance_calendar_service, MaintenanceFrequency, MaintenanceStatus

router = APIRouter()


class SLAMeasurement(BaseModel):
    metric: str
    value: float
    details: str = ""


@router.get("/sla/metrics")
async def get_all_sla_metrics():
    """Get status for all SLA metrics."""
    return sla_monitor_service.get_all_metrics_status()


@router.get("/sla/metric/{metric}")
async def get_sla_metric(metric: str):
    """Get status for a specific SLA metric."""
    try:
        metric_enum = SLAMetric(metric)
        return sla_monitor_service.get_metric_status(metric_enum)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid metric")


@router.post("/sla/measure")
async def record_sla_measurement(measurement: SLAMeasurement):
    """Record a measurement for an SLA metric."""
    try:
        metric_enum = SLAMetric(measurement.metric)
        result = sla_monitor_service.record_measurement(
            metric_enum,
            measurement.value,
            measurement.details
        )
        return {
            "metric": result.metric.value,
            "value": result.value,
            "status": result.status.value,
            "timestamp": result.timestamp.isoformat()
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid metric")


@router.get("/sla/violations")
async def get_sla_violations(limit: int = 100):
    """Get recent SLA violations."""
    return sla_monitor_service.get_violations(limit)


@router.get("/sla/report")
async def get_sla_compliance_report(
    start_date: str,
    end_date: str
):
    """Generate compliance report for a time period."""
    try:
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)
        return sla_monitor_service.get_compliance_report(start, end)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format")


@router.post("/sla/simulate/{metric}")
async def simulate_sla_measurement(metric: str):
    """Simulate a measurement for testing."""
    try:
        metric_enum = SLAMetric(metric)
        result = sla_monitor_service.simulate_measurement(metric_enum)
        return {
            "metric": result.metric.value,
            "value": result.value,
            "status": result.status.value,
            "timestamp": result.timestamp.isoformat()
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid metric")


@router.get("/sla/trend/{metric}")
async def get_sla_trend(metric: str, days: int = 30):
    """Get trend analysis for a specific metric."""
    try:
        metric_enum = SLAMetric(metric)
        return sla_monitor_service.get_trend_analysis(metric_enum, days)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid metric")


@router.get("/sla/forecast/{metric}")
async def forecast_sla_metric(metric: str, days_ahead: int = 7):
    """Forecast metric value based on historical trend."""
    try:
        metric_enum = SLAMetric(metric)
        return sla_monitor_service.forecast_metric(metric_enum, days_ahead)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid metric")


@router.get("/sla/dashboard")
async def get_sla_dashboard():
    """Get comprehensive SLA dashboard data."""
    return sla_monitor_service.get_sla_dashboard()


@router.get("/sla/report/{period}")
async def generate_sla_report(period: str = "monthly"):
    """Generate comprehensive SLA report for specified period."""
    return sla_monitor_service.generate_sla_report(period)


@router.get("/maintenance/tasks")
async def get_all_maintenance_tasks():
    """Get all maintenance tasks."""
    tasks = maintenance_calendar_service.get_all_tasks()
    return {
        "tasks": [
            {
                "id": task.id,
                "title": task.title,
                "description": task.description,
                "frequency": task.frequency.value,
                "estimated_duration_hours": task.estimated_duration_hours,
                "priority": task.priority,
                "status": task.status.value,
                "last_completed": task.last_completed.isoformat() if task.last_completed else None,
                "next_scheduled": task.next_scheduled.isoformat(),
                "assigned_to": task.assigned_to,
                "notes": task.notes
            }
            for task in tasks
        ],
        "count": len(tasks)
    }


@router.get("/maintenance/tasks/{task_id}")
async def get_maintenance_task(task_id: str):
    """Get a specific maintenance task."""
    task = maintenance_calendar_service.get_task(task_id)
    if task:
        return {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "frequency": task.frequency.value,
            "estimated_duration_hours": task.estimated_duration_hours,
            "priority": task.priority,
            "status": task.status.value,
            "last_completed": task.last_completed.isoformat() if task.last_completed else None,
            "next_scheduled": task.next_scheduled.isoformat(),
            "assigned_to": task.assigned_to,
            "notes": task.notes
        }
    else:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")


@router.get("/maintenance/upcoming")
async def get_upcoming_maintenance_tasks(days: int = 7):
    """Get tasks scheduled in the next N days."""
    tasks = maintenance_calendar_service.get_upcoming_tasks(days)
    return {
        "tasks": [
            {
                "id": task.id,
                "title": task.title,
                "scheduled": task.next_scheduled.isoformat(),
                "priority": task.priority,
                "assigned_to": task.assigned_to
            }
            for task in tasks
        ],
        "count": len(tasks)
    }


@router.get("/maintenance/frequency/{frequency}")
async def get_tasks_by_frequency(frequency: str):
    """Get tasks by frequency."""
    try:
        freq_enum = MaintenanceFrequency(frequency)
        tasks = maintenance_calendar_service.get_tasks_by_frequency(freq_enum)
        return {
            "frequency": frequency,
            "tasks": [
                {
                    "id": task.id,
                    "title": task.title,
                    "next_scheduled": task.next_scheduled.isoformat(),
                    "priority": task.priority
                }
                for task in tasks
            ],
            "count": len(tasks)
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid frequency")


@router.post("/maintenance/complete/{task_id}")
async def complete_maintenance_task(task_id: str, notes: str = ""):
    """Mark a maintenance task as completed."""
    success = maintenance_calendar_service.complete_task(task_id, notes)
    if success:
        return {"status": "success", "message": f"Task {task_id} completed"}
    else:
        return {"status": "error", "message": f"Could not complete task {task_id}"}


@router.post("/maintenance/skip/{task_id}")
async def skip_maintenance_task(task_id: str, reason: str = ""):
    """Skip a maintenance task."""
    success = maintenance_calendar_service.skip_task(task_id, reason)
    if success:
        return {"status": "success", "message": f"Task {task_id} skipped"}
    else:
        return {"status": "error", "message": f"Could not skip task {task_id}"}


@router.get("/maintenance/calendar")
async def get_maintenance_calendar(
    start_date: str,
    end_date: str
):
    """Get maintenance calendar for a date range."""
    try:
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)
        return maintenance_calendar_service.get_maintenance_calendar(start, end)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format")


@router.get("/maintenance/summary")
async def get_maintenance_summary():
    """Get summary of maintenance status."""
    return maintenance_calendar_service.get_maintenance_summary()


@router.post("/maintenance/start/{task_id}")
async def start_maintenance_task(task_id: str):
    """Mark a maintenance task as in progress."""
    success = maintenance_calendar_service.start_task(task_id)
    if success:
        return {"status": "success", "message": f"Task {task_id} started"}
    else:
        return {"status": "error", "message": f"Could not start task {task_id} (dependencies not met)"}


@router.post("/maintenance/fail/{task_id}")
async def fail_maintenance_task(task_id: str, error_message: str = ""):
    """Mark a maintenance task as failed."""
    success = maintenance_calendar_service.fail_task(task_id, error_message)
    if success:
        return {"status": "success", "message": f"Task {task_id} marked as failed"}
    else:
        return {"status": "error", "message": f"Could not fail task {task_id}"}


@router.get("/maintenance/overdue")
async def get_overdue_tasks():
    """Get tasks that are overdue."""
    tasks = maintenance_calendar_service.get_overdue_tasks()
    return {
        "tasks": [
            {
                "id": task.id,
                "title": task.title,
                "scheduled": task.next_scheduled.isoformat(),
                "priority": task.priority,
                "assigned_to": task.assigned_to
            }
            for task in tasks
        ],
        "count": len(tasks)
    }


@router.get("/maintenance/dependent/{task_id}")
async def get_dependent_tasks(task_id: str):
    """Get tasks that depend on the specified task."""
    tasks = maintenance_calendar_service.get_dependent_tasks(task_id)
    return {
        "task_id": task_id,
        "dependent_tasks": [
            {
                "id": task.id,
                "title": task.title,
                "priority": task.priority
            }
            for task in tasks
        ],
        "count": len(tasks)
    }


@router.post("/maintenance/reschedule/{task_id}")
async def reschedule_maintenance_task(task_id: str, new_date: str, reason: str = ""):
    """Reschedule a maintenance task to a new date."""
    try:
        new_datetime = datetime.fromisoformat(new_date)
        success = maintenance_calendar_service.reschedule_task(task_id, new_datetime, reason)
        if success:
            return {"status": "success", "message": f"Task {task_id} rescheduled to {new_date}"}
        else:
            return {"status": "error", "message": f"Could not reschedule task {task_id}"}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format")


@router.post("/maintenance/assign/{task_id}")
async def assign_maintenance_task(task_id: str, assignee: str):
    """Assign a maintenance task to a person/team."""
    success = maintenance_calendar_service.assign_task(task_id, assignee)
    if success:
        return {"status": "success", "message": f"Task {task_id} assigned to {assignee}"}
    else:
        return {"status": "error", "message": f"Could not assign task {task_id}"}


@router.get("/maintenance/report/{period}")
async def generate_maintenance_report(period: str = "monthly"):
    """Generate comprehensive maintenance report."""
    return maintenance_calendar_service.generate_maintenance_report(period)