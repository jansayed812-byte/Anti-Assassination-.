from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import numpy as np
import cv2
from app.services.threat.threat_service import threat_analysis_service

router = APIRouter()


class ThreatData(BaseModel):
    location: dict
    threat_type: str
    severity: str
    confidence: float


class LocationData(BaseModel):
    latitude: float
    longitude: float
    altitude: Optional[float] = 0.0


@router.post("/start")
async def start_threat_analysis():
    """Start the threat analysis service."""
    try:
        threat_analysis_service.start()
        return {"status": "success", "message": "Threat analysis service started"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_threat_analysis():
    """Stop the threat analysis service."""
    try:
        threat_analysis_service.stop()
        return {"status": "success", "message": "Threat analysis service stopped"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/detect/image")
async def detect_threats_image(
    file: UploadFile = File(...),
    latitude: float = 35.6892,
    longitude: float = 51.3890
):
    """Detect threats in an uploaded image using AI analysis."""
    try:
        # Read image file
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if image is None:
            raise HTTPException(status_code=400, detail="Invalid image file")
        
        location = {
            "latitude": latitude,
            "longitude": longitude
        }
        
        # Analyze image
        result = threat_analysis_service.analyze_image(image, location)
        
        return result
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/detect")
async def detect_threats(data: ThreatData):
    """Submit manual threat data (for testing or manual input)."""
    alert = threat_analysis_service.generate_alert(data.dict())
    return {"status": "success", "alert": alert}


@router.get("/map")
async def get_threat_map():
    """Get real-time threat map with risk levels."""
    risk_map = threat_analysis_service.get_risk_map()
    return risk_map


@router.get("/blind-spots")
async def get_blind_spots():
    """Identify signal blind spots in the area."""
    # This would normally analyze camera feeds
    return {"blind_spots": [], "message": "Blind spot detection requires camera input"}


@router.post("/risk-score")
async def calculate_risk_score(location: LocationData, time_of_day: str = "day"):
    """Calculate risk score for a specific location."""
    risk = threat_analysis_service.calculate_risk_score(
        location.model_dump(),
        time_of_day
    )
    return risk


@router.get("/statistics")
async def get_threat_statistics():
    """Get threat analysis statistics."""
    stats = threat_analysis_service.get_statistics()
    return stats


@router.get("/history")
async def get_threat_history(limit: int = 100):
    """Get threat detection history."""
    history = threat_analysis_service.get_threat_history(limit)
    return {"threats": history, "count": len(history)}
