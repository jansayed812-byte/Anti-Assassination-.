from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from app.services.governance.data_lifecycle import data_lifecycle_service, DataClass
from app.services.governance.compliance_engine import compliance_engine, ComplianceFramework

router = APIRouter()


class DataRegistration(BaseModel):
    data_id: str
    data_class: str
    metadata: Dict[str, Any]


@router.post("/data/register")
async def register_data(data: DataRegistration):
    """Register a data item with its class and metadata."""
    try:
        data_class_enum = DataClass(data.data_class)
        success = data_lifecycle_service.register_data(
            data.data_id,
            data_class_enum,
            data.metadata
        )
        
        if success:
            return {"status": "success", "message": f"Data {data.data_id} registered"}
        else:
            return {"status": "error", "message": "Invalid data class"}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid data class")


@router.get("/data/{data_id}")
async def get_data_info(data_id: str):
    """Get information about a specific data item."""
    info = data_lifecycle_service.get_data_info(data_id)
    if info:
        return info
    else:
        raise HTTPException(status_code=404, detail=f"Data {data_id} not found")


@router.get("/data/class/{data_class}")
async def get_data_by_class(data_class: str):
    """Get all data items of a specific class."""
    try:
        data_class_enum = DataClass(data_class)
        items = data_lifecycle_service.get_data_by_class(data_class_enum)
        return {"data_class": data_class, "items": items, "count": len(items)}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid data class")


@router.post("/data/{data_id}/validate-classification")
async def validate_data_classification(data_id: str, proposed_class: str):
    """Validate if data can be classified as proposed class."""
    try:
        data_class_enum = DataClass(proposed_class)
        result = data_lifecycle_service.validate_data_classification(data_id, data_class_enum)
        return result
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid data class")


@router.post("/data/class/{data_class}/retention")
async def update_retention_policy(data_class: str, new_retention: str):
    """Update retention policy for a data class (admin only)."""
    try:
        data_class_enum = DataClass(data_class)
        success = data_lifecycle_service.update_retention_policy(data_class_enum, new_retention)
        if success:
            return {"status": "success", "message": f"Retention policy updated for {data_class}"}
        else:
            return {"status": "error", "message": "Failed to update retention policy"}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid data class")


@router.get("/data/user/{user_id}/rights")
async def get_data_subject_rights(user_id: str):
    """Get GDPR-like data subject rights for a user."""
    return data_lifecycle_service.get_data_subject_rights(user_id)


@router.post("/data/user/{user_id}/deletion-request")
async def initiate_data_deletion_request(user_id: str, reason: str):
    """Initiate GDPR deletion request for user data."""
    return data_lifecycle_service.initiate_data_deletion_request(user_id, reason)


@router.get("/data/storage-metrics")
async def get_storage_metrics():
    """Get storage metrics for data classes."""
    return data_lifecycle_service.get_storage_metrics()


@router.get("/data/export-registry")
async def export_registry():
    """Export data registry for audit purposes."""
    return data_lifecycle_service.export_registry()


@router.post("/data/cleanup")
async def cleanup_expired_data():
    """Delete expired data items."""
    result = data_lifecycle_service.delete_expired_data()
    return result


@router.get("/data/compliance")
async def get_data_compliance_status():
    """Get overall data governance compliance status."""
    return data_lifecycle_service.get_compliance_status()


@router.get("/data/retention-report")
async def get_retention_report():
    """Generate retention report for compliance."""
    return data_lifecycle_service.generate_retention_report()


@router.post("/data/{data_id}/gdpr-protect")
async def apply_gdpr_protection(data_id: str):
    """Apply GDPR-like protection (auto-blur for non-military personnel)."""
    success = data_lifecycle_service.apply_gdpr_protection(data_id)
    if success:
        return {"status": "success", "message": f"GDPR protection applied to {data_id}"}
    else:
        return {"status": "error", "message": "Could not apply GDPR protection"}


@router.get("/compliance/control/{control_id}")
async def verify_control(control_id: str):
    """Verify a specific compliance control."""
    result = compliance_engine.verify_control(control_id)
    return result


@router.get("/compliance/quarterly-review")
async def quarterly_compliance_review():
    """Perform quarterly compliance review."""
    return compliance_engine.quarterly_compliance_review()


@router.get("/compliance/report")
async def generate_compliance_report():
    """Generate comprehensive compliance report."""
    return compliance_engine.generate_compliance_report()


@router.get("/compliance/framework/{framework}")
async def get_controls_by_framework(framework: str):
    """Get all controls for a specific framework."""
    try:
        framework_enum = ComplianceFramework(framework)
        controls = compliance_engine.get_controls_by_framework(framework_enum)
        return {
            "framework": framework,
            "controls": [
                {
                    "id": c.id,
                    "title": c.title,
                    "description": c.description,
                    "category": c.category,
                    "mandatory": c.mandatory
                }
                for c in controls
            ],
            "count": len(controls)
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid framework")


@router.get("/compliance/module/{module}")
async def get_controls_by_module(module: str):
    """Get controls relevant to a specific system module."""
    controls = compliance_engine.get_controls_by_module(module)
    return {
        "module": module,
        "controls": [
            {
                "id": c.id,
                "title": c.title,
                "framework": c.framework.value,
                "category": c.category
            }
            for c in controls
        ],
        "count": len(controls)
    }


@router.post("/compliance/review/{review_id}/sign")
async def sign_compliance_review(review_id: str, approver: str, approver_role: str):
    """Sign and send quarterly review to commander."""
    return compliance_engine.sign_and_send_review(review_id, approver, approver_role)


@router.get("/compliance/gap/{gap_id}/progress")
async def track_remediation_progress(gap_id: str):
    """Track progress on remediation of specific compliance gap."""
    return compliance_engine.track_remediation_progress(gap_id)


@router.get("/compliance/summary")
async def get_compliance_summary():
    """Generate high-level compliance summary for management."""
    return compliance_engine.generate_compliance_summary()