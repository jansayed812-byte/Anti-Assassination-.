from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List
from app.services.communication.device_manager import device_manager

router = APIRouter()


class DeviceConnection(BaseModel):
    device_id: str
    device_type: str  # GPS, DRONE, IOT, BEACON
    name: str
    configuration: Dict[str, Any] = {}


class DeviceCommand(BaseModel):
    command: str
    params: Dict[str, Any] = {}


@router.post("/start")
async def start_communication():
    """Start the communication service."""
    try:
        device_manager.start()
        return {"status": "success", "message": "Communication service started"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_communication():
    """Stop the communication service."""
    try:
        device_manager.stop()
        return {"status": "success", "message": "Communication service stopped"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/connect")
async def connect_device(connection: DeviceConnection):
    """Connect to external device (GPS, drone, IoT)."""
    success = device_manager.register_device(
        device_id=connection.device_id,
        device_type=connection.device_type,
        name=connection.name,
        configuration=connection.configuration
    )
    
    if success:
        return {"status": "success", "message": f"Device {connection.device_id} registered"}
    else:
        return {"status": "error", "message": f"Device {connection.device_id} already registered"}


@router.post("/disconnect/{device_id}")
async def disconnect_device(device_id: str):
    """Disconnect from external device."""
    success = device_manager.unregister_device(device_id)
    
    if success:
        return {"status": "success", "message": f"Device {device_id} disconnected"}
    else:
        return {"status": "error", "message": f"Device {device_id} not found"}


@router.get("/devices")
async def list_devices():
    """List all connected devices."""
    devices = device_manager.get_all_devices()
    return {"devices": devices, "count": len(devices)}


@router.get("/devices/type/{device_type}")
async def list_devices_by_type(device_type: str):
    """List devices by type."""
    devices = device_manager.get_devices_by_type(device_type.upper())
    return {
        "devices": [
            {
                "device_id": d.device_id,
                "device_type": d.device_type,
                "name": d.name,
                "status": d.status,
                "last_seen": d.last_seen.isoformat(),
                "battery_level": d.battery_level,
                "data": d.data
            }
            for d in devices
        ],
        "count": len(devices)
    }


@router.get("/status/{device_id}")
async def get_device_status(device_id: str):
    """Get status of a specific device."""
    device = device_manager.get_device(device_id)
    
    if device:
        return {
            "device_id": device.device_id,
            "device_type": device.device_type,
            "name": device.name,
            "status": device.status,
            "last_seen": device.last_seen.isoformat(),
            "battery_level": device.battery_level,
            "configuration": device.configuration,
            "data": device.data
        }
    else:
        raise HTTPException(status_code=404, detail=f"Device {device_id} not found")


@router.post("/command/{device_id}")
async def send_command(device_id: str, command: DeviceCommand):
    """Send a command to a specific device."""
    success = device_manager.send_command_to_device(
        device_id,
        command.command,
        command.params
    )
    
    if success:
        return {"status": "success", "message": f"Command sent to device {device_id}"}
    else:
        return {"status": "error", "message": f"Failed to send command to device {device_id}"}


@router.get("/statistics")
async def get_device_statistics():
    """Get device manager statistics."""
    stats = device_manager.get_statistics()
    return stats
