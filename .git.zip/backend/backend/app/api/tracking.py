from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from pydantic import BaseModel
from typing import Optional
from app.services.tracking.tracking_service import tracking_service
from app.websocket.manager import manager
from app.core.security import get_current_user

router = APIRouter()


class TrackingData(BaseModel):
    user_id: int
    latitude: float
    longitude: float
    altitude: Optional[float] = 0.0
    accuracy: Optional[float] = 0.0


@router.post("/start/{user_id}")
async def start_tracking(user_id: int):
    """Start tracking a user."""
    success = tracking_service.start_tracking(user_id)
    if success:
        return {"status": "success", "message": f"Started tracking user {user_id}"}
    else:
        return {"status": "error", "message": f"User {user_id} is already being tracked"}


@router.post("/stop/{user_id}")
async def stop_tracking(user_id: int):
    """Stop tracking a user."""
    success = tracking_service.stop_tracking(user_id)
    if success:
        return {"status": "success", "message": f"Stopped tracking user {user_id}"}
    else:
        return {"status": "error", "message": f"User {user_id} is not being tracked"}


@router.post("/update")
async def update_tracking(data: TrackingData):
    """Update real-time tracking data."""
    position_data = {
        "latitude": data.latitude,
        "longitude": data.longitude,
        "altitude": data.altitude,
        "accuracy": data.accuracy
    }
    
    kinematics = tracking_service.update_position(data.user_id, position_data)
    
    # Broadcast to all connected users
    await manager.broadcast({
        "type": "position_update",
        "user_id": data.user_id,
        "data": kinematics
    })
    
    return {"status": "success", "data": kinematics}


@router.get("/status/{user_id}")
async def get_tracking_status(user_id: int):
    """Get current tracking status for a user."""
    status = tracking_service.get_tracking_status(user_id)
    if status:
        return status
    else:
        return {"user_id": user_id, "status": "not_tracking"}


@router.get("/status")
async def get_all_tracking_status():
    """Get tracking status for all users."""
    return tracking_service.get_all_tracking_status()


@router.get("/history/{user_id}")
async def get_position_history(user_id: int, limit: int = 100):
    """Get position history for a user."""
    history = tracking_service.get_position_history(user_id, limit)
    return {"user_id": user_id, "positions": history, "count": len(history)}


@router.websocket("/ws/{user_id}")
async def websocket_tracking(websocket: WebSocket, user_id: int):
    """WebSocket endpoint for real-time tracking updates."""
    await manager.connect(websocket, user_id)
    
    try:
        while True:
            # Keep connection alive and handle incoming messages
            data = await websocket.receive_json()
            
            if data.get("type") == "position_update":
                position_data = {
                    "latitude": data.get("latitude", 0.0),
                    "longitude": data.get("longitude", 0.0),
                    "altitude": data.get("altitude", 0.0),
                    "accuracy": data.get("accuracy", 0.0)
                }
                
                kinematics = tracking_service.update_position(user_id, position_data)
                
                # Broadcast to all connected users
                await manager.broadcast({
                    "type": "position_update",
                    "user_id": user_id,
                    "data": kinematics
                })
                
                # Send confirmation back to sender
                await websocket.send_json({
                    "type": "update_confirmed",
                    "data": kinematics
                })
            
            elif data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"WebSocket error for user {user_id}: {e}")
        manager.disconnect(websocket)
