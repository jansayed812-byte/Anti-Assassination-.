from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from app.services.monitoring.alerting_service import alerting_service, AlertSeverity, AlertStatus

router = APIRouter()


class AlertCreate(BaseModel):
    severity: str
    title: str
    description: str
    source: str
    metadata: Dict[str, Any] = {}


class AlertRuleCheck(BaseModel):
    metrics: Dict[str, Any]


@router.post("/alerts")
async def create_alert(alert: AlertCreate):
    """Create a new alert."""
    try:
        severity_enum = AlertSeverity(alert.severity)
        new_alert = alerting_service.create_alert(
            severity_enum,
            alert.title,
            alert.description,
            alert.source,
            alert.metadata
        )
        return {
            "id": new_alert.id,
            "severity": new_alert.severity.value,
            "title": new_alert.title,
            "status": new_alert.status.value,
            "created_at": new_alert.created_at.isoformat()
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid severity")


@router.get("/alerts/{alert_id}")
async def get_alert(alert_id: str):
    """Get a specific alert."""
    alert = alerting_service.get_alert(alert_id)
    if alert:
        return {
            "id": alert.id,
            "severity": alert.severity.value,
            "title": alert.title,
            "description": alert.description,
            "source": alert.source,
            "status": alert.status.value,
            "created_at": alert.created_at.isoformat(),
            "acknowledged_at": alert.acknowledged_at.isoformat() if alert.acknowledged_at else None,
            "resolved_at": alert.resolved_at.isoformat() if alert.resolved_at else None,
            "acknowledged_by": alert.acknowledged_by,
            "resolved_by": alert.resolved_by,
            "metadata": alert.metadata
        }
    else:
        raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")


@router.get("/alerts")
async def get_alerts(status: Optional[str] = None, severity: Optional[str] = None):
    """Get alerts with optional filtering."""
    alerts = list(alerting_service.alerts.values())
    
    if status:
        try:
            status_enum = AlertStatus(status)
            alerts = [a for a in alerts if a.status == status_enum]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid status")
    
    if severity:
        try:
            severity_enum = AlertSeverity(severity)
            alerts = [a for a in alerts if a.severity == severity_enum]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid severity")
    
    return {
        "alerts": [
            {
                "id": a.id,
                "severity": a.severity.value,
                "title": a.title,
                "status": a.status.value,
                "created_at": a.created_at.isoformat()
            }
            for a in alerts
        ],
        "count": len(alerts)
    }


@router.get("/alerts/active")
async def get_active_alerts():
    """Get all active alerts."""
    alerts = alerting_service.get_active_alerts()
    return {
        "alerts": [
            {
                "id": a.id,
                "severity": a.severity.value,
                "title": a.title,
                "description": a.description,
                "created_at": a.created_at.isoformat()
            }
            for a in alerts
        ],
        "count": len(alerts)
    }


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, user_id: str):
    """Acknowledge an alert."""
    success = alerting_service.acknowledge_alert(alert_id, user_id)
    if success:
        return {"status": "success", "message": f"Alert {alert_id} acknowledged"}
    else:
        return {"status": "error", "message": f"Could not acknowledge alert {alert_id}"}


@router.post("/alerts/{alert_id}/resolve")
async def resolve_alert(alert_id: str, user_id: str):
    """Resolve an alert."""
    success = alerting_service.resolve_alert(alert_id, user_id)
    if success:
        return {"status": "success", "message": f"Alert {alert_id} resolved"}
    else:
        return {"status": "error", "message": f"Could not resolve alert {alert_id}"}


@router.post("/alerts/{alert_id}/suppress")
async def suppress_alert(alert_id: str):
    """Suppress an alert."""
    success = alerting_service.suppress_alert(alert_id)
    if success:
        return {"status": "success", "message": f"Alert {alert_id} suppressed"}
    else:
        return {"status": "error", "message": f"Could not suppress alert {alert_id}"}


@router.get("/alerts/statistics")
async def get_alert_statistics():
    """Get alert statistics."""
    return alerting_service.get_alert_statistics()


@router.post("/alerts/check-rules")
async def check_alert_rules(data: AlertRuleCheck):
    """Check alert rules against current metrics."""
    triggered_alerts = alerting_service.check_alert_rules(data.metrics)
    return {
        "triggered_alerts": [
            {
                "id": a.id,
                "severity": a.severity.value,
                "title": a.title,
                "description": a.description
            }
            for a in triggered_alerts
        ],
        "count": len(triggered_alerts)
    }


@router.get("/alerts/rules")
async def get_alert_rules():
    """Get all alert rules."""
    rules = alerting_service.get_alert_rules()
    return {
        "rules": {
            rule_id: {
                "name": rule["name"],
                "condition": rule["condition"],
                "severity": rule["severity"].value,
                "description": rule["description"]
            }
            for rule_id, rule in rules.items()
        },
        "count": len(rules)
    }


@router.post("/alerts/cleanup")
async def cleanup_old_alerts(days: int = 30):
    """Clean up alerts older than specified days."""
    removed_count = alerting_service.cleanup_old_alerts(days)
    return {
        "status": "success",
        "removed_count": removed_count,
        "message": f"Cleaned up {removed_count} old alerts"
    }


@router.post("/alerts/simulate")
async def simulate_alert(severity: str = "warning"):
    """Simulate an alert for testing."""
    try:
        severity_enum = AlertSeverity(severity)
        alert = alerting_service.simulate_alert(severity_enum)
        return {
            "id": alert.id,
            "severity": alert.severity.value,
            "title": alert.title,
            "status": alert.status.value,
            "created_at": alert.created_at.isoformat()
        }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid severity")