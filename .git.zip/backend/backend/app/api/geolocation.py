from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from app.services.geolocation.geolocation_service import geolocation_service

router = APIRouter()


class PositionData(BaseModel):
    latitude: float
    longitude: float
    altitude: Optional[float] = 0.0
    accuracy: Optional[float] = 0.0
    source: Optional[str] = "GPS"
    satellites: Optional[int] = 0


@router.post("/start")
async def start_geolocation():
    """Start the geolocation service."""
    try:
        geolocation_service.start()
        return {"status": "success", "message": "Geolocation service started"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_geolocation():
    """Stop the geolocation service."""
    try:
        geolocation_service.stop()
        return {"status": "success", "message": "Geolocation service stopped"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/position")
async def submit_position(position: PositionData):
    """Submit position data from GPS or other sources."""
    # This endpoint is for manual position submission
    # In production, positions come automatically from connected devices
    return {"status": "success", "message": "Position data received"}


@router.get("/current")
async def get_current_position():
    """Get current fused position from all sources."""
    position = geolocation_service.get_current_position()
    if position is None:
        raise HTTPException(status_code=404, detail="No position data available")
    return position


@router.get("/history")
async def get_position_history(limit: int = 100):
    """Get position history from sensor fusion."""
    history = geolocation_service.get_position_history(limit)
    return {"positions": history, "count": len(history)}


@router.get("/sources")
async def get_source_status():
    """Get status of all position sources."""
    status = geolocation_service.get_source_status()
    return status


@router.post("/predict")
async def predict_position(dt: float = 1.0):
    """Predict position at future time step (dt in seconds)."""
    prediction = geolocation_service.predict_position(dt)
    return prediction


@router.post("/reset")
async def reset_geolocation(initial_lat: float = 35.6892, initial_lon: float = 51.3890):
    """Reset the geolocation service with new initial position."""
    geolocation_service.reset(initial_lat, initial_lon)
    return {"status": "success", "message": "Geolocation service reset"}
