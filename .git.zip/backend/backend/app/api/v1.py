from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from datetime import datetime
from app.services.geolocation.ekf_fusion import fusion_engine
from app.services.threat.risk_scoring import risk_scoring_engine
from app.services.scenarios.scenario_engine import scenario_engine, ScenarioCategory
from app.core.security import get_current_user

router = APIRouter(prefix="/v1", tags=["v1"])


class LocationAnalysisRequest(BaseModel):
    """Request for location analysis."""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    altitude: Optional[float] = 0.0
    radius_km: Optional[float] = 1.0
    analysis_type: Optional[str] = "standard"


class LocationAnalysisResponse(BaseModel):
    """Response for location analysis."""
    location: Dict[str, float]
    resources: List[Dict[str, Any]]
    routes: List[Dict[str, Any]]
    constraints: List[Dict[str, Any]]
    uncertainty: Dict[str, Any]
    risk_assessment: Optional[Dict[str, Any]] = None
    analysis_timestamp: str


class ScenarioRunRequest(BaseModel):
    """Request to create scenario run."""
    scenario_id: str
    team_id: str
    equipment_ids: List[str]
    parameters: Optional[Dict[str, Any]] = None


class ScenarioRunResponse(BaseModel):
    """Response for scenario run creation."""
    run_id: str
    scenario_id: str
    status: str
    start_time: str
    estimated_duration_minutes: int


@router.post("/locations/analyze")
async def analyze_location(
    request: LocationAnalysisRequest,
    current_user: dict = Depends(get_current_user)
) -> LocationAnalysisResponse:
    """
    POST /v1/locations/analyze
    
    Receive location and return resources, routes, constraints, and uncertainty.
    """
    try:
        # Get current fused position for context
        fused_pos = fusion_engine.get_fused_position()
        
        # Analyze location (simplified - in production would query real databases)
        location = {
            "latitude": request.latitude,
            "longitude": request.longitude,
            "altitude": request.altitude or 0.0
        }
        
        # Get available resources in area
        resources = [
            {
                "type": "safe_house",
                "id": "SH-001",
                "distance_km": 0.5,
                "capacity": 10,
                "status": "available"
            },
            {
                "type": "medical_facility",
                "id": "MF-001",
                "distance_km": 1.2,
                "capacity": 50,
                "status": "available"
            },
            {
                "type": "communication_node",
                "id": "CN-001",
                "distance_km": 0.3,
                "status": "operational"
            }
        ]
        
        # Calculate available routes
        routes = [
            {
                "type": "primary",
                "distance_km": 2.5,
                "estimated_time_minutes": 15,
                "risk_level": "low",
                "waypoints": [
                    {"lat": request.latitude + 0.01, "lon": request.longitude + 0.01},
                    {"lat": request.latitude + 0.02, "lon": request.longitude + 0.02}
                ]
            },
            {
                "type": "alternate",
                "distance_km": 3.0,
                "estimated_time_minutes": 20,
                "risk_level": "medium",
                "waypoints": [
                    {"lat": request.latitude - 0.01, "lon": request.longitude + 0.01},
                    {"lat": request.latitude - 0.02, "lon": request.longitude + 0.02}
                ]
            }
        ]
        
        # Identify constraints
        constraints = [
            {
                "type": "no_fly_zone",
                "area": {"radius_km": 5.0, "center": location},
                "reason": "restricted_airspace"
            },
            {
                "type": "time_window",
                "start": "06:00",
                "end": "18:00",
                "reason": "operational_hours"
            }
        ]
        
        # Calculate uncertainty based on fused position quality
        uncertainty = {
            "position_uncertainty_m": 5.0 * (1.0 - fused_pos.confidence),
            "altitude_uncertainty_m": 10.0 * (1.0 - fused_pos.confidence),
            "confidence_score": fused_pos.confidence,
            "source_contributions": fused_pos.source_contributions,
            "is_dead_reckoning": fused_pos.is_dead_reckoning
        }
        
        # Optional risk assessment
        if request.analysis_type == "with_risk":
            risk_score = risk_scoring_engine.calculate_risk(
                severity=0.3,
                likelihood=0.4,
                exposure=0.5,
                data_confidence=fused_pos.confidence,
                location=location,
                threat_type="environmental",
                sources=["gnss", "wifi", "ins"]
            )
            
            return LocationAnalysisResponse(
                location=location,
                resources=resources,
                routes=routes,
                constraints=constraints,
                uncertainty=uncertainty,
                risk_assessment={
                    "overall_score": risk_score.overall_score,
                    "risk_level": risk_score.risk_level.value,
                    "factors": [
                        {
                            "name": f.name,
                            "value": f.value,
                            "contribution": f.contribution
                        }
                        for f in risk_score.factors
                    ]
                },
                analysis_timestamp=datetime.utcnow().isoformat()
            )
        
        return LocationAnalysisResponse(
            location=location,
            resources=resources,
            routes=routes,
            constraints=constraints,
            uncertainty=uncertainty,
            analysis_timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Location analysis failed: {str(e)}")


@router.get("/telemetry/latest")
async def get_latest_telemetry(
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    GET /v1/telemetry/latest
    
    Get latest fused position and source quality.
    """
    try:
        fused_pos = fusion_engine.get_fused_position()
        
        # Get source quality information
        source_quality = {
            "gnss": {
                "available": True,
                "last_update": datetime.utcnow().isoformat(),
                "quality": "high" if fused_pos.source_contributions.get("gnss", 0) > 0.5 else "medium"
            },
            "wifi": {
                "available": True,
                "last_update": datetime.utcnow().isoformat(),
                "quality": "medium"
            },
            "ins": {
                "available": True,
                "last_update": datetime.utcnow().isoformat(),
                "quality": "high"
            }
        }
        
        # Get rejected measurements for audit
        rejected = fusion_engine.get_rejected_measurements()
        
        return {
            "position": {
                "latitude": fused_pos.latitude,
                "longitude": fused_pos.longitude,
                "altitude": fused_pos.altitude,
                "velocity_north": fused_pos.velocity_north,
                "velocity_east": fused_pos.velocity_east,
                "velocity_down": fused_pos.velocity_down,
                "heading": fused_pos.heading,
                "pitch": fused_pos.pitch,
                "roll": fused_pos.roll
            },
            "quality": {
                "confidence": fused_pos.confidence,
                "quality_score": fused_pos.quality_score,
                "is_dead_reckoning": fused_pos.is_dead_reckoning,
                "position_covariance": fused_pos.position_covariance.tolist(),
                "velocity_covariance": fused_pos.velocity_covariance.tolist()
            },
            "sources": {
                "contributions": fused_pos.source_contributions,
                "quality": source_quality
            },
            "metadata": {
                "timestamp": fused_pos.timestamp.isoformat(),
                "update_frequency": "5Hz",
                "rejected_measurements_count": len(rejected),
                "rejected_measurements": rejected[-10:]  # Last 10 rejected
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get telemetry: {str(e)}")


@router.post("/scenarios/runs")
async def create_scenario_run(
    request: ScenarioRunRequest,
    current_user: dict = Depends(get_current_user)
) -> ScenarioRunResponse:
    """
    POST /v1/scenarios/runs
    
    Create scenario run with synthetic or authorized dataset.
    """
    try:
        # Validate scenario exists
        scenario = scenario_engine.get_scenario(request.scenario_id)
        if not scenario:
            raise HTTPException(status_code=404, detail=f"Scenario {request.scenario_id} not found")
        
        # Start scenario run
        result = scenario_engine.start_scenario_run(
            scenario_id=request.scenario_id,
            team_id=request.team_id,
            equipment_ids=request.equipment_ids,
            parameters=request.parameters
        )
        
        return ScenarioRunResponse(
            run_id=result.metrics.get("run_id"),
            scenario_id=request.scenario_id,
            status=result.status.value,
            start_time=result.start_time.isoformat(),
            estimated_duration_minutes=scenario.estimated_duration_minutes
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create scenario run: {str(e)}")


@router.get("/scenarios/runs/{run_id}")
async def get_scenario_run_status(
    run_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get status of a specific scenario run."""
    try:
        report = scenario_engine.get_scenario_report(run_id)
        if not report:
            raise HTTPException(status_code=404, detail=f"Scenario run {run_id} not found")
        
        return report
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get scenario status: {str(e)}")


@router.post("/scenarios/runs/{run_id}/events")
async def record_scenario_event(
    run_id: str,
    event_type: str,
    description: str,
    data: Dict[str, Any],
    team_id: Optional[str] = None,
    equipment_id: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, str]:
    """Record an event during scenario execution."""
    try:
        success = scenario_engine.record_event(
            run_id=run_id,
            event_type=event_type,
            description=description,
            data=data,
            team_id=team_id,
            equipment_id=equipment_id
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to record event (run not found or not running)")
        
        return {"status": "success", "message": "Event recorded"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to record event: {str(e)}")


@router.post("/scenarios/runs/{run_id}/complete")
async def complete_scenario_run(
    run_id: str,
    success: bool,
    evaluator_approval: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, str]:
    """Complete a scenario run with evaluation."""
    try:
        success_flag = scenario_engine.complete_scenario_run(
            run_id=run_id,
            success=success,
            evaluator_approval=evaluator_approval
        )
        
        if not success_flag:
            raise HTTPException(status_code=400, detail="Failed to complete scenario run")
        
        return {"status": "success", "message": "Scenario run completed"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to complete scenario: {str(e)}")


@router.get("/reports/{report_id}")
async def get_report(
    report_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    GET /v1/reports/{id}
    
    Get report and provenance.
    """
    try:
        # Check if it's a scenario report
        scenario_report = scenario_engine.get_scenario_report(report_id)
        if scenario_report:
            return {
                "report_id": report_id,
                "report_type": "scenario_execution",
                "report": scenario_report,
                "provenance": {
                    "generated_at": datetime.utcnow().isoformat(),
                    "generated_by": current_user.get("username", "system"),
                    "data_sources": ["scenario_engine", "fusion_engine"],
                    "version": "1.0"
                }
            }
        
        # Check if it's a risk report
        # (In production, would check other report types)
        
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get report: {str(e)}")


@router.get("/scenarios")
async def list_scenarios(
    category: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """List all available scenarios."""
    try:
        if category:
            from app.services.scenarios.scenario_engine import ScenarioCategory
            try:
                cat_enum = ScenarioCategory(category)
                scenarios = scenario_engine.get_scenarios_by_category(cat_enum)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid category: {category}")
        else:
            scenarios = scenario_engine.get_all_scenarios()
        
        return {
            "scenarios": [
                {
                    "id": s.id,
                    "title": s.title,
                    "category": s.category.value,
                    "version": s.version,
                    "educational_objective": s.educational_objective,
                    "estimated_duration_minutes": s.estimated_duration_minutes,
                    "difficulty": s.difficulty
                }
                for s in scenarios
            ],
            "count": len(scenarios)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list scenarios: {str(e)}")


@router.get("/scenarios/statistics")
async def get_scenario_statistics(
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get scenario execution statistics."""
    try:
        return scenario_engine.get_scenario_statistics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get statistics: {str(e)}")