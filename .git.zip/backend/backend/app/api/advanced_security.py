from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional
from app.services.security.advanced_security import advanced_security_service, SecurityLevel

router = APIRouter()


class DataEncryption(BaseModel):
    data: str
    security_level: str = "standard"


class DataDecryption(BaseModel):
    encrypted_data: str


@router.post("/encrypt")
async def encrypt_data(request: DataEncryption):
    """Encrypt data with appropriate security level."""
    try:
        security_level = SecurityLevel(request.security_level)
        result = advanced_security_service.encrypt_data(request.data, security_level)
        return result
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid security level")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/decrypt")
async def decrypt_data(request: DataDecryption):
    """Decrypt data."""
    try:
        result = advanced_security_service.decrypt_data(request.encrypted_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/keys/rotate")
async def rotate_encryption_key():
    """Rotate the encryption key."""
    new_key = advanced_security_service.rotate_encryption_key()
    return {
        "key_id": new_key.key_id,
        "algorithm": new_key.algorithm.value,
        "created_at": new_key.created_at.isoformat(),
        "expires_at": new_key.expires_at.isoformat(),
        "status": new_key.status
    }


@router.get("/keys/{key_id}")
async def get_key_status(key_id: str):
    """Get status of an encryption key."""
    status = advanced_security_service.get_key_status(key_id)
    if status:
        return status
    else:
        raise HTTPException(status_code=404, detail=f"Key {key_id} not found")


@router.get("/keys")
async def get_all_keys():
    """Get all encryption keys."""
    return advanced_security_service.get_all_keys()


@router.post("/keys/{key_id}/revoke")
async def revoke_key(key_id: str):
    """Revoke an encryption key."""
    success = advanced_security_service.revoke_key(key_id)
    if success:
        return {"status": "success", "message": f"Key {key_id} revoked"}
    else:
        return {"status": "error", "message": f"Could not revoke key {key_id}"}


@router.get("/keys/expiry-check")
async def check_key_expiry():
    """Check for expired keys."""
    expired_keys = advanced_security_service.check_key_expiry()
    return {
        "expired_keys": expired_keys,
        "count": len(expired_keys)
    }


@router.get("/audit-log")
async def get_security_audit_log(limit: int = 100):
    """Get security audit log."""
    return advanced_security_service.get_security_audit_log(limit)


@router.post("/tokens/generate")
async def generate_security_token(user_id: str, expiry_hours: int = 24):
    """Generate a secure token for a user."""
    token = advanced_security_service.generate_security_token(user_id, expiry_hours)
    return {
        "token": token,
        "user_id": user_id,
        "expiry_hours": expiry_hours
    }


@router.post("/tokens/validate")
async def validate_security_token(token: str, user_id: str):
    """Validate a security token."""
    valid = advanced_security_service.validate_security_token(token, user_id)
    return {
        "valid": valid,
        "user_id": user_id
    }


@router.get("/security-scan")
async def perform_security_scan():
    """Perform a comprehensive security scan."""
    return advanced_security_service.perform_security_scan()