# Security Assessment System

A comprehensive operational security assessment software for real-time threat analysis, geolocation tracking, and security protocol management.

## Technology Stack

### Backend
- Python 3.11+ with FastAPI
- PostgreSQL + PostGIS for geospatial data
- Redis for caching
- PyTorch with YOLOv8 for AI/ML
- MAVLink for drone communication

### Frontend
- React 18+ with TypeScript
- Material-UI for components
- Leaflet for mapping
- i18next for internationalization (Persian/English)

## Features

### MVP Core Modules
1. **Geolocation Module** - Multi-source positioning with sensor fusion (GPS, Wi-Fi, Bluetooth, Cellular, INS)
2. **Real-Time Tracking** - <1s latency tracking with movement kinematics
3. **AI Threat Analysis** - Computer vision for blind spots and threat detection
4. **Communication Layer** - Device integration (GPS, drones, IoT devices)
5. **Security Protocols** - Escort planning and routing algorithms
6. **Responsive UI** - Persian/English support with real-time dashboard

## Project Structure

```
anti/
├── backend/
│   ├── app/
│   │   ├── api/              # REST API endpoints
│   │   ├── core/             # Security, config, database
│   │   ├── models/           # Database models
│   │   ├── services/         # Business logic
│   │   ├── ml/               # Machine learning models
│   │   └── websocket/        # Real-time handlers
│   ├── tests/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── services/         # API clients
│   │   ├── i18n/             # Translations
│   │   └── types/            # TypeScript types
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
└── README.md
```

## Getting Started

### Prerequisites
- Docker and Docker Compose
- Python 3.11+
- Node.js 18+
- PostgreSQL 15+ with PostGIS

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd anti
```

2. Set up environment variables:
```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your configuration
```

3. Start the services with Docker Compose:
```bash
docker-compose up -d
```

4. The services will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

### Development

#### Backend Development
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

#### Frontend Development
```bash
cd frontend
npm install
npm run dev
```

### Running Tests

#### Backend Tests
```bash
cd backend
pytest tests/ -v
```

#### Frontend Tests
```bash
cd frontend
npm run lint
npm run build
```

## API Documentation

Once the backend is running, visit http://localhost:8000/docs for interactive API documentation.

## Configuration

### Environment Variables

See `backend/.env.example` for all available configuration options:

- Database connection settings
- Redis configuration
- Security settings (JWT secret, encryption)
- ML model paths
- Communication ports

## Hardware Integration

The system supports integration with:
- GPS receivers (USB/Serial)
- IoT trackers (MQTT/HTTP)
- Drones (MAVLink protocol)
- Bluetooth beacons
- Wi-Fi positioning systems

## Security

- JWT-based authentication
- AES-256 encryption for data at rest
- TLS 1.3 for communication
- CORS protection
- SQL injection prevention

## Performance Targets

- Real-time tracking latency: <1s
- Position accuracy: <5m outdoor, <10m urban
- Risk map update rate: 5Hz
- Concurrent users: 10-50 (MVP)

## Future Enhancements

- Advanced simulation module (50+ scenarios)
- 4K video streaming with WebRTC
- ML-based security analysis with incident history
- Full ISO/NATO compliance framework
- Mobile applications (iOS/Android)

## License

Proprietary - All rights reserved

## Support

For support and documentation, contact the development team.
