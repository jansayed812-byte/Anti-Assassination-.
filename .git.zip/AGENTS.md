# Security Assessment System - Development Notes

## Project Overview
This is a comprehensive operational security assessment software built with Python + React/TypeScript for on-premise deployment (10-50 users), enhanced with advanced governance, training, and operational capabilities from DEFENDERS.md specifications.

## Technology Stack
- **Backend**: Python 3.11+ with FastAPI
- **Frontend**: React 18+ with TypeScript, Material-UI
- **Database**: PostgreSQL + PostGIS, Redis
- **ML/AI**: PyTorch with YOLOv8 (permissive license)
- **Real-time**: WebSocket for live updates
- **Communication**: MAVLink for drones, REST API, WebSocket
- **Security**: AES-256-GCM encryption, TLS 1.3, JWT authentication
- **Governance**: ISO 27001, NIST SP 800-53 compliance engine
- **Operations**: SLA monitoring, maintenance calendar, alerting

## Architecture
Monorepo structure with separate backend and frontend directories.

### Backend Structure
- `app/api/` - REST API endpoints (11 modules)
- `app/core/` - Security, config, database
- `app/models/` - Database models
- `app/services/` - Business logic (8 service modules)
  - `geolocation/` - Multi-source positioning with sensor fusion
  - `tracking/` - Real-time movement tracking
  - `threat/` - AI-powered threat analysis
  - `communication/` - Device integration (MAVLink, device management)
  - `security/` - Security protocols, routing, escort planning, advanced security
  - `governance/` - Data lifecycle, compliance engine
  - `training/` - User training and knowledge transfer
  - `operations/` - SLA monitoring, maintenance calendar
  - `monitoring/` - System alerting and monitoring
- `app/ml/` - Machine learning models (YOLOv8 threat detection)
- `app/websocket/` - Real-time WebSocket handlers

### Frontend Structure
- `src/components/` - React components (Dashboard, Map, Threats, Devices)
- `src/services/` - API clients
- `src/i18n/` - Persian/English translations
- `src/types/` - TypeScript types

## Development Commands

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Docker Compose
```bash
docker-compose up -d
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login and get JWT token
- `GET /api/auth/me` - Get current user info

### Geolocation
- `POST /api/geolocation/start` - Start geolocation service
- `POST /api/geolocation/stop` - Stop geolocation service
- `GET /api/geolocation/current` - Get current fused position
- `GET /api/geolocation/history` - Get position history
- `GET /api/geolocation/sources` - Get source status

### Tracking
- `POST /api/tracking/start/{user_id}` - Start tracking user
- `POST /api/tracking/stop/{user_id}` - Stop tracking user
- `POST /api/tracking/update` - Update position data
- `GET /api/tracking/status/{user_id}` - Get tracking status
- `WS /api/tracking/ws/{user_id}` - WebSocket for real-time updates

### Threat Analysis
- `POST /api/threat/start` - Start threat analysis service
- `POST /api/threat/detect/image` - Detect threats in image
- `GET /api/threat/map` - Get real-time threat map
- `POST /api/threat/risk-score` - Calculate risk score for location

### Communication
- `POST /api/communication/start` - Start communication service
- `POST /api/communication/connect` - Connect external device
- `GET /api/communication/devices` - List all devices
- `POST /api/communication/command/{device_id}` - Send command to device

### Security Protocols
- `POST /api/security/route` - Calculate optimal security route
- `POST /api/security/escort-plan` - Create escort plan
- `GET /api/security/escort-plan/{plan_id}` - Get escort plan details

### Data Governance (NEW)
- `POST /api/governance/data/register` - Register data item with class
- `GET /api/governance/data/{data_id}` - Get data item information
- `POST /api/governance/data/cleanup` - Delete expired data
- `GET /api/governance/data/compliance` - Get data governance compliance status
- `GET /api/governance/compliance/quarterly-review` - Quarterly compliance review
- `GET /api/governance/compliance/report` - Comprehensive compliance report

### Training (NEW)
- `GET /api/training/modules` - Get all training modules
- `GET /api/training/plans/role/{role}` - Get training plan for role
- `POST /api/training/start` - Start training for user
- `POST /api/training/complete` - Complete training with score
- `GET /api/training/progress/{user_id}` - Get user training progress
- `GET /api/training/statistics` - Get overall training statistics

### Operations (NEW)
- `GET /api/operations/sla/metrics` - Get all SLA metrics status
- `POST /api/operations/sla/measure` - Record SLA measurement
- `GET /api/operations/sla/violations` - Get SLA violations
- `GET /api/operations/maintenance/tasks` - Get all maintenance tasks
- `POST /api/operations/maintenance/complete/{task_id}` - Complete maintenance task
- `GET /api/operations/maintenance/calendar` - Get maintenance calendar

### Monitoring (NEW)
- `POST /api/monitoring/alerts` - Create new alert
- `GET /api/monitoring/alerts/active` - Get active alerts
- `POST /api/monitoring/alerts/{alert_id}/acknowledge` - Acknowledge alert
- `POST /api/monitoring/alerts/{alert_id}/resolve` - Resolve alert
- `GET /api/monitoring/alerts/statistics` - Get alert statistics
- `POST /api/monitoring/alerts/check-rules` - Check alert rules

### Advanced Security (NEW)
- `POST /api/advanced-security/encrypt` - Encrypt data
- `POST /api/advanced-security/decrypt` - Decrypt data
- `POST /api/advanced-security/keys/rotate` - Rotate encryption key
- `GET /api/advanced-security/keys` - Get all encryption keys
- `GET /api/advanced-security/security-scan` - Perform security scan

## Environment Variables
See `backend/.env.example` for all available configuration options.

## Testing
```bash
# Backend tests
cd backend
pytest tests/ -v

# Frontend tests
cd frontend
npm run lint
npm run build
```

## Deployment
The system is designed for on-premise deployment using Docker Compose. Ensure you have:
- CPU: 8+ cores
- RAM: 32GB+
- Storage: 500GB+ SSD
- Network: Gigabit Ethernet
- GPU: Optional (for faster ML inference)

## Current Status
✅ Infrastructure setup
✅ Base authentication (JWT)
✅ Geolocation module with sensor fusion
✅ Real-time tracking with WebSocket
✅ AI threat analysis with YOLOv8
✅ Communication layer (MAVLink, device management)
✅ Security protocols (routing, escort planning)
✅ Data governance and lifecycle management
✅ Compliance engine (ISO 27001, NIST SP 800-53)
✅ Training module structure and content
✅ SLA monitoring and maintenance calendar
✅ OpenAPI documentation
✅ Operational monitoring and alerting
✅ Advanced security features (encryption, key management)
⏳ Frontend UI implementation (basic structure complete)
⏳ Hardware integration testing
⏳ Comprehensive testing

## DEFENDERS.md Integration
The following modules from DEFENDERS.md have been integrated:

### Data Governance (§22)
- Data lifecycle management with retention policies
- ISO 27001 and NIST SP 800-53 compliance engine
- Quarterly compliance review automation
- GDPR-like data protection features

### Training (§21)
- Multi-level training programs for 5 user roles
- Training modules with assessment methods
- User progress tracking and completion
- Training statistics and reporting

### Operations (§23)
- SLA monitoring with defined targets
- Maintenance calendar with scheduled tasks
- Alert management system
- Performance metrics tracking

### Advanced Security
- AES-256-GCM encryption
- Key rotation and management
- Security audit logging
- Token generation and validation

## Notes
- The geolocation service supports GPS, Wi-Fi, Bluetooth, Cellular, and INS positioning
- Sensor fusion uses Kalman filter for optimal position estimation
- Real-time tracking provides <1s latency with 5Hz update rate
- AI threat detection uses YOLOv8 with permissive license
- Communication layer supports MAVLink for drones
- Security routing uses A* algorithm with risk-aware pathfinding
- System designed for 10-50 concurrent users (MVP)
- Enhanced with enterprise-grade governance and compliance features
- Comprehensive training and operational capabilities
- Advanced security with encryption and key management
